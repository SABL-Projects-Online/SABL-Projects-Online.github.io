function [Cout, Eout, Mout, Pout, Cparout, Eparout, Mparout, Pparout] = ...
    u_copyfromspmd
%  Copy global structures C, Cpar, E, Epar, M, Mpar, P and Ppar from
%  workers inside SPMD to the client. This function is executed while 
%  still in the spmd block. 
%  Outputs:       Copies of global structures defined on the workers

global C Cpar E Epar M Mpar P Ppar

Cout = C;
Eout = E;
Mout = M;
Pout = P;

Cparout = u_aggregrecursive(Cpar);
Eparout = u_aggregrecursive(Epar);
Mparout = u_aggregrecursive(Mpar);
Pparout = u_aggregrecursive(Ppar);

end