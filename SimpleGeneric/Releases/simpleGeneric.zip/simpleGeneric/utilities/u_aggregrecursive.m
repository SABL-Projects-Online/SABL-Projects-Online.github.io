function outspmd = u_aggregrecursive(inspmd)
% Recursively aggregate a structure distributed among workers from inside SPMD out.
%  Input:
%  inspmd     The structure inside SPMD (the source)
%
%  Output:
%  outspmd    The structure outside SPMD (the destination)

if isstruct(inspmd)
    fields = fieldnames(inspmd);
    for i = 1:length(fields)
        outspmd.(fields{i}) = u_aggregrecursive(inspmd.(fields{i}));        
    end
else
    outspmd = u_gcat(inspmd,1,1);
end

end