function F = u_factor(X)
%  For X (n x k), compute a min(n,k) x k matrix F: F'F = X'X.
%  If n < k then F = X.  If n >= k then F = chol(X'*X) if rank(X'*X) = k
%  to machine precision and F is computed from the singular value 
%  decomposition if not. 
%
%  Input:
%  X      Matrix X  (n x k)
%
%  Output:
%  F      Matrix F  (min(n,k) x k)

[n, k] = size(X);
if n >= k
    A = (X'*X);
    try
        F = chol(A);
    catch
        [U, S, V] = svd((A));
        F = U*sqrt(diag(abs(diag(S))))*V';
    end
else
    F = X;
end

end