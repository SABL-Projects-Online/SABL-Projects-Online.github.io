function [struc, maptype] = ...
    u_mapcheck(struc_in, strucname, mapfield, mapsize, ktheta, lincfield)
%  Check the specification of a standard map structure. If there are no
%  errors then compute easymap and substitute empty for non-existing
%  fields.
%
%  Inputs:
%  struc_in    Structure that contains the map
%  strucname   Name of structure, for error messages (string)
%  mapfield    Field with map matrix, e.g. M.betamap
%  mapsize     Required size of map
%  ktheta      Number of columns in theta
%  lincfield   Field of struc with linc matrix, e.g. M.betalinc
%              (Required only if map has negative entries)
%  namefield   Field of struc with name string for partheta
%              (Required only if map has entries > ktheta)
%
%  Output:  
%  struc       Same as struc_in, with possible addition of empty fields
%              lincfield and/or namefield
%  maptype     Indictors for map types: maptype(1) for some struc.mapfield
%              entries < 0; (2) for some entries = 0; (3) for some entries
%              in [1, ktheta]; (4) for some entries > ktheta.

struc = struc_in;

u_isfield(struc, mapfield, true, strucname);
map = struc.(mapfield);
mapname = sprintf('%s.%s', strucname, mapfield);
if length(size(map)) ~= length(mapsize)
    error('The order of %s is incorrect', mapname)
end
if any(size(map) ~= mapsize)
    error('size(%s) = [%s] but [%s] is required', mapname, ...
        num2str(size(map)), num2str(mapsize))
end
u_is('integer', mapname, map)
minmap = min(min(map));
if minmap < 0
    u_isfield(struc, lincfield, true, strucname);
    linc = struc.(lincfield);
    lincname = sprintf('%s.%s', strucname, lincfield);
    if (size(linc, 1) ~= ktheta) && (size(linc, 1) ~= ktheta+1)
        error('%s has %d rows but %d are required', ...
            lincname, size(linc,1), ktheta)
    end
    if -minmap > size(linc, 2)
        error('Entry %d in %s refers to non-existent column of %s', ...
            minmap, mapname, lincname)
    end
end

maptype = [any(any(map < 0)); any(any(map == 0));
    any(any(map > 0 & map < ktheta)); any(any(map > ktheta))];

end