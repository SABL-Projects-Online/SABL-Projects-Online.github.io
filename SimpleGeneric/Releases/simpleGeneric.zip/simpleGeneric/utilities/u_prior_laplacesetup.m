function prior = u_prior_laplacesetup(prior_in)
%  Map alternative specifications of a Lapalce prior distribution function 
%  into a standard specification.  Set up handling of optional inequality 
%  constraints and/or mixed discrete-continuous variant. Check for 
%  specification errors.
%
%  Input:
%  prior_in             Structure expression the prior distribution:
%    .mean, .diversity  Mean and diversity parameters; OR,
%    .mean, .std        Mean and standard deviation
%    .constraints       See function u_constraintssetup    
%    .mixed             See function u_mixedsetup
%
%  Output:
%  prior                Structure expressing the prior distribution. The 
%                       following fields are added:
%    .name              'Laplace'
%    .lambda            Inverse of diversity parameter
%    .n                 Order of the distribution (1)
%    .npars             Corresponding order of theta (1)
%    .lognormconst      Log of Lapalce prior density normalizing constant
%    .con               Indicator for constraints
%    .mix               Indicator for mixed distribution
%    .constraints       See function u_constraintssetup    
%    .mixed             See function u_mixedsetup

trans = @(x) x;

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'Laplace';
prior.n = 1;
prior.npars = 1;

u_isfield(prior, 'mean', true, 'prior');
u_is('scalar', 'prior.mean', prior.mean)
u_is('realfinite', 'prior.mean', prior.mean)

if isfield(prior, 'diversity')
    u_is('scalar', 'prior.diversity', prior.diversity)
    u_is('positivereal', 'prior.diversity', prior.diversity)
    prior.lambda = 1/prior.diversity;
    
elseif isfield(prior, 'std')
    u_is('scalar', 'prior.std', prior.std)
    u_is('positivereal', 'prior.std', prior.std)
    prior.lambda = sqrt(2)/prior.std;

else
    error('No valid combinations of prior hyperparameter fields')
end

prior.lognormconst = log(0.5*prior.lambda);
prior = u_constraintssetup(prior);
if prior.con
    a = prior.constraints.a/prior.constraints.D;
    b = prior.constraints.b/prior.constraints.D;
    lam = prior.lambda;
    if a < prior.mean
        prior.constraints.cdfa = 0.5*exp(lam*(a-prior.mean));
    else
        prior.constraints.cdfa = 1 - 0.5*exp(lam*(prior.mean-a));
    end
    if b < prior.mean
        prior.constraints.cdfb = 0.5*(exp(lam*(b-prior.mean)));
    else
        prior.constraints.cdfb = 1 - 0.5*exp(lam*(prior.mean-b));
    end
    prior.constraints.logG = ...
        log(prior.constraints.cdfb - prior.constraints.cdfa);
end

prior = u_mixedsetup(prior, @u_prior_laplace, trans);

if prior.mix && prior.con
    if prior.mixed.mass < a || prior.mixed.mass > b
        error('Mixed distribution mass points violate constraints')
    end
end

prior.simple = ~(prior.con || prior.mix);
    
end   