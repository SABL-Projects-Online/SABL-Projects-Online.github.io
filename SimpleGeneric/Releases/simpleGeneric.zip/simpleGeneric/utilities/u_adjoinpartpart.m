function [AB, ABmap] = u_adjoinpartpart(A, Amap, B, Bmap, type)
%  Form [A, B] or [A; B] in compact short matrix-particle format
%  given A and B each in full matrix particle format.
%
%  Inputs:
%  array      Source for A and B in full matrix-particle format
%  A, Amap    A in short matrix-particle format
%  B, Bamp    B in short matrix-particle format
%  type       'rows' for [A, B]; 'columns' for [A; B]
%
%  Output
%  AB, ABmap  Matrix [A, B] or [A; B] in compact short matrix-particle 
%             format

nzA = sum(sum(Amap~=0));
AB = [A, B];

if strcmp(type, 'rows')  % Adjoin by rows
    ABmap = [Amap, Bmap + nzA*(Bmap>0)];
else  % Adjoin by columns
    ABmap = [Amap; Bmap + nzA*(Bmap>0)];
end

end