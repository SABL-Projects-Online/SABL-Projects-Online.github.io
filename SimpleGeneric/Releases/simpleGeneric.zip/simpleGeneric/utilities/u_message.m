% function logp = u_message(theta, intensity)
function [logp, states_out] = u_message(theta, varargin)
%  This function is a portal to m_message. Its only purpose is to convert
%  the continuous algorithmic parameterization to the mixed discrete-
%  continuous parameterization for those parts of the parameter vector
%  having a mixed contiuous-discrete prior distribution.  This facilitates
%  writing model likelihood code independently of the prior specification.
%
%  Inputs:
%  theta      Matrix of particles (C.JNwork x C.parameters)
%  intensity  Vector of current information intensity (C.tlast x 1)
%
%  Output:
%  logp       Current information about theta

global M

if M.mix
    theta1 = theta;
    nparts = length(M.prior);
    for ipart = 1:nparts
        a = M.prior{ipart};
        if a.mix
            theta1(:,a.columns) = u_cont_to_mixed(theta(:,a.columns), ...
                a.mixed.mass, a.mixed.r, a.mixed.s);
        end
    end 
    if length(varargin) == 1
        logp = m_message(theta1, varargin{1});
    else
        [logp, states_out] = m_message(theta1, varargin{1}, varargin{2});
    end
        
else
    if length(varargin) == 1
        logp = m_message(theta, varargin{1});
    else
        [logp, states_out] = m_message(theta, varargin{1}, varargin{2});
    end
end

end        