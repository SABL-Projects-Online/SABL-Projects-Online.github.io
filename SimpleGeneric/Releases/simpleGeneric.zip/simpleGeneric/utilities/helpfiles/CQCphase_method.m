function CQCphase_method 
% C.Cphase_method 
% This is the algorithm used in the C phase: 'anneal_Bayes', 'data_whole'
% or 'anneal_optimize'. In general both of the first two options are 
% effective for Bayesian inference: 'anneal_Bayes' is usually faster, but 
%'data_whole' provides predictive likelihoods as well and 'anneal_Bayes' does not. 
%
% Optimization applications must use the 'anneal_optimize' option. In a 
% Bayesian inference application substitution of 'anneal_optimize' for one
% of the other two options produces maximum likelihood estimates. 
%
% CONTROL FIELD  Core default value 'anneal_Bayes'

end