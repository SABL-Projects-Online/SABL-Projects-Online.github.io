function CQCstop_method
% C.Cstop_method 
% This is the stopping rule for the C phase. The choices are:
% 'ESS'                Use the effective sample size criterion 
%                      C.Cstop.ress.
% 'optimize'           User decies when to stop; C.optstatus structure sets
%                      fields to assist in this decision.
% 'custom'             User provides a function p_Cstop_custom to stop the 
%                      C phase
% 'unconditional stop' Stop the C phase after one step.
%
% CONTROL FIELD  Core default: 'ESS'

end