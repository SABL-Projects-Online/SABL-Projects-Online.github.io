function CQCphase
% C.Cphase
% This field is a structure containing fields for algorithm parameters and 
% variables shared across stages in the C phase. 
%
% STRUCTURE

end

