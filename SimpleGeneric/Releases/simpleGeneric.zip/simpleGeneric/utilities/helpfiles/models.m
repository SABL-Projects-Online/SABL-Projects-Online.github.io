function models
%  The following models are available in this edition (2015a) of SABL:  
%        egarch (EGARCH model for asset returns)
%        MVN (multivariate normal, including simultaneous equations)
%        negative_binomial
%        normal
%        poisson
%
%        In most of the models parameters may be functions of covariates.
%
%  Subsidiary topics:
%     help [modelname]brief, e.g. help normalbrief
%     help parametermaps

end