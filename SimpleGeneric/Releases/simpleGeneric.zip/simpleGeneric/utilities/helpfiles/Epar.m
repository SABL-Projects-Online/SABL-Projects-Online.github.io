function Epar
% Epar
% Reserved for computing environment for data that has different values for 
% different workers when multiple CPUs or GPUs are explicitly employed.
% Currently not used.
%
% STRUCTURE

end

