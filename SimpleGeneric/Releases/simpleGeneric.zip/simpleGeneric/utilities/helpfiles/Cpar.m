function Cpar
% Cpar
% One of the eight SABL parent global structures
% The fields of structure Cpar all pertain to SABL core structures and
% fields, for example Cpar.theta. The Cpar structure is used for data that 
% has different values for different workers when multiple CPUs or GPUs are
% explicitly employed.
%
% STRUCTURE

end

