function CQMphaseQstep_upper
% C.Mphase.step_upper 
% In the Mphase algorithms this is the upper bound on the multiplicative 
% factor for converting the covariance matrix of particles to the variance 
% matrix of the Metropolis Gaussian random walk. 
% If C.Mphase.acceptrate > C.Mphase.acceptgoal then the particle variance
% matrix multiplicative factor increases in the next step in the amount
% C.Mphase.step_inc, subject to an upper bound of C.Mphase.step_upper.
% If C.Mphase.acceptrate <= C.Mphase.acceptgoal then the particle variance
% matrix multiplicative factor decreases in the next step in the amount
% C.Mphase.step_inc, subject to a lower bound of C.Mphase.step_lower.
%
% CONTROL FIELD  Core default: 2.0

end