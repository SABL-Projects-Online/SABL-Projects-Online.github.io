function EQphygpus
% E.phygpus
% Number of physical GPUs installed 
% MONITOR FIELD

end

