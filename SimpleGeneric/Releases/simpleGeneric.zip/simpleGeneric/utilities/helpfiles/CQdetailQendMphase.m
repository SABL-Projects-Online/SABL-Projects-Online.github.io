function CQdetailQendMphase
% C.detail.endMphase
% Indicator field for display at the end of the M phase.
%
% CONTROL FIELD  Core default: 'true' if C.detail_level is 6 or 7

end