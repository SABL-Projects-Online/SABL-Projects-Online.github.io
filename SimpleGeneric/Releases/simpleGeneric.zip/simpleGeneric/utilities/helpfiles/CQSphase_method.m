function CQSphase_method 
% C.Sphase_method 
% The resampling method used in the S phase. Four methods are available
% but only two are recommended. Consult help Sphase for details.
%
% CONTROL FIELD  Core default: 'residual'

end