function CQstage
% The current stage of the SABL algorithm, e.g. 'startrun', 'endMphase', 
% etc.
%
% MONITOR FIELD