function CQlogpl
% C.logpl 
% Element t of this vector is the log predictive likelihood for observation 
% t. The field exists only if SABL uses the data_whole variant of the C 
% phase. 
% MONITOR FIELD

end

