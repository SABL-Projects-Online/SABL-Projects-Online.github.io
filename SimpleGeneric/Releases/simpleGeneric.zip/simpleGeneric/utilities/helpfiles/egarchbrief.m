function egarchbrief
%  Distribution: Exponential Generalized Auotoregressive Conditional
%  Heteroskeasticity Model with K volatility factors and I components
%  in a normal mixture model for the shock.  The model is
%      y_t = muY + sigmaY*exp((1/2)*sum(k=1,...,K)volatility_kt)*shock_t
%      v_kt = alpha_k*v_k,t-1 + beta*k*{|shock_t-1|-sqrt(2/pi)
%                                                    + gamma_k*shock_t-1
%      shock_t ~ N(mu_i, (sigma_i)^2) with probability p_i (i=1,...,I)
%                   E(shock_t) = 0,  var(shock_t) = 1
%  Required model specification fields:
%     M.data       T x d data matrix
%     M.y_pointer  Column of M.data containing y_1, ... , y_T
%     M.K          K = Number of volatility factors
%     M.I          I = Components of mixture distribution for shock_t
%  Parameter map
%  Default map: theta' = (theta(1)', ... , theta(8)')
%      muY = theta(1)/1000
%      sigmaY = exp(theta(2))
%      alpha = (alpha_1, ... , alpha_K)' = tanh(theta(3))
%      beta = (beta_1, ... , beta_K)' = exp(theta(4))
%      gamma = (gamma_1, ... , gamma_K)' = exp(theta(5))
%            p* = (p*_1, ... , p*_I)' = tanh(theta(6))
%            mu* (mu*_1, ... , mu*_I)' = theta(7)
%            sigma* = (sigma*1, ... , sigma*I) = exp(theta(8))
%      p = (p_1, ... , p_I)' = p*/sum(p*)
%            mu** = mu* - sum(p.*mu*)
%            c = 1/sqrt[sum(p.*(mu*.^2 + sigma*.^2)]
%      mu = (mu**) * c
%      sigma = (sigma*) * c
%  Optional maps:
%     For muY (scalar): M.muYmap, M.muYlinc, and name 'muY'
%     For sigmaY (scalar): M.sigmaYmap, M.sigmaYlinc, and name 'sigmaY'
%     For alpha (M.K x 1): M.alphamap, M.alphalinc, and name 'alpha')
%     For beta (M.K x 1): M.betamap, M.betalinc, and name 'beta')
%     For gamma (M.K x 1): M.gammamap, M.gammalinc, and name 'gamma')
%     For p (M.I x 1): M.pmap, M.plinc, and name 'p'
%     For mu (M.I x 1): M.mumap, M.mulinc, and name 'mu'
%     For sigma (M.I x 1): M.sigmamap, M.sigmalinc, and name 'sigma'
%  Default prior distributions: 
%                        (Can be used only in conjunction with default map)
%     theta(1) Normal mean M.muY.mean, standard deviation M.muY.std 
%     theta(2) Normal mean M.sigmaY.mean, standard deviation M.sigmaY.std
%     theta(3) Normal mean ones(K,1)*M.alpha.mean, 
%                                 standard deviations ones(K,1)*M.alpha.std
%     theta(4) Normal mean ones(K,1)*M.beta.mean, 
%                                  standard deviations ones(K,1)*M.beta.std
%     theta(5) Normal mean ones(K,1)*M.gamma.mean, 
%                                 standard deviations ones(K,1)*M.gamma.std
%     theta(6) Normal mean ones(I,1)*M.p.mean, 
%                                     standard deviations ones(I,1)*M.p.std
%     theta(7) Normal mean ones(I,1)*M.mu.mean, 
%                                    standard deviations ones(I,1)*M.mu.std
%     theta(8) Normal mean ones(I,1)*M.sigma.mean, 
%                                 standard deviations ones(I,1)*M.sigma.std
%  Core control field default overrides: None
