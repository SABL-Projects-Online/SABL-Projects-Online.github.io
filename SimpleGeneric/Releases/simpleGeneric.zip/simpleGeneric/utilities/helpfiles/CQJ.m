function CQJ 
% C.J 
% The number of groups J of particles. 
%
% CONTROL FIELD  Core default: 16

end