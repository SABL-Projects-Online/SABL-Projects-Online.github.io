function CQoptstatusQmaxindex
% C.optstatus.maxindex
% In the anneal_optimize algorithm this are the indices of all of the 
% particles at which the evaluation of the objective function yields the 
% global maximum value.
%
% MONITOR FIELD

end