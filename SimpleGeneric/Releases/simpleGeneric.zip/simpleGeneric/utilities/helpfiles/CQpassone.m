function CQpassone 
% C.passone 
% Indicator for pass one of the SABL two-pass algorithm. 
%
% MONITOR FIELD

end