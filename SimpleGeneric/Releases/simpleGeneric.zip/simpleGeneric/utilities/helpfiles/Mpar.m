function Mpar
% Mpar
% One of the eight SABL parent global structures. The Mpar structure is
% model specific and therefore no documentation is available through this
% command. Instead use
%        help [modelname] Mpar
% The Mpar structure is used by few if any models.

end

