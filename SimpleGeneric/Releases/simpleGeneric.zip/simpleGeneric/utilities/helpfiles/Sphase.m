function Sphase
%  There are two primary variations in the S (Selection) phase, set in the
%  control field C.Sphase_method, whose core default value is 'residual'.
%  Selection takes place within but not accross particle groups, which is
%  critical to the evaluation of numerical accuracy in SABL.  
%  The options are
%
%  C.Sphase_method = 'mutlinomial': Multinomial resampling
%     Select particles from a multinomial distribution with sample size
%     C.N = N and probabilities proportional to C phase weights
%
%  C.Sphase_method = 'residual': Residual resamling
%     Compute particle probabilities proportional to C phase weights and
%     resample deterministically from the whole integer parts of the
%     C.N*probabilities. Draw the remaining particles from the residual
%     of particle probabilties from their whole parts using multinomial
%     resampling.
%
%  The properties of the resampling method are critical to central limit
%  theorems for convergence of the particles (in C.N = N) to the target
%  distribution. Both of these methods have the desired properties. The
%  residual method is more efficient than the multinomial method.
%
%  There are two other variations available in SABL, stratified resampling
%  (C.Sphase_method = 'systematic') and strtified resampling
%  (C.Sphase_method = 'stratified') but it is known that the desired
%  central limit theorems to not exist in either case, although they are
%  more efficient. They are available in SABL strictly for methodological
%  research and are not recommended for applied statistics or optimization.
