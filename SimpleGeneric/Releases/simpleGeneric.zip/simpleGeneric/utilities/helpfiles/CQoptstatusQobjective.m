function CQoptstatusQobjective
% C.optstatus.objective
% In the anneal_optimize algorithm this is the value of the objective  
% function at each particle. This C.JN x 1 vector exist in the CPU 
% regardless of the values of E.gup and E.pus.
%
% MONITOR FIELD

end