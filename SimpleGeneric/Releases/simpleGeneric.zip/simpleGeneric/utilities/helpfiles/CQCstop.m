function CQCstop
% C.Cstop
% This field is a structure containing fields for algorithm parameters used 
% in the C phase stopping rule. 
%
% STRUCTURE

end

