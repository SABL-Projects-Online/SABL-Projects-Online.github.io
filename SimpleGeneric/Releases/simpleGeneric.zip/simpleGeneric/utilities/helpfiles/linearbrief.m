function linearbrief
%  The (univariate or multivariate) linear prior distribution has either
%  the form N(mu, sigma) with density kernel
%         exp(-(x-mu)'*(sigma^-1)*(x-mu)/2);
%  OR the form t(mu, sigma, df), with density kernel
%         [1 + (x-mu)'*(sigma^-1)*(x-mu)]^(-(df+n)/2
%  where df is the strictly positive degrees of freedom parameter.
%  In both cases mu is an n x 1 fininte real vector: it is the mean of the
%  normal distribution and the location parameter of the t distribution.
%  In both cases sigma is an n x n positive definite matrix: it is the 
%  variance of the normal distribution and the scale parameter of the
%  t distribution.
%
%  If the field df is present and positive finite then the distribution
%  is Student t. If the field df is absent or present and inf, then the
%  distribution is normal.
%
%  In the hyperparameter fields 
%     mean should be interpreted as location if df < inf
%     variance should be interpreted as scale if df < inf
%  The hyperparameters may be specified by
%     n x 1 vector field mean (= mu) and 
%        n x n positive definite matrix field variance (= sigma), OR
%     n x 1 vector field mean (= mu) and 
%        n x n positive definite matrix field precision (= sigma^-1), OR
%     n x 1 vector field mean (= mu) and n x 1 positive vector field std, 
%        in which case sigma = diag(std.^2)); OR,
%     n x n nonsingular matrix field R, n x 1 vector field r and n x 1
%        positive vector field std, in which case Rx - r has mean or
%        location parameter 0 (n x 1) and variance or scale parameter
%        diag(std.^2) (n x n).
%
%  The linear prior may be modified by truncation to an interval (a, b) 
%  (help priorconstrained); AND/OR by mixture with a discrete distribution 
%  only if n = 1 (help priormixed).

end