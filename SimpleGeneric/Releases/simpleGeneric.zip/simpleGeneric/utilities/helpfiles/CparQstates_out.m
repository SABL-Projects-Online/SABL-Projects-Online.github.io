function CparQstates_out
% Cpar.states_out
% The values of the state variables (if any) determined by the 
% log-likelihood function. The values appropriate to Cpar.states_in depend 
% on whether the algorithm is in the C phase or the M phase, as well as on 
% the variant of the C phase employed. Just how this is done depends on the 
% specifics of the model and is handled in the m_monitor code for the 
% model. See models/egarch for an example and template.

end

