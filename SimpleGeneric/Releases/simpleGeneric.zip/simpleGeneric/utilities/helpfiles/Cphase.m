function Cphase
%  There are three primary variations in the C (Correction) phase, set in
%  the control field C.Cphase_method, whose core default value is 'power':
%
%  C.Cphase_method = 'Bayes_anneal': In the C phase of each cycle the power
%    of the likelihood function is increased up to the point that the 
%    relative effective sample size C.Cstop.ress (default value 0.5) is 
%    attained; but not beyond power 1, at which point cylces are complete.
%
%  C.Cphase_method = 'data_whole': In the Cphase of each cycle,
%    observations are added (in the order provided by the rows of M.data)
%    until relative effective sample size is C.Cstop.ress or less; but
%    not beyond observation C.tlast, at which point cycles are complete.
%
%  C.Cphase_method = 'anneal_optimize': In the Cphase of each cylce the
%    power of the likelihood or objective function is increased until the
%    point that p_monitor sets C.moreinfo = false, at which point cycles
%    are complete.  The monitor structure C.optstatus provides seven
%    summaries of the annealed likelihood or objective function that
%    may be useful in writing the termination code for p_monior.

