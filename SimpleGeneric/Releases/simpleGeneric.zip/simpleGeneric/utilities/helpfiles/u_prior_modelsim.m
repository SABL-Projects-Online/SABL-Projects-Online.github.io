function [theta, prior] = u_prior_modelsim(nsim, prior_in)
%  Simulate from the model distribution.
%
%  Inputs:
%  nsim                    Number of simulations (particles)
%  prior_in                Prior structure created by u_prior_modelsetup
%
%  Outputs:
%  theta                   Simulated random variables (nsim x prior.n)
%  prior                   Same as prior_in, with additional fields that
%                          use values computed in this function (if any).

end