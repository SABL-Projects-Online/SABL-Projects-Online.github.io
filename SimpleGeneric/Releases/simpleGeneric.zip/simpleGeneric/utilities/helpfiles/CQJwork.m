function CQJwork 
% C.Jwork 
% The number of particle groups assigned to each worker, 
% C.Jwork = C.J/E.pus. If C.J/E.pus is not a whole integer then a terminal
% error results.
%
% MONITOR FIELD

end