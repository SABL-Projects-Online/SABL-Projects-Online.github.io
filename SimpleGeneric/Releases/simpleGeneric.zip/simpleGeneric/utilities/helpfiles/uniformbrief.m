function uniformbrief
%  The (univariate or multivariate) uniform prior distribution has 
%  support on (a,b) in Euclidean n-space, density kernel
%          constant if a < x < b; 0 otherwise
%  The hyperparmeters may be specified by
%          n x 2 matrix field endpoints = [ a, b] with a < b, OR
%          n x 1 vector fields mean and width, with width = b - a > 0
%
%  The beta prior may be modified by
%      mixture with a discrete distribution only if n = 1 (see help mixed)

end
