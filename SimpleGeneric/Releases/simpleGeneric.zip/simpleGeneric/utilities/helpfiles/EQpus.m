function EQpus 
% E.pus 
% The number of Matlab workers declared in executing the SABL algorithm.
% If E.pus > 1:
%    A Matlab pool with at least E.pus workers must be opened before 
%    executing SABL. 
%    If E.gpu = true:
%         SABL will use E.pus GPUs, with a terminal error message if there 
% 	      are fewer than E.pus GPUs installed.
%    If E.gpu = false:
%         SABL will divide particles (and other arrays with a C.JN 
%         dimension) among workers.
%    If the Matlab pool is to be closed this must be done after SABL 
%         executes. 
% If E.pus = 1 (SABL default):
%    SABL will work entirely on the client and not involve any workers.
%    If E.gpu = true:
%         The majority of computations is done on one GPU.
%    If E.gpu = false:
%         The majority of computations is done on CPU. Recent versions of 
%         MATLAB automatically utilize more than one CPUs if available.
%
% CONTROL FIELD  Core default: 1

end

