function C
% C
% One of the eight SABL parent global structures
% The fields of structure C all pertain to SABL core structures and fields,
% for example C.J (field), C.Cphase (structure), C.Cphase.power (field).
% The C structure is used for data that has the same value across all
% workers when multiple CPUs or GPUsare explicitly employed.
%
% STRUCTURE

end

