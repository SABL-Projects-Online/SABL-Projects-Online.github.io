function CQsimget
% C.simget 
% Indicator for whether initial particles are read from a file of 
% previously generated particles: simget = isfield(C, 'simulation_get'). 
%
% MONITOR FIELD

end