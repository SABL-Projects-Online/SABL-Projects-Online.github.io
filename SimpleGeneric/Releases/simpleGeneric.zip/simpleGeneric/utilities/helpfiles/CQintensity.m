function CQintensity 
% C.intensity 
% Controls and indicates the multiplicative factor attached to evaluations 
% of the log predictive density.
%
% MONITOR FIELD

end