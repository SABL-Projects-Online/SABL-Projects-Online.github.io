function gammabrief
%  The (univariate) gamma prior distribution has support on (0,inf), 
%     density kernel
%          x^(k-1) * exp(-x/theta)
%  where k is the shape parameter and theta is the scale parameter
%  The hyperparmeters may be specified by
%          scalar fields shape and scale, OR
%          scalar fields shape and rate (rate = 1/theta), OR
%          scalar fields mean and std, OR
%          scalar fields chi2df and scale corresponding to representation
%              scale*x ~ chisquare(chi2df)
%
%  The gamma prior may be modified by
%      truncation to an interval (a, b) (help priorconstrained) AND/OR
%      mixture with a discrete distribution (help priormixed)

end