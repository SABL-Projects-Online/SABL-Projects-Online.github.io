function CQMstop
% C.Mstop 
% This field is a structure containing fields for algorithm parameters used 
% in the M phase stopping rule.
%
% STRUCTURE

end