function CQdetailQstartSphase
% C.detail.startSphase
% Indicator governing whether the number of unique particles following 
% resampling is reported to the screen in the S phase. 
%
% CONTROL FIELD  Core default: 'true' if C.detail_level >= 5

end