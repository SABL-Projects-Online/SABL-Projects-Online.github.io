function priormodel
%  A model may specify a specific prior that is not in the SABL suite of
%  priors. In this case the name of the prior is 'model' and this name
%  can be used just like a SABL prior name: for example, 
%  u_prior_modelsetup is used in the same way as u_prior_linearsetup 
%  or u_prior_gammasetup.
%  A model specifying this option will have provided documentation of
%  specific features of the prior. For example fields of the M structure
%  may have been used to indicate variations on the prior, and in this
%  way the single prior called 'model' in fact becomes several.
%  The model will have provided, in the model directory, the functions SABL 
%  invokes in using any prior distribution:
%             u_prior_modelsetup, u_prior_modelsim, _uprior_model,
%  all using the required input structure. So long as model documentation
%  is adequate, the user need not be concered with these functions.
%  