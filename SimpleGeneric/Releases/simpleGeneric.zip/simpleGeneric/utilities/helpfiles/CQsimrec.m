function CQsimrec
% C.simrec
% Indicator for whether final particles are saved to a file .  
% simrec = isfield(C, 'simulation_record')   
%
% MONITOR FIELD

end