function CQMphaseQtotal
% C.Mphase.total 
% Counts the number of M phase iterations in the entire algorithm
%
% MONITOR FIELD

end