function CQMphaseQranblock
% C.Mphase.ranblock 
% Indicator for random blocking in the MGRW_blocked algorithm. 
%
% CONTROL FIELD  Core default: 'true'

end