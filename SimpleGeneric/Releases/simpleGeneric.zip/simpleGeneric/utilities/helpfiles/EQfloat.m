function EQfloat
% E.float
% Determines whether floating point arithmetic is 'single' or 'double'.
% Default is 'double'. There is rarely a reason to use 'single' for 
% execution on CPUs or on newer GPUs. Core default value 'double'.
% The option 'single' may be eliminated in the near future. 
%
% CONTROL FIELD  Core default: 'double'

end

