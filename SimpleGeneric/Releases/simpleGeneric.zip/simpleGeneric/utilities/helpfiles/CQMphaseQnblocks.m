function CQMphaseQnblocks
% C.Mphase.nblocks 
% The number of blocks in the MGRW_blocked variant of the M phase
% C.Mphase.nblocks = length(C.Mphase.blocks) 
%
% Case 1:
% If C.Mphase.ranblock = true then the model or user may elect to declare
% the value of C.Mphase.nblocks in stage startup.
%
% Case 2:
% If the model or user sets C.Mphase.nblocks in stage startup then
% C.Mphase.nblocks = length(C.blocks).
% If C.ranblock = true (core default) and C.Mphase.nblocks is not 
% declared by the model or user in stage startup then SABL assigns 
% C.Mphase.nblocks = max(2, round(C.parameters/6).
%
% CONTROL FIELD  (Case 1)  MONITOR FIELD (Case 2)

end