function EQgpu 
% E.gpu 
% An indicator field for using one or more GPUs. E.gpu = true in the 
% absence of a GPU produces a terminal error.
%
% CONTROL FIELD  Core default: false

end

