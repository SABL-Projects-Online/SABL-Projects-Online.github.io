function CQdetailQml 
% C.detail.ml 
% Indicator field for displaying log marginal likelihood information at the 
% end of the SABL algorithm. 
%
% CONTROL FIELD  Core default: 'true' if C.detail_level > 0

end