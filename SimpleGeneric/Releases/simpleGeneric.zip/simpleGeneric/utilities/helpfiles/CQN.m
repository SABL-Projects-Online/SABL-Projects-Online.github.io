function CQN
% C.N 
% The number particles N in each group
%
% CONTROL FIELD  Core default: 1024

end