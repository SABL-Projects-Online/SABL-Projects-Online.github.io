function CQMphaseQaccept_rate 
% C.Mphase.accept_rate 
% Acceptance rate in the most recent Metropolis Gaussian random walk step
%
% MONITOR FIELD

end

