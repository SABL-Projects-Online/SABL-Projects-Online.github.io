function Ppar
% Ppar
% One of the eight SABL parent global structures. The Ppar structure is 
% reserved for data created by the user as part of a project (application)
% that has different values for different workers when multiple CPUs or 
% GPUs are explicitly employed.
%
% Since the P structure is project specific, no SABL documentation is
% available.

end

