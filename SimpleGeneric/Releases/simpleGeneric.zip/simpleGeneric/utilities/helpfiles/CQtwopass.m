function CQtwopass
% C.twopass 
% Indicator field for execution of the SABL two-pass algorithm. The 
% two-pass algorithm cannot be executed when updating. 
%
% CONTROL FIELD  Core default: false

end