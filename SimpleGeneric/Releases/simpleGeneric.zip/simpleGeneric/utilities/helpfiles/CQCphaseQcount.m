function CQCphaseQcount
% C.Cphase.count
% Counts the number of C phase iterations in the current cycle.
%
% MONITOR FIELD  

end

