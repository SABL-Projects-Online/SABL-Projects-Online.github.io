function CQCphaseQpower
% C.Cphase.power
% The current value of the objective function (likelihood, for inference) 
% power in the anneal_Bayes and anneal_optimize variants of the C phase. 
% Determined in stage 'whileCphase'. Since the C phase has only one step in 
% the anneal_Bayes and anneal_optimize C phase algorithms, it can be 
% referenced in stage 'endCphase' without loss of information. 
%
% MONITOR FIELD

end

