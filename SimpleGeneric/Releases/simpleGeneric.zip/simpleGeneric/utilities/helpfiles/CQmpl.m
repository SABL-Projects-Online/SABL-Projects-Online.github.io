function CQmpl
% C.mpl 
% Indicator for whether C.mpl is executed. The default is C.mpl = true 
% unless C.Cphase_method = 'anneal_optimize' in which case it is 
% C.mpl = false. 
%
% MONITOR FIELD

end