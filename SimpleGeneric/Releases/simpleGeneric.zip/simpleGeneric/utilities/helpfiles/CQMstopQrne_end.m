function CQMstopQrne_end
% C.Mstop.rne_end 
% RNE stopping criterion for M phase Metropolis steps in the last
% cycle of the SABL algorithm. 
%
% CONTROL FIELD  Core default: 0.9
%

end