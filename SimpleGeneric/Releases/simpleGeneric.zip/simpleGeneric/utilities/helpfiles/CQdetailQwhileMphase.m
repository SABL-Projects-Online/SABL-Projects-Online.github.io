function CQdetailQwhileMphase
% C.detail.whileMphase 
% Indicator field for displaying during the M phase. 
%
% CONTROL FIELD  Core default: 'true' if C.detail_level >= 8.

end