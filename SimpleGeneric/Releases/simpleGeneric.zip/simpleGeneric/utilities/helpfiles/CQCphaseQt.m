function CQCphaseQt
% C.Cphase.t
% The current observation processed in the data_whole C phase algorithm. 
% This provides a reference to the current observation that can be used in 
% p_monitor at stage 'whileCphase'. 
%
% MONITOR FIELD

end

