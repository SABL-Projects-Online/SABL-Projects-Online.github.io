function betabrief
%  The (univariate) beta prior distribution has support on (0,1), 
%     density kernel
%          x^(a-1) * (1-x)^(b-1)
%  The hyperparmeters may be specified by
%          scalar fields a and b, OR
%          scalar fields mean and std
%
%  The beta prior may be modified by
%      truncation to an interval (a, b) (help priorconstrainted) AND/OR
%      mixture with a discrete distribution (help priormixed)

end