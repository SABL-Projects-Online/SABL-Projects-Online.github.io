function u_pucheck
%  Check the compatibility of E.gpu and E.pus declarations with status
%  of physical GPUs and size of Matlab pool.
%  Inputs through global E structure, outputs through error messages

global E

if E.gpu
    if ~E.phygpus
        error('E.gpu = true but GPUs not installed')
    end
%     if E.phygpus < E.pus
%         error('E.pus = %d but %d GPUs installed', E.pus, E.phygpus)
%     end
    if  ~E.mptbi
        error('E.gpu = true but Matlab Parallel Computing Toolbox not installed')
    end
end

if E.pus > 1
    if  ~E.mptbi
        error('E.pus = %d but Matlab Parallel Computing Toolbox not installed. Please use E.pus = 1', E.pus)
    end
    gc = gcp('nocreate');
    if isempty(gc)
	error('E.pus = %d but parpool not opened yet', E.pus)
    else
	if gc.NumWorkers < E.pus
	    error('E.pus = %d but pool size = %d', E.pus, gc.NumWorkers)
	end
    end
end