function logp = u_initial(theta, prior)
%  Evaluate the initial density.
%
%  Inputs:
%  theta         Particles at which log density is evaluated  (JN x npars)
%  prior         Each element of this cell array contains the specification
%                of the initial distribution for a component of the initial
%                distribution.  (cell, ncomponents x 1)
%
%  Output:
%  logp          Evalation of the log density at each particle  (JN x 1)

global C

logp = zeros(C.JNwork, 1);
nparts = length(prior);
for ipart = 1:nparts
    a = prior{ipart};
    
    if strcmp(a.name, 'beta')
        logpi = u_prior_beta(theta(:,a.columns), a);
        
    elseif strcmp(a.name, 'Dirichlet')
        logpi = u_prior_dirichlet(theta(:,a.columns), a);
        
    elseif strcmp(a.name, 'gamma')
        logpi = u_prior_gamma(theta(:,a.columns), a);
  
    elseif strcmp(a.name, 'Laplace')
        logpi = u_prior_laplace(theta(:,a.columns), a);
        
    elseif strcmp(a.name, 'linear')
        logpi = u_prior_linear(theta(:,a.columns), a);
        
    elseif strcmp(a.name, 'uniform')
        logpi = u_prior_uniform(theta(:,a.columns), a);
        
    elseif strcmp(a.name, 'Wishart')
        logpi = u_prior_wishart(theta, a);
        
    elseif strcmp(a.name, 'model')
        logpi = m_prior_custom(theta, ipart, a);
    
    elseif strcmp(a.name, 'custom')
        logpi = p_prior_custom(theta, ipart, a);
        
    end
    
    logp = logp + logpi;
    
end

end