function [ amode ] = u_mode(X,nbins)
%U_MODE Returns the mode of the distribution

[hcc,hce,~] = histcounts(X,nbins);
[mhv,mhi] = max(hcc);
amode = real(hce(mhi+1)+hce(mhi))/2;
end

