function Y = u_gplus(X,labtarget)
%  Extend the Matlab parallel toolbox function Y = gplus(X, labtarget)
%  to include Matlab installations without the parallel toolbox. 
%  
%  Inputs:
%  X          Array to be summed across workers
%  labtarget  Worker on which results will be placed. If this input is
%             missing then the result is placed on all workers.
%
%  Output     
%  Y          Array summed across workers; placement of result is governed
%             by labtarget.

global E

if E.pus > 1
    if nargin == 1
        Y = gplus(X);
    else
        Y = gplus(X,labtarget);
    end
else
    Y = X;
end

end