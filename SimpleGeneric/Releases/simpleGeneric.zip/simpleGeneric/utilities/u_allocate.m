function a = u_allocate(s, memtype, entrytype)
%  Allocate an array of size s on gpu or cpu memory.
%
%  Inputs:
%  s          1 x 2 array specifying the size of the allocation
%  memtype    Memory type (either cpu or gpu); 'gpu', 'cpu' or 'default';                       
%             'default' uses E.gpu to determine memory type
%             If memtype = 'default' then type is determined by E.gpu
%  entrytype  (optional): 'zeros', 'ones', 'eye', 'rand' or 'randn'
%  Omitting the last argument is equivalent to entrytype = 'zero'.
%  Omitting the last two arguments is equivalent to memtype = 'defuault',
%  entrytype = 'zero'.
%
%  Output:
%  a          The array on cpu or gpu as indicated by input , with contents
%             as indicated by input
 
global E

if nargin < 3
    entrytype = 'zeros';
end

if nargin < 2
    memtype = 'default';
end

if strcmp(memtype, 'default')
    if E.gpu
        memtype = 'gpu';
    else
        memtype = 'cpu';
    end 
end

if strcmp(memtype, 'gpu')
    if E.gpu
	if strcmp(entrytype, 'zeros')
	    a = gpuArray.zeros(s);
	elseif strcmp(entrytype, 'ones')
	    a = gpuArray.ones(s);
    elseif strcmp(entrytype, 'eye') 
	    a = gpuArray.eye(s(1));
	elseif strcmp(entrytype, 'rand')
	    a = gpuArray.rand(s);
	elseif strcmp(entrytype, 'randn')
	    a = gpuArray.randn(s);
	else
	    error('entrytype = %s unrecognized',entrytype)
	end
    else
        error('memtype = ''gpu'', yet E.gpu = %d, not supported. E.gpu = 0 could be because E.mptbi = false, E.phygpus < 1 or user set E.gpu = false.', E.gpu);
    end
elseif strcmp(memtype, 'cpu')
    if strcmp(entrytype,'zeros')
        a = zeros(s);
    elseif strcmp(entrytype,'ones')
        a = ones(s);
    elseif strcmp(entrytype, 'eye')
        a = eye(s(1));
    elseif strcmp(entrytype,'rand')
        a = rand(s);
    elseif strcmp(entrytype,'randn')
        a = randn(s);
    else
        error('entrytype = %s unrecognized',entrytype)
    end
else
    error('memtype ''%s'' not supported.', memtype);
end

end