function u_addskeleton(rootdir)
%  Add rootdir (including updates_*) and its core, utilities and library
%  subdirectories to SABL.
%
%  Input:
%  rootdir   Root directory to add to the search path (compulsory,
%            non-empty) 


if 7 == exist(rootdir, 'dir')
    [~, fileinfo] = fileattrib(rootdir);
    rootdirabs = fileinfo.Name; % absolute path of rootdir
    u_adddir(rootdirabs);
    u_addskeleton([rootdirabs filesep 'core']);
    u_addskeleton([rootdirabs filesep 'utilities']);
    u_addskeleton([rootdirabs filesep 'library']);
    u_addskeleton([rootdirabs filesep 'helpfiles']);
    u_addskeleton([rootdirabs filesep 'updates_Simon']);
    u_addskeleton([rootdirabs filesep 'updates_Bin']);
    u_addskeleton([rootdirabs filesep 'updates_Huaxin']);
    u_addskeleton([rootdirabs filesep 'updates_John']);
end

end
