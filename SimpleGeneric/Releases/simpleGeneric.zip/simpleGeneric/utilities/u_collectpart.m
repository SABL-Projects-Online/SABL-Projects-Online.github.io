function [A, Amap] = u_collectpart(array, map, linc, name)
%  Transform a matrix in full matrix-particle format to compact short 
%  matrix-particle format.
%
%  Input:
%  array      Contains non-zero entries of A (JN x npars)  
%
%  Other inputs and outputs:
%  map        Pointers from columns of array to entries in A (n x m)
%             If                        Then A(:,Amap(i,j)) =
%             0 < map(i,j) <= npars     array(:,map(i,j));
%             map(i,j) = 0              No entry, and Amap(i,j)=0
%             map(i,j) < 0              array*linc(1:npars),-map(i,j))
%                                                + linc(npars+1, -map(i,j))
%             map(i,j) > size(array,1)  given by 
%                                             p_thetapar(array, name, i, j)      

global C

[n, m] = size(map);
[JN, npars] = size(array);
A = u_allocate([JN, sum(sum(map~=0))]);

nonlinear = sum(sum(map>npars));
if nonlinear > 0
    ii = u_allocate([nonlinear, 1]);  % On GPU ???
    jj = u_allocate([nonlinear, 1]);  % On GPU ???
    columns = u_allocate([nonlinear, 1]);  % On GPU ???
    nlc = 0;
end

s = 0;
Amap = zeros(n, m);
for j = 1:m  % Indexes rows of map
    for i = 1:n  % Indexes columns of map
        p = map(i,j);  % Value of entry for row i, column j
        if p == 0
            continue
        end
        s = s + 1;
        Amap(i,j) = s;
        if p > 0  && p <= npars
            A(:,s) = array(:,p);
        elseif p < 0
            A(:,s) = array*linc(1:npars,-p);
            if size(linc, 1) > npars
                A(:,s) = A(:,s) + linc(end, -p);
            end
        elseif p > npars
            nlc = nlc + 1;
            ii(nlc) = i;  % Map row for nlc'th nonlinear combination 
            jj(nlc) = j;  % Map column for nlc'th nonlinear combination
            columns(nlc) = s;  % Column of A for nlc'th nonlinear comb.
        end
    end
end

if nonlinear > 0
    if C.nlcuda
        A = p_thetapar_CUDA(array, name, ii, jj, columns, A);
    else
        A = p_thetapar(array, name, ii, jj, columns, A);
    end
end

end