function [keyline, keyword] = u_help(varargin)
% Function replaces the Matlab help function in SABL and supplements it:
% (1) It accesses all helpfiles
%
%  Inputs:
%  command_in    help topic request (string)
% 
%  Outputs:
%  Option 1: No outputs (nargout = 0):
%            Put first set of successive lines with '%' in the first
%            position to screen
%  Option 2: 2 outputs (nargout = 2):
%  keyline   The entire line containing one of the keywords
%            'REQUIRED', 'MONITOR', 'CONTROL', or 'STRUCTURE'
%  keyword   The keyword
%  ... If the the input is a function or the helpfile has none of the
%  keywords then both outputs are 'NONE'

if nargin < 1 || nargin > 2
    error('help requires either 1 or 2 arguments')
end
    
if nargout > 0
    keyline = [];
    if nargout > 2
        error('Too many outputs')
    else
        keyword = [];
    end
end

keystrings = cell(4,1);
keystrings{1} = 'MONITOR';
keystrings{2} = 'CONTROL';
keystrings{3} = 'STRUCTURE';
keystrings{4} = 'REQUIRED';
if nargin == 1
    fullname = u_buildname(varargin{1});
else
    fullname = u_buildname(varargin{1}, varargin{2});
end

%  .........................................

% if nargin == 1
%     fname = varargin{1};
% 
% else
%     model = varargin{1};
%     fname = varargin{2};
% end
% 
% Qfind = false;
% 
% for i = 1:length(fname)
%     if strcmp(fname(i), '.');
%         Qfind = true;
%         fname(i) = 'Q';
%     end
% end
% fname = strcat(fname, '.m');
% pathnow = path;
% if nargin == 1
%     fullname = which(fname);
% else
%     if Qfind
%         pathtemp = strcat(u_getsablroot, '/models/', model, '/', ...
%             'helpfiles/');
%     else
%         pathtemp = strcat(u_getsablroot, '/models/', model, '/');
%     end
%     if ~isempty(dir(pathtemp))
%         addpath(pathtemp)
%     end
% %     strcat(pathtemp, fname)
%     fullname = which(strcat(pathtemp, fname));
%     pause
% end

%  ........................................

if strcmp(fullname, '')
    if nargout == 0
        if nargin == 1
            fprintf('\n%s not found.\n\n', varargin{1})
        else
            fprintf('\n%s %s not found.\n\n', varargin{1}, varargin{2})
        end
    else
        keyline = [];
        keyword = [];
    end
    return
end

if exist(fullname, 'file') == 0
    if nargout == 0
        if nargin == 1
            fprintf('\n%s not found.\n\n', varargin{1})
        else
            fprintf('\n%s %s not found.\n\n', varargin{1}, varargin{2})
        end
    end
    return

end
linesin = importdata(fullname, '\n');
firstpct = false;
jline = 0;
lines = cell(1000, 1);

for i = 1:length(linesin);
    line = linesin{i};
    if ~isempty(line)
        if strcmp(line(1), '%')
            firstpct = true;
            jline = jline + 1;
            lines{jline} = line(2:end);
        else
            if firstpct
                break
            end
        end
    end
end
lines = lines(1:jline);

keyline1 = 'NONE';
keyword1 = 'NONE';
for i = 1:jline
    line = lines{i};
    for j = 1:4
        if strfind(line, keystrings{j}) > 0
            keyline1 = line;
            keyword1 = keystrings{j};
        end
    end
end

if nargout == 0
    for i = 1:jline
        fprintf('%s\n', lines{i})
    end
    fprintf('%s \n', ' ')
    if strcmp(keyword1, 'STRUCTURE')
        if nargin == 1
            u_listfields(varargin{1})
        else
            u_listfields(varargin{1}, varargin{2})
        end
    end
else
    keyline = keyline1;
    keyword = keyword1;
end