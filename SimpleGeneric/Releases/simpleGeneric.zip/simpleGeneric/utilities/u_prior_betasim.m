function theta = u_prior_betasim(nsim, prior)
%  Simulate from the beta prior distribution, x ~ beta(a, b);
%  x = exp(theta)/(1+exp(theta)), theta = log(x/(1-x))
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior     Prior structure created by u_prior_betasetup
%
%  Output:
%  theta     Simulated random variables (nsim x 1)

if prior.con
    lower = prior.constraints.a/prior.constraints.D;
    upper = prior.constraints.b/prior.constraints.D;
    plower = betacdf(lower, prior.a, prior.b);
    pupper = betacdf(upper, prior.a, prior.b);
    p = unifrnd(plower, pupper, nsim, 1);
    x = betainv(p, prior.a, prior.b);
else
    x = betarnd(prior.a, prior.b, nsim, 1);
end
theta = log(x./(1-x));

if prior.mix
    [~, theta] = ...
        u_mixedrnd(theta, log(prior.mixed.mass./(1-prior.mixed.mass)), ...
        prior.mixed.prob, prior.mixed.r, prior.mixed.s);
end

end