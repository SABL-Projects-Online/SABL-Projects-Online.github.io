function u_runtest_study(R, verbose)
%  Summarize the results of u_runtest and test various hypotheses of 
%  interest.
%
%  Inputs:
%  R        Structure of reseauls created by u_runtest
%  verbose  Controls the level detail in output to screen (0, 1 or 2)
%
%  Ouputs:
%  All outputs are to screen

npars = size(R.meantheta,7);

%  Test CPU vs GPU
testiGPUtotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n CPU vs GPU\n')
for iw = 1:2
    for iC = 1:2
        for iM = 1:2
            for itp = 1:2
                for igr = 1:4
                    if ~R.cell(1,iw,iC,iM,itp,igr) || ...
                            ~R.cell(2,iw,iC,iM,itp,igr)
                        continue
                    end
                    thetamean_iGPU1 = R.meantheta(1,iw,iC,iM,itp,igr,:);
                    thetastd_iGPU1 = R.stdtheta(1,iw,iC,iM,itp,igr,:);
                    thetanse_iGPU1 = R.nsetheta(1,iw,iC,iM,itp,igr,:);
                    logmliGPU1 = R.logml(1,iw,iC,iM,itp,igr);
                    logmlnseiGPU1 = R.logmlnse(1,iw,iC,iM,itp,igr);
                    thetamean_iGPU2 = R.meantheta(2,iw,iC,iM,itp,igr,:);
                    thetastd_iGPU2 = R.stdtheta(2,iw,iC,iM,itp,igr,:);
                    thetanse_iGPU2 = R.nsetheta(2,iw,iC,iM,itp,igr,:);
                    logmliGPU2 = R.logml(2,iw,iC,iM,itp,igr);
                    logmlnseiGPU2 = R.logmlnse(2,iw,iC,iM,itp,igr);
                    testiGPU = (thetamean_iGPU2 - thetamean_iGPU1)...
                        ./sqrt(thetanse_iGPU1.^2 + thetanse_iGPU2.^2);
                    testiGPUall = sum(testiGPU.^2);
                    if thetamean_iGPU1 ~=0
                        testiGPUtotal = testiGPUtotal + testiGPUall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmliGPU1 - logmliGPU2)...
                        /sqrt(logmlnseiGPU1.^2 + logmlnseiGPU2^2);
                    if logmliGPU1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iw = %d, iC = %d, iM = %d, itp = %d, ', ...
                            iw, iC, iM, itp)
                        fprintf('igr = %d, Overall test:%9.4f  (%7.5f)', ...
                            igr, testiGPUall, 1 - chi2cdf(testiGPUall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml))));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmliGPU1, logmlnseiGPU1, logmliGPU2, ...
                                logmlnseiGPU2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_iGPU1(i), thetastd_iGPU1(i), ...
                                    thetanse_iGPU1(i),thetamean_iGPU2(i), ...
                                    thetastd_iGPU2(i), thetanse_iGPU2(i), ...
                                    testiGPU(i), ...
                                    0.5*(1-normcdf(abs(testiGPU(i)))))
                            end
                        end
                    end
                    
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testiGPUtotal, testdf, 1 - chi2cdf(testiGPUtotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))
fprintf('\n     paused\n');  pause

%  Test one vs two workers
testiwtotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n One vs two workers\n')
for iGPU = 1:2
    for iC = 1:2
        for iM = 1:2
            for itp = 1:2
                for igr = 1:4
                    if ~R.cell(iGPU,1,iC,iM,itp,igr) || ...
                            ~R.cell(iGPU,2,iC,iM,itp,igr)
                        continue
                    end
                    thetamean_iw1 = R.meantheta(iGPU,1,iC,iM,itp,igr,:);
                    thetastd_iw1 = R.stdtheta(iGPU,1,iC,iM,itp,igr,:);
                    thetanse_iw1 = R.nsetheta(iGPU,1,iC,iM,itp,igr,:);
                    logmliw1 = R.logml(iGPU,1,iC,iM,itp,igr);
                    logmlnseiw1 = R.logmlnse(iGPU,1,iC,iM,itp,igr);
                    thetamean_iw2 = R.meantheta(iGPU,2,iC,iM,itp,igr,:);
                    thetastd_iw2 = R.stdtheta(iGPU,2,iC,iM,itp,igr,:);
                    thetanse_iw2 = R.nsetheta(iGPU,2,iC,iM,itp,igr,:);
                    logmliw2 = R.logml(iGPU,2,iC,iM,itp,igr);
                    logmlnseiw2 = R.logmlnse(iGPU,2,iC,iM,itp,igr);
                    testiw = (thetamean_iw2 - thetamean_iw1)...
                        ./sqrt(thetanse_iw1.^2 + thetanse_iw2.^2);
                    testiwall = sum(testiw.^2);
                    if thetamean_iw1 ~=0
                        testiwtotal = testiwtotal + testiwall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmliw1 - logmliw2)...
                        /sqrt(logmlnseiw1.^2 + logmlnseiw2^2);
                    if logmliw1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iGPU = %d, iC = %d, iM = %d, itp = %d, ', ...
                            iGPU, iC, iM, itp)
                        fprintf('igr = %d, Overall test:%9.4f  (%7.5f)', ...
                            igr, testiwall, 1 - chi2cdf(testiwall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml), 0, 1)));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmliw1, logmlnseiw1, logmliw2, ...
                                logmlnseiw2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_iw1(i), thetastd_iw1(i), ...
                                    thetanse_iw1(i), thetamean_iw2(i), ...
                                    thetastd_iw2(i), thetanse_iw2(i), ...
                                    testiw(i), ...
                                    0.5*(1-normcdf(abs(testiw(i)))))
                            end
                        end
                    end
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testiwtotal, testdf, 1 - chi2cdf(testiwtotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))
fprintf('\n     paused\n');  pause

%  Test the two Cphase methods
testiCtotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n C phase methods data_whole and anneal_Bayes\n')
for iw = 1:2
    for iGPU = 1:2
        for iM = 1:2
            for itp = 1:2
                for igr = 1:4
                    if ~R.cell(iGPU,iw,1,iM,itp,igr) || ...
                            ~R.cell(iGPU,iw,2,iM,itp,igr)
                        continue
                    end
                    thetamean_iC1 = R.meantheta(iGPU,iw,1,iM,itp,igr,:);
                    thetastd_iC1 = R.stdtheta(iGPU,iw,1,iM,itp,igr,:);
                    thetanse_iC1 = R.nsetheta(iGPU,iw,1,iM,itp,igr,:);
                    logmliC1 = R.logml(iGPU,iw,1,iM,itp,igr,:);
                    logmlnseiC1 = R.logmlnse(iGPU,iw,1,iM,itp,igr,:);
                    thetamean_iC2 = R.meantheta(iGPU,iw,2,iM,itp,igr,:);
                    thetastd_iC2 = R.stdtheta(iGPU,iw,2,iM,itp,igr,:);
                    thetanse_iC2 = R.nsetheta(iGPU,iw,2,iM,itp,igr,:);
                    logmliC2 = R.logml(iGPU,iw,2,iM,itp,igr,:);
                    logmlnseiC2 = R.logmlnse(iGPU,iw,2,iM,itp,igr,:);
                    testiC = (thetamean_iC2 - thetamean_iC1)...
                        ./sqrt(thetanse_iC1.^2 + thetanse_iC2.^2);
                    testiCall = sum(testiC.^2);
                    if thetamean_iC1 ~=0
                        testiCtotal = testiCtotal + testiCall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmliC1 - logmliC2)...
                        /sqrt(logmlnseiC1.^2 + logmlnseiC2^2);
                    if logmliC1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iw = %d, iGPU = %d, iM = %d, itp = %d, ', ...
                            iw, iGPU, iM, itp)
                        fprintf('igr = %d, Overall test:%9.4f  (%7.5f)', ...
                            igr, testiCall, 1 - chi2cdf(testiCall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml))));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmliC1, logmlnseiC1, logmliC2, ...
                                logmlnseiC2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_iC1(i), thetastd_iC1(i), ...
                                    thetanse_iC1(i),thetamean_iC2(i), ...
                                    thetastd_iC2(i), thetanse_iC2(i), ...
                                    testiC(i), ...
                                    0.5*(1-normcdf(abs(testiC(i)))))
                            end
                        end
                    end
                    
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testiCtotal, testdf, 1 - chi2cdf(testiCtotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))
fprintf('\n     paused\n');  pause

%  Test 2 Mphase methods
testiMtotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n M phase methods MGRW_simple and MGRW_blocked\n')
for iw = 1:2
    for iGPU = 1:2
        for iC = 1:2
            for itp = 1:2
                for igr = 1:4
                    if ~R.cell(iGPU,iw,iC,1,itp,igr) || ...
                            ~R.cell(iGPU,iw,iC,2,itp,igr)
                        continue
                    end
                    thetamean_iM1 = R.meantheta(iGPU,iw,iC,1,itp,igr,:);
                    thetastd_iM1 = R.stdtheta(iGPU,iw,iC,1,itp,igr,:);
                    thetanse_iM1 = R.nsetheta(iGPU,iw,iC,1,itp,igr,:);
                    logmliM1 = R.logml(iGPU,iw,iC,1,itp,igr,:);
                    logmlnseiM1 = R.logmlnse(iGPU,iw,iC,1,itp,igr,:);
                    thetamean_iM2 = R.meantheta(iGPU,iw,iC,2,itp,igr,:);
                    thetastd_iM2 = R.stdtheta(iGPU,iw,iC,2,itp,igr,:);
                    thetanse_iM2 = R.nsetheta(iGPU,iw,iC,2,itp,igr,:);
                    logmliM2 = R.logml(iGPU,iw,iC,2,itp,igr,:);
                    logmlnseiM2 = R.logmlnse(iGPU,iw,iC,2,itp,igr,:);
                    testiM = (thetamean_iM2 - thetamean_iM1)...
                        ./sqrt(thetanse_iM1.^2 + thetanse_iM2.^2);
                    testiMall = sum(testiM.^2);
                    if thetamean_iM1 ~=0
                        testiMtotal = testiMtotal + testiMall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmliM1 - logmliM2)...
                        /sqrt(logmlnseiM1.^2 + logmlnseiM2^2);
                    if logmliM1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iw = %d, iGPU = %d, iC = %d, itp = %d, ', ...
                            iw, iGPU, iC, itp)
                        fprintf('igr = %d, Overall test:%9.4f  (%7.5f)', ...
                            igr, testiMall, 1 - chi2cdf(testiMall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml))));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmliM1, logmlnseiM1, logmliM2, ...
                                logmlnseiM2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_iM1(i), thetastd_iM1(i), ...
                                    thetanse_iM1(i),thetamean_iM2(i), ...
                                    thetastd_iM2(i), thetanse_iM2(i), ...
                                    testiM(i), ...
                                    0.5*(1-normcdf(abs(testiM(i)))))
                            end
                        end
                    end
                    
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testiMtotal, testdf, 1 - chi2cdf(testiMtotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))
fprintf('\n     paused\n');  pause

%  Test one-pass vs. two-pass
testitptotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n One-pass vs two-pass\n')
for iw = 1:2
    for iGPU = 1:2
        for iC = 1:2
            for iM = 1:2
                for igr = 1:4
                    if ~R.cell(iGPU,iw,iC,iM,1,igr) || ...
                            ~R.cell(iGPU,iw,iC,iM,2,igr)
                        continue
                    end
                    thetamean_itp1 = R.meantheta(iGPU,iw,iC,iM,1,igr,:);
                    thetastd_itp1 = R.stdtheta(iGPU,iw,iC,iM,1,igr,:);
                    thetanse_itp1 = R.nsetheta(iGPU,iw,iC,iM,1,igr,:);
                    logmlitp1 = R.logml(iGPU,iw,iC,iM,1,igr,:);
                    logmlnseitp1 = R.logmlnse(iGPU,iw,iC,iM,1,igr,:);
                    thetamean_itp2 = R.meantheta(iGPU,iw,iC,iM,2,igr,:);
                    thetastd_itp2 = R.stdtheta(iGPU,iw,iC,iM,2,igr,:);
                    thetanse_itp2 = R.nsetheta(iGPU,iw,iC,iM,2,igr,:);
                    logmlitp2 = R.logml(iGPU,iw,iC,iM,2,igr,:);
                    logmlnseitp2 = R.logmlnse(iGPU,iw,iC,iM,2,igr,:);
                    testitp = (thetamean_itp2 - thetamean_itp1)...
                        ./sqrt(thetanse_itp1.^2 + thetanse_itp2.^2);
                    testitpall = sum(testitp.^2);
                    if thetamean_itp1 ~=0
                        testitptotal = testitptotal + testitpall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmlitp1 - logmlitp2)...
                        /sqrt(logmlnseitp1.^2 + logmlnseitp2^2);
                    if logmlitp1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iw = %d, iGPU = %d, iC = %d, iM = %d, ', ...
                            iw, iGPU, iC, iM)
                        fprintf('igr = %d, Overall test:%9.4f  (%7.5f)', ...
                            igr, testitpall, 1 - chi2cdf(testitpall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml))));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmlitp1, logmlnseitp1, logmlitp2, ...
                                logmlnseitp2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_itp1(i), thetastd_itp1(i), ...
                                    thetanse_itp1(i),thetamean_itp2(i), ...
                                    thetastd_itp2(i), thetanse_itp2(i), ...
                                    testitp(i), ...
                                    0.5*(1-normcdf(abs(testitp(i)))))
                            end
                        end
                    end
                    
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testitptotal, testdf, 1 - chi2cdf(testitptotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))
fprintf('\n     paused\n');  pause

%  Early sample, simulation_record = [] vs = name
testigrtotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n Early sample, simulation_record = [] vs = name\n')
for iw = 1:2
    for iGPU = 1:2
        for iC = 1:2
            for iM = 1:2
                for itp = 1:2
                    if ~R.cell(iGPU,iw,iC,iM,itp,1) || ...
                            ~R.cell(iGPU,iw,iC,iM,itp,2)
                        continue
                    end
                    thetamean_igr1 = R.meantheta(iGPU,iw,iC,iM,itp,1,:);
                    thetastd_igr1 = R.stdtheta(iGPU,iw,iC,iM,itp,1,:);
                    thetanse_igr1 = R.nsetheta(iGPU,iw,iC,iM,itp,1,:);
                    logmligr1 = R.logml(iGPU,iw,iC,iM,itp,1);
                    logmlnseigr1 = R.logmlnse(iGPU,iw,iC,iM,itp,1);
                    thetamean_igr2 = R.meantheta(iGPU,iw,iC,iM,itp,2,:);
                    thetastd_igr2 = R.stdtheta(iGPU,iw,iC,iM,itp,2,:);
                    thetanse_igr2 = R.nsetheta(iGPU,iw,iC,iM,itp,2,:);
                    logmligr2 = R.logml(iGPU,iw,iC,iM,itp,2);
                    logmlnseigr2 = R.logmlnse(iGPU,iw,iC,iM,itp,2);
                    testigr = (thetamean_igr2 - thetamean_igr1)...
                        ./sqrt(thetanse_igr1.^2 + thetanse_igr2.^2);
                    testigrall = sum(testigr.^2);
                    if thetamean_igr1 ~=0
                        testigrtotal = testigrtotal + testigrall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmligr1 - logmligr2)...
                        /sqrt(logmlnseigr1.^2 + logmlnseigr2^2);
                    if logmligr1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iw = %d, iGPU = %d, iC = %d, M = %d, ', ...
                            iw, iGPU, iC, iM)
                        fprintf('itp = %d, Overall test:%9.4f  (%7.5f)', ...
                            itp, testigrall, 1 - chi2cdf(testigrall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml))));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmligr1, logmlnseigr1, logmligr2, ...
                                logmlnseigr2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_igr1(i), thetastd_igr1(i), ...
                                    thetanse_igr1(i),thetamean_igr2(i), ...
                                    thetastd_igr2(i), thetanse_igr2(i), ...
                                    testigr(i), ...
                                    0.5*(1-normcdf(abs(testigr(i)))))
                            end
                        end
                    end
                    
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testigrtotal, testdf, 1 - chi2cdf(testigrtotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))
fprintf('\n     paused\n');  pause

%  Late sample, simulation_get = [] vs = name
testigrtotal = 0;
testdf = 0;
testlmltotal = 0;
testlmldf = 0;
fprintf('\n Late sample, simulation_get = [] vs = name\n')
for iw = 1:2
    for iGPU = 1:2
        for iC = 1:2
            for iM = 1:2
                for itp = 1:2
                    if ~R.cell(iGPU,iw,iC,iM,itp,3) || ...
                            ~R.cell(iGPU,iw,iC,iM,itp,4)
                        continue
                    end
                    thetamean_igr1 = R.meantheta(iGPU,iw,iC,iM,itp,3,:);
                    thetastd_igr1 = R.stdtheta(iGPU,iw,iC,iM,itp,3,:);
                    thetanse_igr1 = R.nsetheta(iGPU,iw,iC,iM,itp,3,:);
                    logmligr1 = R.logml(iGPU,iw,iC,iM,itp,3);
                    logmlnseigr1 = R.logmlnse(iGPU,iw,iC,iM,itp,3);
                    thetamean_igr2 = R.meantheta(iGPU,iw,iC,iM,itp,4,:);
                    thetastd_igr2 = R.stdtheta(iGPU,iw,iC,iM,itp,4,:);
                    thetanse_igr2 = R.nsetheta(iGPU,iw,iC,iM,itp,4,:);
                    logmligr2 = R.logml(iGPU,iw,iC,iM,itp,4);
                    logmlnseigr2 = R.logmlnse(iGPU,iw,iC,iM,itp,4);
                    testigr = (thetamean_igr2 - thetamean_igr1)...
                        ./sqrt(thetanse_igr1.^2 + thetanse_igr2.^2);
                    testigrall = sum(testigr.^2);
                    if thetamean_igr1 ~=0
                        testigrtotal = testigrtotal + testigrall;
                        testdf = testdf + npars;
                    end
                    testlml = (logmligr1 - logmligr2)...
                        /sqrt(logmlnseigr1.^2 + logmlnseigr2^2);
                    if logmligr1 ~= 0
                        testlmltotal = testlmltotal + testlml.^2;
                        testlmldf = testlmldf + 1;
                    end
                    if verbose >= 1
                        fprintf('iw = %d, iGPU = %d, iC = %d, M = %d, ', ...
                            iw, iGPU, iC, iM)
                        fprintf('itp = %d, Overall test:%9.4f  (%7.5f)', ...
                            itp, testigrall, 1 - chi2cdf(testigrall, npars))
                        fprintf('  log ML test:%9.4f (%7.5f)\n', ...
                            testlml, 0.5*(1 - normcdf(abs(testlml))));
                        if verbose >= 2
                            fprintf('%15.5f%10.5f%25.5f%10.5f%30.5f\n', ...
                                logmligr1, logmlnseigr1, logmligr2, ...
                                logmlnseigr2, testlml)
                            for i = 1:npars
                                fprintf('%15.5f%10.5f%10.5f%15.5f%10.5f%10.5f%20.5f (%6.4f)\n', ...
                                    thetamean_igr1(i), thetastd_igr1(i), ...
                                    thetanse_igr1(i),thetamean_igr2(i), ...
                                    thetastd_igr2(i), thetanse_igr2(i), ...
                                    testigr(i), ...
                                    0.5*(1-normcdf(abs(testigr(i)))))
                            end
                        end
                    end
                    
                end
            end
        end
    end
end
fprintf('    Overall test statistic for parameters')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testigrtotal, testdf, 1 - chi2cdf(testigrtotal, testdf))
fprintf('        Overall test statistic for log ML')
fprintf('%10.3f, %4.0f d.f., p-value  = %7.5f\n', ...
    testlmltotal, testlmldf, 1 - chi2cdf(testlmltotal, testlmldf))