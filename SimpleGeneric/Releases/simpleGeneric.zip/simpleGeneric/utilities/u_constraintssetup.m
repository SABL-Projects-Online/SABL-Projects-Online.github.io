function prior = u_constraintssetup(prior_in)
%  Check the specification of a prior.constraints structure for
%  a <= D*theta <= b and complete it.
%
%  Inputs:
%  prior_in             Prior structure with the fields
%    .constraints.a     Vector a
%    .constraints.b     Vector b
%    .constraints.D     Vector D 
%  Output:
%  prior                Prior structure with the additional fields
%    .con               Indicator for constraints
%    .constraints.D     Complete D
%    .constraints.Dinv  Inverse of D
%    .constraints.a     Complete a
%    .constraints.b     Complete b

prior = prior_in;
prior.con = u_isfield(prior, 'constraints', false);
if ~prior.con
    return
end

prior.constraints = u_tidyfields(prior.constraints);
u_isfield(prior.constraints, 'a', true, 'prior.constraints');
u_isfield(prior.constraints, 'b', true, 'prior.constraints');
u_isfield(prior.constraints, 'D', true, 'prior.constraints');
    
D = prior.constraints.D;
[r, n] = size(D);
if n ~= prior.n || r > n || r == 0
    error('prior.constraints.D is %d x %d', r, n)
end   
if length(prior.constraints.a)~=r || length(prior.constraints.b)~=r
    error('Dimensions of prior.constraints.D, .a, .b inconsistent')
end
if any(prior.constraints.a >= prior.constraints.b)
    error('prior.constraints.b(i) <= prior.constraints.(i) for some i')
end

if rank(D) < r
    error('D is %d x %d but rank(prior.constraints.D) = %d', ...
        r, n, rank(D))
end
if r < n
    %  This forms an orthonomal completion of the rows of D:
    [~, ~, V] = svd(D);   
    D((r+1):prior.n, :) = V(:,(r+1):prior.n, :)';
    %  ----
end

prior.constraints.D = D;
prior.constraints.Dinv = D\eye(prior.n);
prior.constraints.a(r+1:prior.n) = -inf;
prior.constraints.b(r+1:prior.n) = inf;
prior.constraints.a = reshape(prior.constraints.a, prior.n, 1);
prior.constraints.b = reshape(prior.constraints.b, prior.n, 1);

prior.constraints = u_tidyfields(prior.constraints);

end