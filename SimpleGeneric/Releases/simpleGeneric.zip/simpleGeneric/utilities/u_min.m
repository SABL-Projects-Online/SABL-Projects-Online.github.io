function y = u_min(x, dim, parallel)
%  Replicate the Matlab function min(x, dim) with efficient handling
%  of the multiple-worker case. In the multiple worker case the array
%  sizes must be the same for all workers. All 3 inputs are required.
%
%  Inputs:
%  x  	     The multidimensional array.
%  dim	     Dimension of the array along which the minimum is computed
%  parallel  Indicator for multiple workers
%
%  Output:
%  y        Minimum

y = min(x, [], dim);
if parallel
    y = min(gcat(y, dim),[], dim);
end

end