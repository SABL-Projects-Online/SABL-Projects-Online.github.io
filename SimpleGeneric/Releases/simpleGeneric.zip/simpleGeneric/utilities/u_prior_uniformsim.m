function theta = u_prior_uniformsim(nsim, prior)
%  Simulate from the mutivariate uniform distribution
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior     Prior structure created by u_prior_lambdasetup
%
%  Output:
%  theta     Simulated random variables

n = size(prior.endpoints, 1);
theta = zeros(nsim, n);

for i = 1:n
    theta(:,i) = ...
        unifrnd(prior.endpoints(i,1), prior.endpoints(i,2), nsim, 1);
end

if prior.mix
    [~, theta] = u_mixedrnd(theta, prior.mixed.mass, prior.mixed.prob, ...
        prior.mixed.r, prior.mixed.s);
    
    
end

end