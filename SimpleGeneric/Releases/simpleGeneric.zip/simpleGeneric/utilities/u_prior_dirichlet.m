function logp = u_prior_dirichlet(theta, prior)
%  Evaluate the log pdf of the Dirichlet prior density function
%  log[p(x|a)] = c + sum(i=1,...,n)[(a_i-1)*log(x_i)].
%  For c, see u_prior_dirichletsetup.
%  In turn a is a function of theta:
%     a_i = exp(theta_i)/[1+sum(j=1,...,n-1)exp(theta_j)]
%  where n is the order of the distribution.  The corresponding
%  log Jacobian term is sum(i=1,...,n)[log(x_i)].
%
%  Inputs:
%  theta     Algorithm parameters (C.JNwork x n-1)
%  prior     Prior structure created by u_prior_dirichletsetup
%
%  Output:
%  logp      Log prior density corresponding to theta (C.JNwork x 1)                                                 

JN = size(theta, 1);
logp = repmat(prior.lognormconst, JN, 1);
denominator = ones(JN, 1);

for i = 1:prior.n-1
    logp = logp + prior.avector(i)*theta(:,i);
    denominator = denominator + exp(theta(:,i));
end

logp = logp - prior.asum*log(denominator);

end