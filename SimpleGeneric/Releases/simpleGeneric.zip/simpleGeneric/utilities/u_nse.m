function nse = u_nse(g, N, parallel, logw)
% Compute the numerical standard error of one or more functions
% that may be distributed across workers.
%  
% Inputs:
% g	       Function evaluations with particles by row and functions by 
%          column (JworkerN x ng)
% N	       Number of particles per group
% parallel Indicator for multiple workers
% logw	   Log weights (optional)  (JworkerN x 1)

[JworkerN, ng] = size(g);
if nargin == 4
    if size(logw, 1) ~= JworkerN
        error('g array %d x %d and logw array %d x %d incompatible', ...
            size(g), size(logw))
    end
end
Jworker = JworkerN/N;
n = 0;
gmean = u_allocate([Jworker, ng]);
for k = 1:Jworker
    if nargin == 4
        gmean(k,:) = ...
            u_mean(g(n+1:n+N,:), 1, false, repmat(logw(n+1:n+N), 1, ng));
    else
        gmean(k,:) = u_mean(g(n+1:n+N,:), 1, false);
    end
    n = n + N;
end

if parallel
    gmean = gcat(gmean, 1);
end

nse = std(gmean, [], 1)/sqrt(u_numlabs*Jworker);

end