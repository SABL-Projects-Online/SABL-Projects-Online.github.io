function [specdir, specname] = u_setspecdir(root, specinfo)
%  Set specifics (model or project) for subsequent SABL operations. The
%  specifics will stay in effect until being changed by u_setspecdir.m or
%  SABL(model, project). 
%
%  Inputs:
%  root        a string representing the name of a specific (when there is
%              only one argument) or a path (could be absolute or
%              relative) 
%  specinfo    a string representing the name of a specific
%
%  Outputs:
%  specdir     full path of the directory that contains the specific; in
%              the case of more than one directory has been found, 
%              specdir takes the form of a cell array in alphabetical
%              order (may not be in the order of desired precedence, in
%              this case, manual sorting to implement priority order is
%              needed) 
%  specname    a string identifying a specific, this is actually the last
%              part of the full path of the directory

global E

specdir = '';
specname = '';
if 0 < nargin && ~isempty(root) && ischar(root)
    if 2 > nargin 
        specinfo = root;
        if isempty(regexp(specinfo,filesep,'once'))
            % model is a character string with no filesep (not like a path)
            if ~isfield(E, 'SABLrootdir') || isempty(E.SABLrootdir)
                E.SABLrootdir = u_getsablroot;
            end
            specdir = u_searchdirin(E.SABLrootdir, specinfo);
            if ~isempty(specdir)
                specname = specinfo;
            else
                [specdir, specname] = u_ispath(specinfo);
            end
        else
            % model in a path-like string
            [specdir, specname] = u_ispath(specinfo);
        end
    else
        if 7 == exist(root,'dir') && isempty(regexp(specinfo,filesep,'once'))
            specdir = u_searchdirin(root, specinfo);
            if ~isempty(specdir)
                specname = specinfo;
            else
                [specdir, specname] = u_ispath(specinfo);
            end
        end
    end
end

end