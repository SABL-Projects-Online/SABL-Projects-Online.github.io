function [fullpath, lowestdir] = u_ispath(astring)
%  If astring is a valid pathname then return fullpath and lowest 
%  directory.  Otherwise return empty character arrays.
%
%  Input:
%  astring	   Pathname to be checked
%
%  Outputs:
%  fullpath   Full path of the directory represented by astring, if any.
%  lowestdir  Lowest level directory represented by astring, if any.

fullpath = '';
lowestdir = '';
if ~isempty(astring) && ischar(astring)
    [status, dirinfo] = fileattrib(astring); 
    if 1 == status && 1 == dirinfo.directory
        fullpath = dirinfo.Name; 
        parts = regexp(fullpath, filesep, 'split');
        if isempty(parts(end))
            parts = parts(1:end-1);
        end
        lowestdir = parts{end};
    end
end

end