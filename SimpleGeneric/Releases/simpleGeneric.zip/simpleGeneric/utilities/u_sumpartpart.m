function [C, Cmap] = u_sumpartpart(array, Amap, Ascale, Bmap, Bscale)
%  Compute C = sA*A + sB*B, A and B in short matrix-particle format and C
%  in compact short matrix-particle format
%
%  Inputs:
%  Amap       (array, Amap) is A in short matrix-particle format
%  Ascale     The scalar factor sA
%  Bmap       (array, Bmap) is B in short matrix-particle format
%  Bscale     The scalar factor sB
%
%  Outputs:
%  C, Cmap    Matrix C in compact short matrix-particle format
%
%  The outputs may occupy the same location as any of the inputs in the
%  invoking function.

[n, m] = size(Amap);
JN = size(array, 1);

Cmaplocal = zeros(n, m);
Cflag = Amap~=0 | Bmap~=0;
Clocal = zeros(JN, sum(sum(Cflag)));
s = 0;
for j = 1:m
    for i = 1:n
        if Cflag(i,j)
            s = s + 1;
            Cmaplocal(i,j) = s;
            if Amap(i,j) > 0
                Clocal(:,s) = Ascale*array(:,Amap(i,j));
            end
            if Bmap(i,j) > 0
                Clocal(:,s) = Clocal(:,s) + Bscale*array(:,Bmap(i,j));
            end
        end
    end
end

C = Clocal;
Cmap = Cmaplocal;
   
end