function r = u_ison(a)
% Check if an array is on CPU or GPU
%
% Input:
%   a	 The array to be checked
% Output
%   r	 '', 'cpu' or 'gpu'

if isempty(a)
    r = ''; 
    return;
end

switch class(a)
case 'gpuArray'
    r = 'gpu'; return;
otherwise
    r = 'cpu'; return;
end