function logp = u_prior_beta(theta, prior)
%  Evaluate the log pdf of the beta prior distribution
%  p(x) = x^(a-1) * (1-x)^(b-1) /beta(a,b).

%  The algorithm parameter theta = log(x/(1-x)), so the function 
%  incorporates the log of the Jacobian of transformation
%  log[p(theta)] = log[p(exp(theta)/(1+exp(theta)] -2log(exp(1+theta)).
%
%  Inputs:
%  theta     Points of evaluation (particles); theta = log(x)   
%                                                            (C.JNwork x 1)
%  prior     Prior structure created by u_prior_gammasetup
%
%  Output:
%  logp      Log prior density corresponding to theta (C.JNwork x 1) 

trans = @(x) log(x./(1-x));
invtrans = @(x) exp(x)./(1+exp(x));

if prior.simple
    xx = exp(theta);
    x = xx./(1+xx);
    logp = prior.lognormconst + log(x)*(prior.a-1) + ...
        log(1-x)*(prior.b-1) + log(x.*(1-x));
else
    logp = u_priormixcont(theta, prior, @u_prior_beta, trans, invtrans);
end

end