function prior = u_mixedsetup(prior_in, flogpdf, trans)
% function prior = u_mixedsetup(prior_in, flogpdf, dolog)
%  Check the specification of a prior.mixed structure and complete it.
%
%  Inputs:
%  prior_in       Prior structure with the fields
%    .mixed.mass  Prior distribution mass points (k x 1)
%    .mixed.prob  Associated prior probabilities (k x 1)
%  flogpdf        Handle to the function that evaluates the prior log pdf
%  trans          Function that transforms the variables to which
%                 constraints apply to the algorithm parameter theta
%
%  Output:
%  prior          Prior structure with the additional fields
%    .mix         Indicator for presence of a mixed distribution
%    .mixed.pcont 1 - sum(prior.mixed.prob)
%    .mixed.r     Vector r used in subsequent computations
%    .mixed.s     Vector s used in subsequent computations

prior = prior_in;
prior.mix = u_isfield(prior, 'mixed', false);
if ~prior.mix
    return
end

if prior.n ~= 1
    error('Dimension of prior = %d; prior.mixed requires dimension 1', ...
        prior.n)
end

prior.mixed = u_tidyfields(prior.mixed);

u_isfield(prior.mixed, 'mass', true, 'prior.mixed');
u_isfield(prior.mixed, 'prob', true, 'prior.mixed');
if any(prior.mixed.prob < 0) || sum(prior.mixed.prob) >= 1
    error('prior.mixed.prob is not a valid mass probability vector')
end

prior.mixed.pcont = 1 - sum(prior.mixed.prob);
prior.mix = false;
prior.simple = true;
pdf = exp(flogpdf(trans(prior.mixed.mass), prior));
[prior.mixed.r, prior.mixed.s] = ...
    u_rscreate(trans(prior.mixed.mass), prior.mixed.prob, pdf);
if prior.mixed.s > 1/eps
    error('Mass point outside support of prior (to machine rounding error)')
end
prior.simple = false;
prior.mix = true;
prior.mixed = u_tidyfields(prior.mixed);

end