function u_is(property,label,x)
%  Check whether a structure and/or value of a structure posesses a certain
%  property.  Return terminal error if not.
%
%  Inputs:
%  property  Qualifications for which strucutre and/or value are checked
%  label     Name of array (for use in error message)
%  x         Array

if isempty(x)
    error('%s is empty',label)
elseif ~ismatrix(x)
    error('%s is not a two-dimensional array', label)
end

if strcmp(property,'realfinite')  %  real number(s)
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) ...
            || any(any(isnan(x)))
        error ('%s is not real and finite',label)
    end
    
elseif strcmp(property,'positivereal')  %  positive number(s)
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) || ...
            any(any(isnan(x))) || any(any(x<=0))
        error('%s is not positive',label)
    end
    
elseif strcmp(property,'nonnegativereal')  %  nonnegative number(s)
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) || ...
            any(any(isnan(x))) || any(any(x<0))
        error('%s is not nonnegative',label)
    end
    
elseif strcmp(property,'integer')  %  integer(s)
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) || ...
            any(any(isnan(x))) || any(any(x~=round(x)))
        error('%s is not integer',label)
    end
    
elseif strcmp(property,'positiveinteger')  %  positive integer(s)
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) ...
            || any(any(isnan(x))) || any(any(x~=round(x))) || ...
            any(any(x<=0))
        error('%s is not positive integer',label)
    end
    
elseif strcmp(property,'nonnegative integer')  %  nonnegative integer(s)
    if any(any(~isfloat(x)) )|| any(any(~isfinite(x))) || ...
            any(any(isnan(x))) || any(any(x~=round(x))) || any(any(x<0))
        error('%s is not nonnegative integer',label)
    end
    
elseif strcmp(property,'distinctpositiveintegers') % distinct pos integers
    if any(~isfloat(x)) || any(~isfinite(x)) || any(isnan(x)) || ...
        any(x~=round(x)) || any(x<=0) || numel(x)~=length(unique(x))
        error('%s is not an array of distinct positive integers',label)
    end

elseif strcmp(property,'scalar')  %  Scalar
    if numel(x)~=1
        error('%s is not a scalar')
    end
    
elseif strcmp(property,'vector')  %  Vector
    [n1, n2] = size(x);
    if ~(n1 ==1 || n2 == 0)
        error('%s is not a vector; specified as %d x %d',...
            label,n1,n2)
    end
    
elseif strcmp(property,'columnvector')  %  column vector
    [n1, n2] = size(x);
    if ~(n1>0 && n2==1)
        error('%s is not a column vector; specified as %d x %d',...
            label,n1,n2)
    end
    
elseif strcmp(property,'characterstring')  %  character string
    if ~ischar(x)
        error('%s is not a character string',label)
    end
    
elseif strcmp(property,'openunitinterval')  %  All elements in (0,1)
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) || ...
            any(any(isnan(x))) || any(any(x<=0)) || any(any(x>=1))
        error('%s is not in the unit interval',label)
    end
    
elseif strcmp(property,'weakorder')  %  Weakly monotone increasing
    if any(~isfloat(x)) || any(~isfinite(x)) || any(isnan(x)) || ...
            any(diff(x)<0)
        error('%s is not real and weakly monotone increasing',label)
    end
    
elseif strcmp(property,'strongorder')  %  Strictly monotone increasing
    if any(~isfloat(x)) || any(~isfinite(x)) || any(isnan(x)) || ...
            any(diff(x)<=0)
        error('%s is not real and strictly monotone increasing',label)
    end
    
elseif strcmp(property,'positive_definite')
    if any(any(~isfloat(x))) || any(any(~isfinite(x))) || ...
            any(any(isnan(x)))
        error('%s some elements not real and finite',label)
    end
    if size(x,1) ~=size(x,2)
        error('%s is %d x %d',label,size(x,1),size(x,2))
    end
    eigs = 0.5*eig(x + x');
    if min(eigs) <= 0
        disp(eigs')
        error('%s (eigenvalues above) is not positive definite',label)
    end
    
else
    error('property = %s is an invalid input', property)
end 