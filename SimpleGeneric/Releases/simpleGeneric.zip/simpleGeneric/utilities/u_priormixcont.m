function logp = u_priormixcont(theta, prior, flogpdf, trans, invtrans)
%  Evaluate the log pdf of the prior distribution given inequality
%  constraints and/or a mixed continuous-discrete distribution
%
%  Inputs:
%  theta     Points of evaluation (particles)  (JN x npars)
%  prior     Structure associated with the prior distribution
%  flogpdf   Handle to the function that evaluates the prior log pdf
%  trans     Function that transforms the variables to which constraints
%            apply to the algorithm parameter theta
%  invtrans  Function that transforms the algorithm parmaetertheta to the 
%            variables to whichconstraints apply
%
%  Output:
%  logp      Log of the prior density evaluated at the particles  (JN x 1

JN = size(theta, 1);
prior.simple = true;

if prior.mix && ~prior.con
    theta1 = u_cont_to_mixed(theta, trans(prior.mixed.mass), ...
        prior.mixed.r, prior.mixed.s);
    logpc = flogpdf(theta1, prior);
    logp = log(u_pdfstar(theta, prior.mixed.pcont*exp(logpc), ...
        prior.mixed.r, prior.mixed.s, prior.mixed.prob));
    
elseif ~prior.mix && prior.con
    z = invtrans(theta)*prior.constraints.D';
    ii = find(all(z >= repmat(prior.constraints.a', JN, 1), 2) & ...
        all(z <= repmat(prior.constraints.b', JN, 1), 2));
    logp = -inf*u_allocate([JN 1],'default','ones');
    logp(ii) = flogpdf(theta(ii,:), prior) - prior.constraints.logG;
    
elseif prior.mix && prior.con
    theta1 = u_cont_to_mixed(theta, trans(prior.mixed.mass), ...
        prior.mixed.r, prior.mixed.s);
    z = invtrans(theta1)*prior.constraints.D';
    ii = find(all(z >= repmat(prior.constraints.a', JN, 1), 2) & ...
        all(z <= repmat(prior.constraints.b', JN, 1), 2));
    logp = -inf(JN, 1);
    logpc = flogpdf(theta1(ii,:), prior);
    factorpdf = prior.mixed.pcont/exp(prior.constraints.logG);
    logp(ii) = log(u_pdfstar(theta(ii,:), factorpdf*exp(logpc), ...
        prior.mixed.r, prior.mixed.s, prior.mixed.prob));
end

prior.simple = false;  %  [Does nothing]

end