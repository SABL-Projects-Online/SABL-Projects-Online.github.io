function [x, xstar] = u_mixedrnd(x_in, mvector, pvector, rvector, svector)
%  Generate random variables from the mixed-continuous discrete 
%  distribution.
%
%  Inputs:
%  x_in      Random variables from the continuous distribution (JN x 1)
%  mvector   Mass points of the distrbution (n x 1)
%  pvector   Probabilities of the mass points (n x 1)
%  rvector   Vector r with reference to the notes in this section
%  svector   Vector s with reference to the notes in this section 
%
%  Output:
%  x         Vector of random variables from the mixed continuous-
%            discrete distribution
%  xstar     Continuous representation of the same random variables
%
%  In application typically x and x_in occupy the same location, thus
%  x = mixedrnd(x, mvector pvector, rvector, svector)

Pvector = [0; cumsum(pvector)];
JN = length(x_in);
u = rand(JN, 1);
n = length(pvector);

%  First pass: Treat all elements of x_in as if from continuous part.
x = x_in;
xstar = x_in;
for j = 1:n-1
    ii = x_in > mvector(j) & x_in <= mvector(j+1);
    xstar(ii) = x_in(ii) - mvector(j) + svector(j);
end
ii = x_in > mvector(n);
xstar(ii) = x_in(ii) - mvector(n) + svector(n);

%  Second pass: Convert randomly and appropriately selected elements of
%  x_in to discrete part.
jj = 1:JN;
for j = 1:n
    ii = find(u > Pvector(j) & u <= Pvector(j+1));
    x(ii) = mvector(j);
    jj = setdiff(jj, ii);
    xstar(ii) = unifrnd(rvector(j), svector(j), length(ii), 1);
end

end