function u_hisfigTruncate(data,lowerb,upperb,chartname,xname,varargin)
%% Histogram distribution plot
global P
% ff = figure(1);
ff = figure();

% clf(ff);
histogram(data,'BinLimits',[lowerb upperb]);
title(chartname);
xlabel(xname);
ylabel('Frequency');
if (length(varargin)>1)
    mlmean = varargin{2};
    mlstderr = varargin{3};
    if (length(varargin)>3)
        priorMean = varargin{4};
        priorStd  = varargin{5};
    else
        priorMean = 0;
        priorStd = 5;
    end
    yyaxis right;
    aax = gca;    
    if ~isempty(mlmean)
        str_m = sprintf('Rational ML mean =  %.2f',mlmean);    
    else
        str_m = [];
    end
    
    if (~isempty(mlmean)&&~isempty(mlstderr))
        str_mps = sprintf('Rational ML mean + 1.96stdErr =  %.2f',(mlmean+1.96*mlstderr));    
        str_mms = sprintf('Rational ML mean - 1.96stdErr =  %.2f',(mlmean-1.96*mlstderr));
        plot([mlmean mlmean],[0 1],':',[(mlmean+1.96*mlstderr) (mlmean+1.96*mlstderr)],[0 1],':',[(mlmean-1.96*mlstderr) (mlmean-1.96*mlstderr)],[0 1],':');
    else
        str_mps = [];
        str_mms = [];
    end
    
    str_prior = sprintf('SABL, prior ~ Normal(%.2f, %.2f^2)',priorMean,priorStd);
    
    if P.useFryer
            if (~isempty(mlmean)&&~isempty(mlstderr))
                legend(['Fryer ' str_prior], str_m, str_mps, str_mms,'Location','NorthOutside');        
            else
                legend(['Fryer ' str_prior],'Location','NorthOutside'); 
            end
    else
            if (~isempty(mlmean)&&~isempty(mlstderr))
                legend(['Rational ' str_prior], str_m, str_mps, str_mms,'Location','NorthOutside');
            else
                legend(['Rational ' str_prior],'Location','NorthOutside');
            end
    end
%     plot([mlmean mlmean],[0 1],':',[(mlmean+1.96*mlstderr) (mlmean+1.96*mlstderr)],[0 1],':',[(mlmean-1.96*mlstderr) (mlmean-1.96*mlstderr)],[0 1],':');
%     str_m = sprintf('ML mean =  %.2f',mlmean);    
%     str_mps = sprintf('ML mean + 1.96stdErr =  %.2f',(mlmean+1.96*mlstderr));
%     str_mms = sprintf('ML mean - 1.96stdErr =  %.2f',(mlmean-1.96*mlstderr));
%     str_prior = sprintf('SABL, prior ~ Normal(%.2f, %.2f^2)',priorMean,priorStd);
%     if P.useFryer
%         legend(['Fryer ' str_prior], ['Rational ' str_m], ['Rational ' str_mps], ['Rational ' str_mms],'Location','NorthOutside');        
%     else
%         legend(['Rational ' str_prior], ['Rational ' str_m], ['Rational ' str_mps], ['Rational ' str_mms],'Location','NorthOutside');
%     end
    aax.YTickLabel = '';
end
resdir = varargin{1};
chartname(chartname == '\') = '';
xname(xname == '\') = '';
print(ff,[resdir '/' chartname ':' xname '.png'],'-dpng');
end