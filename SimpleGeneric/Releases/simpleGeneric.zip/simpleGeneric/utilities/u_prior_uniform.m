function logp = u_prior_uniform(theta, prior)
%  Evaluate the log pdf of the uniform density function
%
%  Inputs:
%  theta     Points of evaluation (particles); theta = x   (C.JNwork x 1)
%  prior     Prior structure created by u_prior_uniformsetup
%
%  Output:
%  logp      Log prior density corresponding to theta  (C.JNwork x 1)

trans = @(x) x;

[JN, k] = size(theta);
bounds = true(JN, 1);
logp = -inf(JN, 1);
for i = 1:k
    bounds = bounds & theta(:,i) >= prior.endpoints(i,1) & ...
        theta(:,i) <= prior.endpoints(i,2);
end
if prior.simple
    logp(bounds) = prior.lognormconst;
%     disp('here1');  disp(size(logp)); disp(size(theta))
    
else
    logp = u_priormixcont(theta, prior, @u_prior_uniform, trans, trans);
%     disp('here2');  disp(size(logp))
end

end