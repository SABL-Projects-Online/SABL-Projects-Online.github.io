function logp = u_prior_gamma(theta, prior)
%  Evaluate the log pdf of the gamma prior distribution
%  p(x) = [x^(shape-1) * exp(-x/scale)] / [gamma(shape)*scale^shape].
%  The algorithm parameter theta = log(x), so the function incorporates
%  the Jacobian of transformation and returns
%  log[p(theta)] = log[p(exp(theta)] + theta.
%
%  Inputs:
%  theta     Points of evaluation (particles); theta = log(x)   
%                                                            (C.JNwork x 1)
%  prior     Prior structure created by u_prior_gammasetup
%
%  Output:
%  logp      Log prior density corresponding to theta (C.JNwork x 1) 

if prior.simple
    logp = prior.lognormconst + prior.shape*theta ...
        - exp(theta)/prior.scale;
else
    logp = u_priormixcont(theta, prior, @u_prior_gamma, @log, @exp);
    
end

end