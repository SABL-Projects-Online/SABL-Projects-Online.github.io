function fullpath = u_searchdirin(hay, needle)
%  Search if model is provided in a SABL copy at root.
%
%  Inputs:
%  hay 	     Name of directory that restricts the scope of search. 
%  needle    Character string that is either the lowest level directory 
%            of a full path or empty.
%
%  Output:
%  fullpath	 Full path pointing to where needle has been found. 
%            Empty string if needle is not found.

if 7 ~= exist(hay, 'dir') || isempty(needle) || ~ischar(needle) ...
	|| isempty(regexp(needle, '[a-zA-Z]+')) || ...
    ~isempty(regexp(needle, filesep))
    fullpath = '';
else
    [~, hayinfo] = fileattrib(hay);% hayinfo.Name: absolute path of hay

    b=regexp(genpath(hayinfo.Name),...
        [pathsep '(?<wantedpart>[^' pathsep ']*)' needle pathsep], ...
        'names'); 
    if 1 > length(b)
	    % needle is not found under hayinfo
	    fullpath = '';
    elseif 1 < length(b)
        if 1 == size(b,1)
            b = b';
        end
        fullpath = cell(size(b));
        for i = 1:length(fullpath)
            fullpath{i} = [b(i).wantedpart needle];
        end
    else
	    % 1 = length(b)
	    fullpath = [b.wantedpart needle];
    end

end

end