function u_rmskeleton(rootdir, recoverable)
% Remove a directory and its subdirectories from MATLAB's path.
%
% Inputs
%   rootdir       - string, the highest level directory to be removed.
%   recoverable   - boolean, whether the subdirectory 'utilities' gets
%                   removed, too. 'Utilities' contains utility functions,
%                   particularly u_getsablroot.m and u_install.m, which are
%                   required to recover SABL installation.
%                   
if isempty(rootdir)
    return;
end

if ~ischar(rootdir)
    return;
end

if 7~=exist(rootdir, 'dir')
    return;
end

[~, fileinfo] = fileattrib(rootdir);
rootdirabs = fileinfo.Name; % absolute path of rootdir
u_rmdir(rootdirabs);


lst = dir(rootdirabs);
for i = 1:length(lst)
    switch lst(i).name
        case '.'
            % do nothing
        case '..'
            % do nothing
        case 'utilities'
            if recoverable
                % do nothing
                lst2 = dir(fullfile(rootdirabs,lst(i).name));
                for j = 1:length(lst2)
                    switch lst2(j).name
                        case '.'
                            % do nothing
                        case '..'
                            % do nothing
                        case 'utilities'
                            % do nothing
                        otherwise
                            u_rmskeleton(fullfile(rootdirabs, ...
                                lst(i).name,lst2(j).name), false);
                    end
                end
                clear lst2
            else
                u_rmskeleton(fullfile(rootdirabs,lst(i).name), false);
            end
        otherwise
            u_rmskeleton(fullfile(rootdirabs,lst(i).name), false);
    end
end

end