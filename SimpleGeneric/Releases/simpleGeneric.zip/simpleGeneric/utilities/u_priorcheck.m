function struc = u_priorcheck(struc_in, strucname, defaultfield, ...
    columns, priorentry, ktheta, varargin)
%  Check the specification of a defualt prior field in a model. Terminate
%  if errors and otherwise set into a cell of struc.prior.
%
%  Inputs:
%  struc_in      Structure containng the fields (strucname) and the cell
%                array prior; typically M
%  strucname     Name of structure, for error messages (string)
%  defaultfield  Field with the default prior, e.g. M.betaprior
%  columns       Default columns of theta to which the prior applies,
%                if not already in struc.(defaultfield).columns
%  priorentry    The entry of the cell array struc.prior that is the
%                destination for the default prior
%  ktheta        Maximum permissible entry in columns
%  varagin       A cell array with the admissible prior names (e.g.,
%                'linear', 'Wishart', etc.) for the default prior
%
%  Output:
%  struc         The structure with the addition of struc.prior{priorentry}
%                and possibly struc.(defaultfield).columns

struc = struc_in;

    u_isfield(struc, defaultfield, true, strucname);
    priorstruc = struc.(defaultfield);
    priorname = sprintf('%s.%s', strucname, defaultfield);
    u_isfield(priorstruc, 'name', true, ...
        sprintf('%s.%s', priorname, defaultfield));
    if ~strcmp(priorstruc.name, varargin)
        error('Prior %s.%s.name = %s not permitted', ...
            strucname, defaultfield, priorstruc.name)
    end
    if ~u_isfield(priorstruc, 'columns')
        priorstruc.columns = columns;
        field = sprintf('%s.%s', priorname, 'columns');
        u_is('distinctpositiveintegers', field, priorstruc.columns)
        if max(priorstruc.columns) > ktheta
            error('One or more entries in %s too large', field)
        end
    end
    struc.prior{priorentry} = priorstruc;
end
