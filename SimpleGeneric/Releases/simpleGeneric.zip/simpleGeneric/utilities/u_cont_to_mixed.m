function x = u_cont_to_mixed(xstar, mvector, rvector, svector)
%  Convert the continuous form of the random variables to their mixed
%  discrete-continuous form.  This is the function f with reference to
%  the notes.
%
%  Inputs:
%  xstar      Continuous random variables (JN x 1)
%  mvector    Discrete mass points (n x 1)
%  rvector    Vector r with reference to the notes in this section
%  svector    Vector s with reference to the notes in this section 
%
%  Output:
%  x         Mixed continuous-discrete random vector

x = xstar;
n = length(mvector);
for j = 1:n
    ii = find(xstar > rvector(j) & xstar <= svector(j));
    if ~isempty(ii)
        x(ii) = mvector(j);
    end
    if j < n
        ii = find(xstar > svector(j) & xstar < rvector(j+1));
    else
        ii = find(xstar > svector(j));
    end
    if ~isempty(ii)
        x(ii) = xstar(ii) + mvector(j) - svector(j);
    end
end

end