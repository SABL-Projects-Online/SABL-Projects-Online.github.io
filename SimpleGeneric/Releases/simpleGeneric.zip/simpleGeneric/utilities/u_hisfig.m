function u_hisfig(data,bins,chartname,xname,varargin)
%% Histogram distribution plot
global P
% ff = figure(1);
ff = figure();
        
priorMean = 0;
priorStd = 5;
% priorMean = 2;
% priorStd = 1;
if (length(varargin)>3)
    priorMean = varargin{4};
    priorStd  = varargin{5};
end
% clf(ff);
hold on;
histogram(data,bins,'Normalization','pdf');
title(chartname);
xlabel(xname);
ylabel('Probability Density');

rra = ceil(max(data)-min(data));
plot(-(0.5*rra):(rra/100):(0.5*rra),normpdf(-(0.5*rra):(rra/100):(0.5*rra),priorMean,priorStd));
% [~,hce,~] = histcounts(data,bins);
% plot(normpdf(real(hce),priorMean,priorStd));


yyaxis right; 
aax = gca;
aax.YTickLabel = '';
if (length(varargin)>1)
    mlmean = varargin{2};
    mlstderr = varargin{3};


    if ~isempty(mlmean)
        str_m = sprintf('Rational ML mean =  %.2f',mlmean);    
    else
        str_m = [];
    end
    
    if (~isempty(mlmean)&&~isempty(mlstderr))
        str_mps = sprintf('Rational ML mean + 1.96stdErr =  %.2f',(mlmean+1.96*mlstderr));    
        str_mms = sprintf('Rational ML mean - 1.96stdErr =  %.2f',(mlmean-1.96*mlstderr));
        plot([mlmean mlmean],[0 1],':',[(mlmean+1.96*mlstderr) (mlmean+1.96*mlstderr)],[0 1],':',[(mlmean-1.96*mlstderr) (mlmean-1.96*mlstderr)],[0 1],':');
    else
        str_mps = [];
        str_mms = [];
    end
    
    str_prior = sprintf('SABL, prior ~ Normal(%.2f, %.2f^2)',priorMean,priorStd);
    
    if P.useFryer
            if (~isempty(mlmean)&&~isempty(mlstderr))
                legend(['Fryer ' str_prior], str_m, str_mps, str_mms,'Location','NorthOutside');        
            else
                legend(['Fryer ' str_prior],'Location','NorthOutside'); 
            end
    else
            if (~isempty(mlmean)&&~isempty(mlstderr))
                legend(['Rational ' str_prior], str_m, str_mps, str_mms,'Location','NorthOutside');
            else
                legend(['Rational ' str_prior],'Location','NorthOutside');
            end
    end

end
resdir = varargin{1};
chartname(chartname == '\') = '';
chartname(chartname == '^') = '';
xname(xname == '\') = '';
xname(xname == '^') = '';
print(ff,[resdir '/' chartname ':' xname '.png'],'-dpng');
hold off;
% clf(ff);
end