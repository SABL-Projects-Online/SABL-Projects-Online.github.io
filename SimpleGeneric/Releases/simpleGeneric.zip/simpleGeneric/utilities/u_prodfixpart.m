function [C, Cmap] = u_prodfixpart(A, B, Bmap)
%  Compute C = A*B, A in conventional matrix format, B in short
%  matrix-particle format and C in compact short matrix-particle format
%
%  Inputs:
%  A          Matrix A  (n x m)
%  B, Bmap    Matrix B in short matrix-particle format
%
%  Outputs:
%  C, Cmap    Matrix C in compact short matrix-particle format
%
%  The outputs may occupy the same location as any of the inputs in the
%  invoking function.

[n, m] = size(A);
k = size(Bmap, 2);
JN = size(B, 1);

Cmaplocal = zeros(n, k);
Aflag = A~=0;
Cflag = logical(double(Aflag)*double(Bmap>0));
Clocal = zeros(JN, sum(sum(Cflag)));
s = 0;
for j = 1:k
    for i = 1:n
        if Cflag(i,j)
            s = s + 1;
            Cmaplocal(i,j) = s;
            for h = 1:m
                if Aflag(i,h) && Bmap(h,j)>0
                    Clocal(:,s) = Clocal(:,s) + B(:,Bmap(h,j))*A(i,h);
                end
            end
        end
    end
end

C = Clocal;
Cmap = Cmaplocal;

end