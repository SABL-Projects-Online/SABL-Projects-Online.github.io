function [tstatout,pstatout] = u_pdfcheck(x,pdf,display)
%  Test the hypothesis that a random sample of vectors was in fact 
%  generated from a given pdf.  This implementation of the test requires 
%  that the support of the pdf is k-dimensional Euclidean space.  It uses
%  9 alternative truncation points of the multivariate normal pdf f(x).
%  Reference: Theorem 8.1.2 in Geweke J (2005) Contemporary Bayesian
%             Econometrics and Statistics
%  Function is designed for use with CPU, 1 worker.
%
%  Inputs:
%  x         Sample (size N) of random vectors (each k x 1)  (N x k matrix)
%  pdf       Corresponding evaluations of the pdf;  N x 1 vector
%  display   If true then display the results of the tests
%
%  Outputs (both optional):
%  tstatout  Test statistics (1 x 9)
%  pstatout  F(tstat) where F( ) is the c.d.f. of the test statistic
%            conditional on the hypothesis that the code for evaluating
%            the pdf and simulating from the corresponding density are
%            logically consistent.  (1 x 9)

[N k] = size(x);
mu = mean(x);  
V = cov(x);
f = mvnpdf(x,mu,V);
p = linspace(.1,.9,9);
cut = ((2*pi)^(-0.5*k)) * (det(V)^(-0.5)) * exp(-0.5*chi2inv(p,k));
f1 = f*ones(1,9);
v = (f1.*(f1>ones(N,1)*cut)) ./ (pdf*ones(1,9))-ones(N,1)*p;
tstat = u_setdatatype(sqrt(N)*mean(v)./std(v), 'cpu');
pstat = tcdf(tstat,N-1);
if display
    fprintf('  Test of consistency between pdf and simulation\n')
    fprintf('       Simulation size %d, %d dimensions\n', N, k)
    fprintf(' Truncation    Test statistic    Evaluated at cdf of t(%d)\n',...
        N-1)
    for i=1:9
        fprintf('%7.1f %18.4f  %19.4f\n',p(i),tstat(i),pstat(i))
    end
end
if nargout>0
    tstatout = tstat;
end
if nargout>1
    pstatout = pstat;
end
end
