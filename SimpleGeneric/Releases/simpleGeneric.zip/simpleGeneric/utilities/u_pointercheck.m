function u_pointercheck(struc, strucname, maxentry, varargin)
%  Check the existence and specification of a set of pointer fields in a
%  structure.
%
%  Inputs:
%  struc      Structure
%  strucname  Name of structure for error messages (string)
%  maxentry   Larges permissible value in any pointerfield
%  varargin   A sequence of pairs (field name of pointer, maximum length)
%
%  Output:    Terminates with error message if any field does not exist,
%             if the contents of any field are not correctly specified,
%             or if the fields overlap.  (If overlaps between certain
%             pairs of fields are permitted, invoke u_pointercheck several
%             times as required.)

nfields = length(varargin)/2;
if nfields ~= round(nfields)
    error('Number of input arguments is invalid')
end

m = 1;
vectors = cell(nfields, 1);
for i = 1:nfields
    title = varargin{m};
    maxlength = varargin{m+1};
    u_isfield(struc, title, true, strucname);
    a = struc.(title);
    na = length(a);
    vectors{i} = a;
    if max(a) > maxentry
        error('The entry %d in %s.%s exceeds the permissible maximum %d', ...
            max(a), strucname, title, maxentry)
    end
    if na > maxlength
        error('length(%s.%s) = %d exceeds the maximum %d', ...
            strucname, title, na, maxlength)
    end
    if na == 1
        u_is('positiveinteger', sprintf('%s.%s', strucname, title), a)
    else
        u_is('distinctpositiveintegers', ...
            sprintf('%s.%s', strucname, title), a)
    end
    for j = 1:i-1
        if ~isempty(intersect(a, vectors{j}))
            error('The pointers %s.%s and %s.%s overlap', ...
                strucname, varargin{2*j-1}, strucname, title)
        end
    end
    m = m + 2;
end

end