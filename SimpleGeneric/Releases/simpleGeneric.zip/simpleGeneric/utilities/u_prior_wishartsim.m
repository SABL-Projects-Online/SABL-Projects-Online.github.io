% function theta = u_prior_wishartsim(nsim, sigma, index, df, theta_in)
function theta = u_prior_wishartsim(nsim, prior)
%  Simulate the positive definite matrix from the Wishart prior 
%  distribution and compute its Choleski decomposition C: C'C = A,
%  C upper triangular with positive diagonal elements. Logs of diagonal
%  elements, and the non-diagonal elements themselves, are returned. They
%  are in row-major order of C, omitting the below-diagonal elements that
%  are identically zero.
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior     Prior structure created by u_prior_gammasetup
%
%  Output:
%  theta     Simulated random variables

theta = zeros(nsim, prior.n*(prior.n+1)/2);
D = chol(prior.var);

for jn = 1:nsim
    C = chol(wishrnd(prior.var, prior.df, D));
    C(1:prior.n+1:prior.n^2) = log(C(1:prior.n+1:prior.n^2));
    Cp = C';
    theta(jn,:) = Cp(Cp~=0);
end

end