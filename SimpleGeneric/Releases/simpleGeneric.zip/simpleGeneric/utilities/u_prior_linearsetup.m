function prior = u_prior_linearsetup(prior_in)
%  Map alternative specifications of a linear prior distribution function 
%  into a standard specification. Set up handling of optional inequality
%  constraints and/or optional mixed distribution.  Check for specification
%  errors. This is done by means of adding fields to the prior
%  specification structure provided by the user.
%  
%  Input:
%  prior_in          Structure expressing the prior distribution:
%  .mean, .variance  Mean vector and variance matrix; OR,
%  .mean, .precision Mean vector and precision matrix; OR,
%  .mean, .std       Mean vector and standard deviation vector; OR,
%  .r, .R, .std      R*theta - r (R nonsingular) has mean zero, mutually
%                    independent with standard deviations prior.std
%    .df             Degrees of freedom parameter.  Optional: Ignored if 
%                    prior.distribution = 'normal')
%    .constraints    Structure expressing r constraints a <= D*theta <= b
%                    Structure present and non-empty only if constraints
%      .a            a vector (-inf entries OK)  (r x 1)
%      .b            b vector (+inf entries OK)  (r x 1)
%      .D            D matrix with rank(D) = r  (r x n)
%    .mixed          Structure expressing mixed continuous-discrete 
%                    distribution.  Limited to the case n = 1.  Structure 
%                    present and non-empty only if the prior distribution
%                    is mixed
%      .mvector      Mass points of the distrbution (d x 1)
%      .pvector      Probabilities of the mass points (d x 1)
%
%  Output:
%  prior            Structure expressing the prior distribution. The 
%                   s  following fields are added:
%    .name          'linear'
%    .mean          Location parameter vector (n x 1)
%    .var           Prior scale matrix (n x n)
%    .prec          Prior precision matrix (n x n)
%    .varchol       Upper triangular Choleski factor C, C'*C = prior.var
%    .precchol      Upper triangular Choleski factor C, C'*C = prior.prec
%                   ... If there are constraints the preceding 5 fields
%                   pertain to prior.constraints.D*theta, not D
%    .n             Order of the distribution
%    .npars         Number of parameters to which the distribution applies
%    .normal        Indicator for normal distribution (else Student-t)
%    .lognormconst  Log of prior density normalizing constant
%    .df            Degrees of freedom parameter (Student-t only)
%    .power         Exponent in prior density (Student-t only)
%    .con           Indicator for constraints
%    .mix           Indicator for mixed distribution
%    .constraints   See function u_constraintssetup    
%    .mixed         See function u_mixedsetup

trans = @(x) x;

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'linear';

if isfield(prior, 'mean') && isfield(prior, 'variance')
    u_is('realfinite', 'Linear prior distribution mean', prior.mean)
    u_is('positive_definite', 'Distribution variance', prior.variance)
    prior.n = length(prior.mean);
    if any(size(prior.mean) ~= [prior.n, 1]) || ...
            any(size(prior.variance) ~= [prior.n, prior.n])
        error('prior.mean is %d x %d, prior.variance is %d x %d', ...
            size(prior.mean), size(prior.variance))
    end
    prior.var = prior.variance;
    prior.prec = inv(prior.var);
    
elseif isfield(prior, 'mean') && isfield(prior, 'precision')
    u_is('realfinite', 'Linear prior distribution mean', prior.mean)
    u_is('positive_definite', 'Distribution precision', prior.precision)
    prior.n = length(prior.mean);
    if any(size(prior.mean) ~= [prior.n, 1]) || ...
            any(size(prior.precision) ~= [prior.n, prior.n])
        error('prior.mean is %d x %d, prior.precision is %d x %d', ...
            size(prior.mean), size(prior.precision))
    end
    prior.prec = prior.precision;
    prior.var = inv(prior.prec);
    
elseif isfield(prior, 'mean') && isfield(prior, 'std')
    u_is('realfinite', 'Linear prior distribution mean', prior.mean)
    u_is('positivereal', 'Distribution std', prior.std)
    prior.n = length(prior.mean);
    if any(size(prior.mean) ~= [prior.n, 1]) || ...
            any(size(prior.std) ~= [prior.n, 1])
        error('prior.mean is %d x %d, prior.std is %d x %d', ...
            size(prior.mean), size(prior.std))
    end
    prior.var = diag(prior.std.^2);
    prior.prec = diag(prior.std.^-2);
    
elseif isfield(prior, 'r') && isfield(prior, 'R') && isfield(prior, 'std')
    u_is('realfinite', 'r vector', prior.r)
    u_is('realfinite', 'R matrix', prior.R)
    u_isfield(prior, 'std', true, 'prior')
    u_is('positivereal', 'std vector', prior.std)
    prior.n = length(prior.r);
    if any(size(prior.r) ~= [prior.n, 1]) || ...
            any(size(prior.R) ~= [prior.n, prior.n]) || ...
            any(size(prior.std) ~= [prior.n, 1])
        error('prior.mean is %d x %d, prior.R is %d x %d, prior.std is %d x %d',  ...
            size(prior.r), size(prior.R), size(prior.std))
    end
    if rank(prior.R) < prior.n
        error('Linear combinations matrix prior.R is singular')
    end
    Rinv = prior.R\eye(prior.n);
    prior.mean = Rinv*prior.r;
    prior.var = (Rinv*diag(prior.std.^2)*Rinv');
    prior.prec = inv(prior.var);
else
    error('No valid combinations of prior hyperparameter fields')
end
prior.npars = prior.n;
prior.varchol = chol(prior.var);
prior.precchol = chol(prior.prec);
if ~isfield(prior, 'df')
    prior.df = inf;
end
logdet = sum(log(diag(prior.precchol)));
prior.normal = isinf(prior.df);
if prior.normal
    prior.lognormconst = -0.5*prior.n*log(2*pi) + logdet;
else
    prior.power = -0.5*(prior.df + prior.n);
    prior.lognormconst = gammaln(0.5*(prior.df + prior.n)) + logdet - ...
        gammaln(0.5*prior.df) - 0.5*prior.n*(log(prior.df)+log(pi));
end
        
prior = u_constraintssetup(prior);

prior = u_mixedsetup(prior, @u_prior_linear, trans);

if prior.mix && prior.con
    z = prior.constraints.D*prior.mixed.mass;
    if any(z < prior.constraints.a || z > prior.constraints.b)
        error('Mixed distribution mass points violate constraints')
    end
end

prior.simple = ~(prior.con || prior.mix);

end