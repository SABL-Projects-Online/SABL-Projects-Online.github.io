function sortedcellarray = u_sortcellarray(unsortedcellarray, tosortagainst)
%  Sort cell array containing strings according to cell array of strings 
%  "tosortagainst". This function is mainly used to place 
%  updates_* directories in precedence order, it can also be used in other 
%  occasions.
%
%  Inputs:
%  unsortedcellarray    Cell array containing strings to sort. Only the 
%                       strings that are also in tosortagainst are being 
%                       sorted and placed in the slots they originally 
%                       occupy. Other strings are left intact.
%  tosortagainst	    Cell array containing strings in desired order. 
%
%  Output:
%  sortedcellarraya     Sorted version of unsortedcellarray with those 
%                       strings also in tosortagainst placed in desired 
%                       order.x

sortedcellarray = unsortedcellarray;
unsorted = [];
for i = 1:length(tosortagainst)        
    found = find(~cellfun(@isempty, regexp(unsortedcellarray,tosortagainst(i),'once')));    
    if ~isempty(found)
        unsorted_size = size(unsorted,1);
        unsorted(unsorted_size+1,:) = [unsorted_size+1 found];
    end
end

sorted = sort(unsorted(:,2));
sortedcellarray(sorted(unsorted(:,1))) = sortedcellarray(unsorted(:,2));

end
