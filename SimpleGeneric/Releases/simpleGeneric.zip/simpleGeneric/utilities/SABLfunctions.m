function SABLfunctions
%  SABL draws on a substantial library of utilities functions, all in
%  the utilities subdirectory of the SABL toolbox and with file names u_*.
%  Many of these functions replicate Matlab functions and expressions so as
%  to handle complications due to
%    (1) using CPU or GPU
%    (2) using one or several workers
%    (3) encountering underflow or overflow
%  internally in a manner that requires little additional logic or
%  computation in the invoking function. 
%
%  Array manipulation
%    SABL function    Matlab function/expression(s) replaced
%    u_allocate       ones, zeros, rand, randn
%    u_gcat           gcat
%    u_setdatatype    gather, GPUarray
%
%  Matrix arithmetic
%    SABL function    Matlab function/expression(s) replaced
%    u_gplus          gplus
%    u_logmeanlog     log(mean(exp(logx, dim)))
%    u_logmomlog      log(mean(exp(logx), dim)), log(var(exp(logx, [], dim)))
%    u_logsumlog      log(sum(exp(logx, dim)))
%    u_max            max
%    u_mean           mean
%    u_min            min              
%    u_mvmom          mean, cov
%    u_std            std
%    u_sum            sum
%
%  Management
%    SABL function    Matlab function/expression(s) replaced
%    u_islab1         labindex == 1, independent of Parallel Toolbox
%    u_numlabs        numlabs, independent of Parallel Toolbox
%
%  Some SABL utility functions handle computations specific to the SABL
%  algorithm, handling otherwise awkward details of CPU vs GPU and single-
%  worker vs. multiple-worker environments in a transparent fashion.  They
%  can similarly make ancillary user computations more convenient. These
%  include:
%  u_nse             Numerical standard error
%  u_rne             Relative numerical efficiency
%
%  Two functions that are useful in checking user- or modeller-contributed
%  custom priors, and model contributions from moddelers, are:
%  u_pfcheck         Test consistency of simulation from a discrete 
%                    distribution and evaluation of its probability
%                    function
%  u_pdfcheck        Test consistency of simulation from a continuous 
%                    distribution and evaluation of its probability
%                    density function
