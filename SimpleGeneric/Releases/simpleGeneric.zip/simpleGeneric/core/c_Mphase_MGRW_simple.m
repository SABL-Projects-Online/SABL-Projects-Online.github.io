function c_Mphase_MGRW_simple(stage)
%  Execute the M phase MGRW_simple algorithm
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C Cpar E M

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    %  Fill missing fields with default values
    if ~isfield(C.Mphase, 'step_initial')
        C.Mphase.step_initial = 0.5;
    end
    if ~isfield(C.Mphase, 'step_lower')
        C.Mphase.step_lower = 0.1;
    end
    if ~isfield(C.Mphase, 'step_upper')
        C.Mphase.step_upper = 2.0;
    end
    if ~isfield(C.Mphase, 'step_inc')
        C.Mphase.step_inc = 0.1;
    end
    if ~isfield(C.Mphase, 'acceptgoal')
        C.Mphase.acceptgoal = 0.25;
    end
    if ~isfield(C.Mphase, 'groups')
        C.Mphase.groups = 1;
    end
    %  ------------------
    if ~isfield(C.detail, 'startupM')
        C.detail.startupM = C.detail_level >= 2;
    end
    if ~isfield(C.detail, 'whileMphase')
        C.detail.whileMphase = C.detail_level >= 8;
    end
    if ~isfield(C.detail, 'endMphase')
        C.detail.endMphase = C.detail_level >= 6 && C.detail_level < 8;
    end
    
    C.Mphase.step = C.Mphase.step_initial;
    
    if C.passone
        fprintf('\nM phase MGRW_simple algorithm\n')
        f1 = '   Initial step size (C.Mphase.step_initial) = %5.3f\n';
            fprintf(f1, C.Mphase.step_initial)
            f1 = '     Minimum step size (C.Mphase.step_lower) = %5.3f\n';
            fprintf(f1, C.Mphase.step_lower)
            f1 = '     Maximum step size (C.Mphase.step_upper) = %5.3f\n';
            fprintf(f1, C.Mphase.step_upper)
            f1 = '   Step size increment (C.Mphase.step_upper) = %5.3f\n';
            fprintf(f1, C.Mphase.step_inc)
            f1 = 'Acceptance rate target (C.Mphase.acceptgoal) = %5.3f\n';
            fprintf(f1 , C.Mphase.acceptgoal)
        if C.twopass
            C.sigma_factor_store = u_allocate(...
                [C.parameters, C.parameters, 1]);
	    C.sfs_tail = 0;
        end
    end

elseif strcmp(stage, 'startMphase') && strcmp(C.stagestep, 'premonitor')
    if C.nstates > 0
        [Cpar.logp, Cpar.states_out] = ...
            u_message(Cpar.theta, C.intensity, Cpar.states_in);
    else
        Cpar.logp = u_message(Cpar.theta, C.intensity);
    end
    Cpar.logp = Cpar.logp + u_initial(Cpar.theta, M.prior);

elseif strcmp(stage, 'startMphase')
    if C.Mphase.groups == 1
        [~, sigma] = u_mvmom(Cpar.theta, 1, E.pus>1);
        C.Mphase.sigmafactor = chol(sigma);
    elseif C.Mphase.groups > 1
        C.Mphase.sigmafactors = ...
            zeros(C.parameters, C.parameters, C.Mphase.groups);
        group = kmeans(Cpar.theta, C.Mphase.groups);
        for j = 1:C.Mphase.groups
            V = cov(Cpar.theta(group==j,:));
            C.Mphase.sigmafactors(:,:,j) = chol(V);
        end
    end     
    if strcmp(C.stagestep, 'postmonitor') && C.detail.whileMphase && ...
        u_islab1
        fprintf('Cycle%5.0f  M phase iterations\n', C.cycle)
        fprintf('Iteration  Step size  Acceptance rate  Mean RNE\n')
    end

elseif strcmp(stage, 'whileMphase') && strcmp(C.stagestep, 'nomonitor')
    if C.passone
        if C.Mphase.groups == 1
            sigma_factor = C.Mphase.sigmafactor*sqrt(C.Mphase.step);
        else
            gfactor = mod(C.Mphase.total, C.Mphase.groups) + 1;
            sigma_factor = ...
                C.Mphase.sigmafactors(:,:,gfactor)*sqrt(C.Mphase.step);
        end
        if C.twopass
            sfs_size = size(C.sigma_factor_store,3); 
            if sfs_size <= C.sfs_tail 
                C.sigma_factor_store(:,:,sfs_size+1:2*sfs_size)  = ...
                    u_allocate(size(C.sigma_factor_store));
            end
	    clear sfs_size;
            C.sigma_factor_store(:,:,C.Mphase.total) = sigma_factor;
	    C.sfs_tail = C.sfs_tail + 1;
        end
    else
        sigma_factor = squeeze(C.sigma_factor_store(:,:,C.Mphase.total));
    end
    
    %  Draw the candidate particles and evaluate log-posteriors there.
    thetastar = Cpar.theta + ...
        u_allocate(size(Cpar.theta), 'default', 'randn')*sigma_factor;
    if C.nstates > 0
        %  Note that initial states cannot depend on theta:
        [logpstar, states_out] = ...
            u_message(thetastar, C.intensity, Cpar.states_in);
    else
        logpstar = u_message(thetastar, C.intensity);
    end
    logpstar = logpstar + u_initial(thetastar, M.prior);

    %  Execute the Metropolis accept/reject step.
    loguniforms = ...
       log(u_allocate([size(logpstar,1), 1], 'default', 'rand'));
    select = find(loguniforms < logpstar - Cpar.logp);
    Cpar.theta(select,:) = thetastar(select,:);
    Cpar.logp(select) = logpstar(select);
    if C.nstates > 0
        Cpar.states_out(select,:) = states_out(select,:);
    end
    C.Mphase.accept_rate = u_gplus(length(select))/C.JN;
    
    if C.detail.whileMphase
        C.Mphase.rne = mean(u_rne(m_rnefunctions(Cpar.theta), ...
            C.N, E.pus>1));
        if u_islab1
            fprintf('%9.0f  %9.3f  %15.4f  %8.4f\n',C.Mphase.count,...
                C.Mphase.step, C.Mphase.accept_rate, C.Mphase.rne)
        end
    end
    if C.passone
        if C.Mphase.accept_rate > C.Mphase.acceptgoal
            C.Mphase.step = ...
               min(C.Mphase.step + C.Mphase.step_inc, C.Mphase.step_upper);
        else
            C.Mphase.step = ...
               max(C.Mphase.step - C.Mphase.step_inc, C.Mphase.step_lower);
        end
    end
    
elseif strcmp(stage, 'endMphase') && strcmp(C.stagestep, 'postmonitor') ...
        && C.detail.endMphase
    C.Mphase.rne = mean(u_rne(m_rnefunctions(Cpar.theta), ...
                C.N, E.pus>1));
    if u_islab1
        fprintf('Cycle%5.0f Mphase:%4.0f iterations, mean RNE = %7.4f\n',...
            C.cycle, C.Mphase.count, C.Mphase.rne)
    end
    
end

end