function c_Mphase_MGRW_blocked(stage)
%  Execute the M phase MGRW_blocked algorithm
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C Cpar E M

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    %  Fill missing fields with default values
    if C.Mphase.groups > 1
        error('C.Mphase.groups > 1 not permitted with MGRW_blocked')
    end
    if C.parameters == 1
        error('C.parameters = 1, MGRW_blocked not applicable')
    end
    if isfield(C.Mphase, 'blocks')
        if ~iscell(C.Mphase.blocks)
            error('C.Mphase.blocks must be a cell array')
        end
        C.Mphase.nblocks = length(C.Mphase.blocks);
        j = 0;
        entries = zeros(C.parameters, 1);
        for i = 1:C.Mphase.nblocks
            if ~isreal(C.Mphase.blocks{i})
                error('C.Mphase.blocks{%d} not a real array', i)
            end
            newj = j + length(C.Mphase.blocks{i});
            entries(j+1:newj) = C.Mphase.blocks{i};
            j = newj;
        end
        if newj ~= C.parameters
            out1 = 'C.Mphase.blocks cell lengths sum to %d ';
            out2 = 'but C.parameters = %d';
            error([out1, out2], newj, C.parameters)
        end
        if length(unique(entries)) ~= C.parameters
            out1 = '%d unique entries in C.Mphase.blocks cells ';
            out2 = 'but C.parameters = %d';
            error([out1, out2], length(unique(entries)), C.parameters)
        end
    else
        if ~isfield(C.Mphase, 'nblocks')
            C.Mphase.nblocks = max(2, round(C.parameters/6));
        end
        C.Mphase.ranblock = true;
    end
    if ~isfield(C.Mphase, 'ranblock')
        C.Mphase.ranblock = false;
    end
 
    if ~isfield(C.Mphase, 'step_initial')
        C.Mphase.step_initial = repmat(0.5, C.Mphase.nblocks, 1);
    end
    if ~isfield(C.Mphase, 'step_lower')
        C.Mphase.step_lower = repmat(0.1, C.Mphase.nblocks, 1);
    end
    if ~isfield(C.Mphase, 'step_upper')
        C.Mphase.step_upper = repmat(5.0, C.Mphase.nblocks, 1);
    end
    if ~isfield(C.Mphase, 'step_inc')
        C.Mphase.step_inc = repmat(0.1, C.Mphase.nblocks, 1);
    end
    if ~isfield(C.Mphase, 'acceptgoal')
        C.Mphase.acceptgoal = repmat(0.50, C.Mphase.nblocks, 1);
    end
    
    if ~isfield(C.detail, 'startupM')
        C.detail.startupM = C.detail_level >= 2;
    end
    if ~isfield(C.detail, 'whileMphase')
        C.detail.whileMphase = C.detail_level >= 8;
    end
    if ~isfield(C.detail, 'endMphase')
        C.detail.endMphase = C.detail_level >= 6 && C.detail_level < 8;
    end
    C.Mphase.step = C.Mphase.step_initial;
    if C.passone
        fprintf('\nMphase MGRW_blocked algorithm\n')
        if C.Mphase.ranblock
            fprintf('Parameters randomly allocated across blocks\n')
            nlines = 1;
        else
            nlines = length(C.Mphase.blocks);
        end
        for j = 1:nlines
            if ~C.Mphase.ranblock
                if length(C.Mphase.blocks{j}) == 1
                    fprintf('Block %d, Parameter %d\n', j, ...
                        C.Mphase.blocks{j})
                else
                    fprintf('Block %d, Parameters %d %s\n', ...
                        j, sprintf('%4d', C.Mphase.blocks{j}))
                end
            end
            f1 = '   Initial step size (C.Mphase.step_initial) = %5.3f\n';
            fprintf(f1, C.Mphase.step_initial(j))
            f1 = '     Minimum step size (C.Mphase.step_lower) = %5.3f\n';
            fprintf(f1, C.Mphase.step_lower(j))
            f1 = '     Maximum step size (C.Mphase.step_upper) = %5.3f\n';
            fprintf(f1, C.Mphase.step_upper(j))
            f1 = '   Step size increment (C.Mphase.step_upper) = %5.3f\n';
            fprintf(f1, C.Mphase.step_inc(j))
            f1 = 'Acceptance rate target (C.Mphase.acceptgoal) = %5.3f\n';
            fprintf(f1 , C.Mphase.acceptgoal)
        end
        if C.twopass
            C.sigma_factor_store = u_allocate(...
                [C.parameters, C.parameters, 1]);
            C.sfs_tail = 0;
        end    
    end
    C.Mphase.iblock = 0;
    
elseif strcmp(stage, 'startMphase') && strcmp(C.stagestep, 'premonitor')
    if C.nstates > 0
        [Cpar.logp, Cpar.states_out] = ...
            u_message(Cpar.theta, C.intensity, Cpar.states_in);
    else
        Cpar.logp = u_message(Cpar.theta, C.intensity);
    end
    Cpar.logp = Cpar.logp + u_initial(Cpar.theta, M.prior);

elseif strcmp(stage, 'startMphase') && ...
        strcmp(C.stagestep, 'postmonitor') && C.passone && ...
        C.detail.whileMphase && u_islab1
    fprintf('\nCycle%5.0f  M phase iterations\n', C.cycle)
    f1 = 'Iteration  Block  Block size  Step size  ';
    f2 = 'Acceptance rate  Mean RNE\n';
    fprintf([f1, f2])
    
elseif strcmp(stage, 'whileMphase') && strcmp(C.stagestep,  'nomonitor')
    if C.passone
        nblocks = C.Mphase.nblocks;
        C.Mphase.iblock = mod(C.Mphase.iblock, nblocks) + 1;
        %  Computations at the start of the M phase
        if C.Mphase.iblock == 1 && C.Mphase.ranblock
            ii = randperm(C.parameters);
            cuts = linspace(0, C.parameters, nblocks + 1);
            list = 1:C.parameters;
            for j = 1:nblocks
                C.Mphase.blocks{j} = ii(list>cuts(j) & list <= cuts(j+1));
            end
            if E.pus > 1
                C.Mphase.blocks = labBroadcast(1, C.Mphase.blocks);
            end
            C.Mphase.step = repmat(mean(C.Mphase.step), nblocks, 1);
        end
        %  Computations in all steps of the M phase
        sigma_factor = u_allocate([C.parameters,C.parameters]);
        ii = C.Mphase.blocks{C.Mphase.iblock};
        [~, sigma] = u_mvmom(Cpar.theta(:,ii), 1, E.pus>1);
        sigma_factor(ii,ii) = chol(sigma*C.Mphase.step(C.Mphase.iblock));
        if C.twopass
	    sfs_size = size(C.sigma_factor_store,3); 
	    if sfs_size <= C.sfs_tail 
		C.sigma_factor_store(:,:,sfs_size+1:2*sfs_size) = ...
		    u_allocate(size(C.sigma_factor_store));
	    end
        clear sfs_size;
        C.sigma_factor_store(:,:,C.Mphase.total) = sigma_factor;
        C.sfs_tail = C.sfs_tail + 1;
        end
    else
        sigma_factor = squeeze(C.sigma_factor_store(:,:,C.Mphase.total));
    end
    %  Draw the candidate particles and evaluate log-posteriors there.
    thetastar = Cpar.theta + ...
        u_allocate(size(Cpar.theta), 'default', 'randn')*sigma_factor;
    if C.nstates > 0
        %  Note that initial states cannot depend on theta:
        [logpstar, states_out] = ...
            u_message(thetastar, C.intensity, Cpar.states_in);
    else
        logpstar = u_message(thetastar, C.intensity);
    end
    logpstar = logpstar + u_initial(thetastar, M.prior);

    loguniforms = ...
       log(u_allocate([size(logpstar,1), 1], 'default', 'rand'));
    select = find(loguniforms < logpstar - Cpar.logp);
    Cpar.theta(select,:) = thetastar(select,:);
    Cpar.logp(select) = logpstar(select);
    if C.nstates > 0
        Cpar.states_out(select,:) = states_out(select,:);
    end
    
    C.Mphase.accept_rate = u_gplus(length(select))/C.JN;
    if C.passone
        if C.detail.whileMphase
            rne = u_rne(m_rnefunctions(Cpar.theta), C.N, E.pus>1);
            C.Mphase.rne = mean(rne);
            if u_islab1
                fprintf('%9.0f  %5.0f  %10.0f  %9.3f  %15.4f  %8.4f\n', ...
                    C.Mphase.count, C.Mphase.iblock, ...
                    length(C.Mphase.blocks{C.Mphase.iblock}), ...
                    C.Mphase.step(C.Mphase.iblock), ...
                    C.Mphase.accept_rate, C.Mphase.rne)
            end
        end
        if C.Mphase.accept_rate > C.Mphase.acceptgoal(C.Mphase.iblock)
            C.Mphase.step(C.Mphase.iblock) = ...
               min(C.Mphase.step_upper(C.Mphase.iblock), ...
               C.Mphase.step(C.Mphase.iblock) + ...
               C.Mphase.step_inc(C.Mphase.iblock));
        else
            C.Mphase.step(C.Mphase.iblock) = ...
                max(C.Mphase.step_lower(C.Mphase.iblock), ...
                C.Mphase.step(C.Mphase.iblock) - ...
                C.Mphase.step_inc(C.Mphase.iblock));
        end
    end
    
elseif strcmp(stage, 'endMphase') && ...
        strcmp(C.stagestep, 'postmonitor') && C.detail.endMphase
    rne = u_rne(m_rnefunctions(Cpar.theta), C.N, E.pus>1);
    C.Mphase.rne = mean(rne);
    if u_islab1
        fprintf('Cycle%5.0f Mphase:%4.0f iterations, mean RNE = %7.4f\n',...
            C.cycle, C.Mphase.count, C.Mphase.rne)
    end

end

end