function c_sabl

global C Cpar M
    
if ~C.simget
    [Cpar.theta, M.prior] = u_initialsim(M.prior);
end

%  Stage initialize: everything that is done before moving through the
%  cycles of the SABL algorithm
c_monitor('initialize');
c_mpl('initialize');
C.cycle = 0;
C.Cphase.total = 0;
C.Mphase.total = 0;
C.moreinfo = true;

while C.moreinfo  %  For cycles of the SABL algorithm ---------------------
    C.cycle = C.cycle + 1;
    
    %  Stage startcycle: Provides the opportunity for computation
    %  at the start of each cycle; conceptually but not operationally
    %  distinct from stage startCphase
    c_monitor('startcycle');
	
    %  C phase --------------------------------
    Cpar.logw = u_allocate([C.JNwork,1]);
    
    %  Stage startCphase
    c_monitor('startCphase');
    c_Cphase('startCphase');
    c_mpl('startCphase');
    C.Cphase.count = 0;
    moreCsteps = true;
    
    while moreCsteps && C.moreinfo %  Iteration(s) of the C phase
        
        %  Stage whileCphase
        C.Cphase.total = C.Cphase.total + 1; 
        C.Cphase.count = C.Cphase.count + 1; 
        moreCsteps = c_Cphase('whileCphase');
        c_monitor('whileCphase');
        c_mpl('whileCphase');
    end
    
    %  Stage endCphase
    c_monitor('endCphase');
    
    %  S phase --------------------------------
    
    %  Stage startSphase
    c_monitor('startSphase');
    c_Sphase('startSphase');
    
    %  Stage endSphase
    c_monitor('endSphase');

    %  M phase --------------------------------
    
    %  Stage startMphase
    c_monitor('startMphase');
    C.Mphase.count = 0;
    moreMsteps = true;
    
    while moreMsteps  %  Iterations of the M phase
        
        %  Stage whileMphase
        C.Mphase.total = C.Mphase.total + 1;
        C.Mphase.count = C.Mphase.count + 1;
        moreMsteps = c_Mphase('whileMphase');
        c_monitor('whileMphase')
    end
    
    %  Stage endMphase
    c_monitor('endMphase');
    
end  %  -------------------------------------------------------------------

%  Stage finish: Provides the opportunity for computation required at the
%  end of pass one or pass two.
c_mpl('finish');
c_monitor('finish')
    
end
