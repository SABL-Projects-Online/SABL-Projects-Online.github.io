function moreMsteps = c_Mstop_rne(stage)
%  Execute the M phase stopping rule.
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm
%
%  Output:
%  moreMsteps Inicator for more steps in the M phase

global C Cpar E
persistent rne_criterion steps_criterion steps_store

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    %  Fields left unspecified by model/application set to default values:
    if ~isfield(C.Mstop, 'rne')
        C.Mstop.rne = 0.4;
    end
    if ~isfield(C.Mstop, 'steps')
        C.Mstop.steps = 100;
    end
    if ~isfield(C.Mstop, 'rne_end')
        C.Mstop.rne_end = 0.9;
    end
    if ~isfield(C.Mstop, 'steps_end')
        C.Mstop.steps_end = 3*C.Mstop.steps;
    end
    if ~isfield(C.Mstop, 'hybrid')
        C.Mstop.hybrid = false;
    end
    
    if strcmp(C.Mstop_method, 'steps')
        C.Mstop.rne = inf;
        C.Mstop.rne_end = inf;
    elseif strcmp(C.Mstop_method, 'RNE')
        C.Mstop.steps = inf;
        C.Mstop.steps_end = inf;
    elseif strcmp(C.Mstop_method, 'hybrid')
        C.Mstop.hybrid = true;
    elseif strcmp(C.Mstop_method, 'RNE&steps')
    else
        error('Unrecognized: C.Mstop_method = %s', C.Mstop_method)
    end
    
    if C.passone
        fprintf('\nM phase Mstop_rne stopping algorithm\n')
        if isfinite(C.Mstop.rne)
            f1 = '                  RNE criterion (C.Mstop.rne) = %5.3f\n';
            fprintf(f1, C.Mstop.rne)
        end
        if isfinite(C.Mstop.rne_end)
            f1 = '   Last cycle RNE criterion (C.Mstop.rne_end) = %5.3f\n';
            fprintf(f1, C.Mstop.rne_end)
        end
        if isfinite(C.Mstop.steps)
            f1 = '               Bound on steps (C.Mstop.steps) = %d\n';
            fprintf(f1, C.Mstop.steps)
        end
        if isfinite(C.Mstop.steps_end)
            f1 = 'Last cycle bound on steps (C.Mstop.steps_end) = %d\n';
            fprintf(f1, C.Mstop.steps_end)
        end
    end
    
elseif strcmp(stage, 'startMphase') && strcmp(C.stagestep, 'premonitor')
    if C.passone
        if C.moreinfo
            rne_criterion = C.Mstop.rne;
            steps_criterion = C.Mstop.steps;
        else
            rne_criterion = C.Mstop.rne_end;
            steps_criterion = C.Mstop.steps_end;
        end
    end

elseif strcmp(stage, 'whileMphase') && strcmp(C.stagestep, 'nomonitor')
    if C.passone
        g = m_rnefunctions(Cpar.theta);
        rne = mean(u_rne(g, C.N, E.pus>1));
        moreMsteps = rne < rne_criterion && ...
            C.Mphase.count < steps_criterion;
        %  Stop if rne not increasing rapidly enough with M iterations
        if moreMsteps && C.Mstop.hybrid
            moreMsteps = ...
                rne > rne_criterion*C.Mphase.count/steps_criterion;
        end
        if ~moreMsteps && C.twopass
            steps_store(C.cycle) = C.Mphase.count;
        end
    else
        moreMsteps = C.Mphase.count < steps_store(C.cycle);
    end

elseif strcmp(stage, 'finish') && strcmp(C.stagestep, 'premonitor')
    if C.twopass && C.passone
        steps_store = steps_store(1:C.cycle);
    end
end

end
