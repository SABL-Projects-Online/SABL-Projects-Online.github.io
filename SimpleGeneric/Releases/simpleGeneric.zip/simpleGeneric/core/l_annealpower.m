function rpower = l_annealpower(logw, ress, bound, crit, parallel)
%  Determine the power (inverse temperature) that corresponds to a
%  target realtive effective sample size.  The power is restricted
%  to the interval (0, bound).  If all powers in this interval correspond
%  to a relative effective sample size greater than the target then the
%  function returns bound.
%
%  Inputs: 
%  logw       Logs of weights (n x 1)
%  ress       Relative effective sample size target
%  bound      Upper bound on power
%  crit       Criterion for solution of nonlinear equation
%             (Positive; values < 1e-6 may be infeasible)
%
%  Output:
%  rpower      Power that guarantees ress, if one exists in (0, bound);
%             bound, if no such power exists

f = @(rpower, logw, ress) 2*u_logsumlog(rpower*logw, 1, parallel) ...
   - u_logsumlog(2*rpower*logw, 1, parallel) ...
   - log(u_gplus(length(logw))*ress);
    
if bound == inf
    upper = 2^(-5);
    while f(upper, logw, ress) > 0
        upper = 2*upper;
    end
else
    if f(bound, logw, ress)  >0
        rpower = bound;
        return;
    else
        upper = bound;
    end
end

powbelow = 0;
powabove = upper;
eps = 100*crit;
iter = 0;
while abs(eps) > crit && iter < 1000
    iter = iter+1;
    pow = 0.5*(powbelow + powabove);
    eps = f(pow, logw, ress);
    if eps > 0
        powbelow = pow;
    else
        powabove = pow;
    end
end
rpower = pow;

end