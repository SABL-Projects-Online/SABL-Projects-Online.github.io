function moreMsteps = c_Mstop_step_count(stage)
%  Use an M phase stopping criteron based on the number of steps taken
%  in this cycle, the relative effective sample size from the C phase,
%  and whether or not this is the terminal M phase of the algorithm.
%  This is the variant of the M phase stopping rule detailed in Durham
%  and Geweke (2015).
%
%  Inputs: All global
%
%  Output
%  moreMsteps  False if stopping criterion has been satsified, else true

global C
persistent nowsteps_store

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    %  Fields left unspecified by model/application set to default values:
    if ~isfield(C.Mstop, 'steps')
        C.Mstop.steps = 55;
    end
    if ~isfield(C.Mstop, 'ress_D1')
        C.Mstop.ress_D = 0.2;
    end
    if ~isfield(C.Mstop, 'ess_factor')
        C.Mstop.ess_factor = 3;
    end
    if ~isfield(C.Mstop, 'final_factor')
        C.Mstop.final_factor = 3;
    end
    fprintf('\nM phase Mstop_step count stopping algorithm\n')
    fprintf('             Bound on steps (C.Mstop.steps) = %5.3f\n', ...
        C.Mstop.steps)
    fprintf(' RESS threshold for factor (C.Mstop.ress_D) = %5.3f\n', ...
        C.Mstop.ress_D)
    fprintf('           RESS factor (C.Mstop.ess_factor) = %5.3f\n', ...
        C.Msstop.ess_factor)
    fprintf('  Final cycle factor (C.Mstop.final_factor) = %5.3f\n', ...
        C.Mstop.final_factor)
    if C.twopass
        nom_cycle_total = 100;
        nowsteps_store = u_allocate([nom_cycle_total, 1]);
    end
    
elseif strcmp(stage, 'startMphase') && strcmp(C.stagestep, 'premonitor')
    if C.passone
        factor = 1;
        if C.ress < C.Mstop.ress_D
            factor = C.Mstop.ess_factor;
        end
        if ~C.moreinfo
            factor = C.Mstop.final_factor;
        end
        C.Mstop.nowsteps = C.Mstop.steps*factor;
        if C.twopass
            nowsteps_store(C.cycle) = C.Mstop.nowsteps;
        end
    else
        C.Mstop.nowsteps = nowsteps_store(C.cycle);
    end
    
elseif strcmp(stage, 'whileMphase') && strcmp(C.stagestep, 'nomonitor')
    moreMsteps = C.Mphase.count < C.Mstop.nowsteps;

elseif strcmp(stage, 'finish') && strcmp(C.stagestep, 'premonitor')
   
end

end