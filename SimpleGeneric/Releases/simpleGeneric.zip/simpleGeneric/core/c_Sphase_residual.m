function count = c_Sphase_residual(w, n)
%  Execute the S phase using residual resampling
%  CHECK -- The following reference should come out of the code and
%  go in the manual:
%  Reference: Douc R, Cappe P. Moulines E (2005), Comparison of resampling
%  schemes for particle filtering.  4th International Symposium on Image 
%  and Signal Processing and Analysis
%  (http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.126.9118)
%
%  Inputs:
%  w       Weights of the sample (non-negative, positive sum)  (m x 1)
%  n       Size of unweighted sample
%
%  Output:
%  count   count(i) is the number of times the sample point with weight
%          w(i) is included in the unweighted sample of size n  (n x 1)

w = w/sum(w);
countbase = u_setdatatype(floor(n*w), 'cpu');

n1 = n - sum(countbase);
if n1 > 0
    count = countbase + c_Sphase_multinomial(w - countbase/n, n1);
else
    count = countbase;
end

end