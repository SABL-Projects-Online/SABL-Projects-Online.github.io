function moreMsteps = c_Mphase(stage)
%  Function manages the S phase
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C

%  Execute the specified M phase method.

if strcmp(C.Mphase_method, 'MGRW_simple')
    c_Mphase_MGRW_simple(stage);
    
elseif strcmp(C.Mphase_method, 'MGRW_blocked')
    c_Mphase_MGRW_blocked(stage);
    
elseif strcmp(C.Mphase_method, 'custom')
    p_Mphase_custom(stage);

else
    error('Unrecognized: C.Mphase_method = %s', C.Mphase_method)
end

%  Execute the specifed M phase stopping rule.

if strcmp(C.Mstop_method, 'RNE&steps');
    if strcmp(stage, 'whileMphase') && strcmp(C.stagestep, 'nomonitor')
            moreMsteps = c_Mstop_rne(stage);
    else
        c_Mstop_rne(stage);
    end
    
elseif strcmp(C.Mstop_method, 'custom');
    if strcmp(stage, 'whileMphase') && strcmp(C.stagestep, 'nomonitor')
        moreMsteps = p_Mstop_custom(stage);
    else
        p_Mstop_custom(stage);
    end
elseif strcmp(C.Mstop_method, 'steps')
    moreMsteps = (C.Mphase.count<C.Mstop.steps);
end