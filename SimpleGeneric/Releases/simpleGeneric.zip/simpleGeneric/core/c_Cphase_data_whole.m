function c_Cphase_data_whole(stage)
%  Eecute the C phase data_whole algorithm
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C Cpar E

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    %  Fill missing fields with default values
    if ~isfield(C.detail, 'startupC')
        C.detail.startupC = C.detail_level >= 2;
    end
    if ~isfield(C.detail, 'whileCphase')
        C.detail.whileCphase = C.detail_level >= 8;
    end
    if ~isfield(C.detail, 'endCphase')
        C.detail.endCphase = C.detail_level >= 6 && C.detail_level < 8;
    end
    %  Initializations
    C.mpl = true;
    C.logpl(C.tfirst:C.tlast,1) = ...
        u_allocate([C.tupdate, 1]);
    C.Cphase.t = C.tfirst - 1;

    if C.passone
        fprintf('\nCphase data_whole algorithm\n')
    end

elseif strcmp(stage, 'startCphase') && strcmp(C.stagestep, 'postmonitor')
    C.Cphase.logwsum = log(C.JN);
    if u_islab1 &&  C.detail.whileCphase
        fprintf('Cycle%5.0f  C phase iterations\n', C.cycle)
        fprintf('Iteration   Observation Log pred like    RESS\n')
    end
    
elseif strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
    %  Manage the observations and the intensity vector.
    C.Cphase.t = C.Cphase.t + 1;
    C.intensity = u_allocate([C.tlast,1], 'default');
    C.intensity(1:C.Cphase.t) = 1;
    intensity = u_allocate([C.tlast,1]);
    intensity(C.Cphase.t) = 1;
    
    %  The predictive density is the increment to the weights.
    if C.nstates > 0
        [Cpar.logpinc, Cpar.states_out] = ...
            u_message(Cpar.theta, intensity, Cpar.states_in);
        Cpar.states_in = Cpar.states_out;
    else
        Cpar.logpinc = u_message(Cpar.theta, intensity);
    end   
    
    %  Compute the new weights and the log predictive likelihood.
    logwnew = Cpar.logw + Cpar.logpinc;
    logwnewsum = u_logsumlog(logwnew, 1, E.pus>1);
    C.logpl(C.Cphase.t) = logwnewsum - C.Cphase.logwsum;
    Cpar.logw = logwnew;
    C.Cphase.logwsum = logwnewsum;
    w = exp(Cpar.logw - u_logsumlog(Cpar.logw, 1, (E.pus>1) ));
    
    %  Evaluate effective sample size now for subsequent use.
    ess = 1/u_sum(w.*w, 1, (E.pus>1));
    C.ress = ess/C.JN;
    
    %  Determine whether the sample is now exhausted.
    C.moreinfo = C.Cphase.t < C.tlast;
    if C.detail.whileCphase && u_islab1
        fprintf('%9.0f %13.0f %13.4f %7.4f\n', C.Cphase.count, ...
            sum(C.intensity), C.logpl(C.Cphase.t), C.ress)
    end
    
elseif strcmp(stage, 'endCphase') && strcmp(C.stagestep, 'postmonitor')
    if C.detail.endCphase  && u_islab1
	    fprintf('Cycle%5.0f Cphase:%4.0f steps to observation %d of %d, RESS%7.4f\n',...
            C.cycle, C.Cphase.count, sum(C.intensity), C.tlast, C.ress)
    end
    
end

end