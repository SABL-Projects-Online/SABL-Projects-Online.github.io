function c_mpl(stage)
%  Updating and boookkeeping for computation of log marginal likelihoods.  
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C Cpar E
persistent logwnmean2 oldlogml1 oldlogml2 oldlogmlnse

if ~C.mpl
    return
end

if strcmp(stage, 'initialize')
    logwnmean2 = u_allocate([C.Jwork, 1]);
    if C.simget
        oldlogml1 = C.logml1;
        oldlogml2 = C.logml2;
        oldlogmlnse = C.logmlnse;
    else
        oldlogml1 = 0;
        oldlogml2 = 0;
        oldlogmlnse = 0;
    end
    
elseif strcmp(stage, 'whileCphase')
    %  Log of mean particle weight in each of J groups after updating:
    logwnmean = u_logmeanlog(reshape(Cpar.logw, C.N, C.Jwork), 1, false);
                                                             %  1 x Jwork
    logwnmean2(:,C.cycle) = logwnmean';  %  Jwork x C.cycle
    
elseif strcmp(stage, 'finish')
    %  Compute first approximation of marginal likelihood ("w-bar"):
    elsumlogwnmean = sum(logwnmean2, 2)';  %  1 x Jwork
    [C.logml1, lognsecomponent] = u_logmomlog(elsumlogwnmean, 2, E.pus>1);
    %  Compute numerical standard error of both ML approximations:
    C.logmlnse = exp(0.5*lognsecomponent - C.logml1)/sqrt(C.J);
    C.logml1 = C.logml1 + oldlogml1;
    C.logmlnse = sqrt(C.logmlnse^2 + oldlogmlnse^2);
    %  Compute second approximation of marginal likelihood ("w-tilde"):
    C.logml2 = ...
         sum(u_logmeanlog(logwnmean2, 1, E.pus>1));
    C.logml2 = C.logml2 + oldlogml2;

end

end
