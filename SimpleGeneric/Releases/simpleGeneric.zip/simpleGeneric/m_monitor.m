function m_monitor(stage)
%  Execute monitoring functions specific to the normal model but not to
%  the project.
%
%  Intput:
%  stage        Current stage of the SABL algorithm

global C E M

p_monitor(stage);
  

end
