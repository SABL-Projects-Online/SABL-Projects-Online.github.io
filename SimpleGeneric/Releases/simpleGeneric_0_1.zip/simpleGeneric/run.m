clear all; close all;
global C P M Cpar E

%% SABL

if ~isdeployed
    eval(['addpath ' pwd '/core']);
    eval(['addpath ' pwd '/utilities']);
end
parpool(gpuDeviceCount);

%   Results directory

        outpath = 'SABL_results';
    
%   Enable GPUs

        P.useGpu = true;

%   Import CSV data

    % Provide your own data import and preparation function here...
    % Store the data as columns in the cell array: P.x{}
    % For this example I simply have 5 columns of random data
    % Columns 1:4 are the covariates, Column 5 is the outcome

        P.x{1} = rand(72,1);
        P.x{2} = rand(72,1);
        P.x{3} = rand(72,1);
        P.x{4} = rand(72,1);
        P.x{5} = randi([0 1],72,1); 

%   Data adjustments

    % Provide your own data transforms here    

%   Set up a model

    %
    % First logit
    %
        P.dataColumnsLogit1  = [1 3];
        P.thetaColumnsLogit1 = 1:length(P.dataColumnsLogit1);        
        cumulativeColumns    = P.thetaColumnsLogit1(end);
    % 
    % Second logit
    %
        P.dataColumnsLogit2  = [2 4];
        P.thetaColumnsLogit2 = cumulativeColumns + (1:length(P.dataColumnsLogit2));
        cumulativeColumns    = P.thetaColumnsLogit2(end);
    % 
    % Outcome
    %
        P.dataColumnsY = 5;
    %
    % Number of parameters
    %
        tableSize = cumulativeColumns;
    %
    % Prior distributions - assumed to be Normal
    %
        P.priorMeanStd.mean = zeros(tableSize,1);
        P.priorMeanStd.std  = 5*ones(tableSize,1);         
        P.priorMeanStd.columns = [1:tableSize]';
        
    %
    % Name the parameters
    %
        P.modelParameterNames = {...
                        'beta_1_1',...
                        'beta_1_2',...
                        'beta_2_1',... 
                        'beta_2_2',...
        };

        if isdir(outpath)
            fprintf('\n%s is the output storage directory - existing files in that directory will be overwritten.\n',...
                     outpath);
        else
            mkdir(outpath);
            fprintf('\n%s is the output storage directory and has been created as a new directory.\n',...
                     outpath);
        end
        
        diary([outpath '/summary.txt']);
        diary on;
        
    % Execute SABL
        SABL;

        diary off;
    
if ~isdeployed    
    eval(['rmpath ' pwd '/core']);
    eval(['rmpath ' pwd '/utilities']);
end
delete(gcp('nocreate'));
