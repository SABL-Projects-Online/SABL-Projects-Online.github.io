function [rvector, svector] = u_rscreate(mvector, pvector, kernel)
%  With reference to the notes in this section, create the vectors
%  r and s.
%
%  Inputs:
%  mvector   Mass points of the distrbution (n x 1)
%  pvector   Probabilities of the mass points (n x 1)
%  kernel    Evaluations of the continuous component kernel of the 
%            distribution at mvector (n x 1)
%
%  Outputs:
%  rvector   Vector r (n x 1)
%  svector   Vector s (n x 1)

n = length(mvector);
u_is('realfinite', 'mvector', mvector)
u_is('realfinite', 'pvector', pvector)
if any(pvector <= 0) || sum(pvector) > 1
    error('pvector = %s is not valid', num2str(pvector))
end
if length(unique(mvector)) < n
    warning('mvector = %s has duplicate entries', num2str(mvector))
end
    
rvector = zeros(n,1);
svector = zeros(n,1);
rvector(1) = mvector(1);
for j = 1:n
    if j > 1
        rvector(j) = svector(j-1) + mvector(j) - mvector(j-1);
    end
    svector(j) = rvector(j) + pvector(j)/kernel(j);
end