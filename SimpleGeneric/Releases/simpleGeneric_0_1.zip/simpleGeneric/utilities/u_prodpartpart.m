function [C, Cmap] = u_prodpartpart(array, Amap, Bmap)
%  Compute C = A*B, A and B in short matrix-particle format and C in
%  compact short matrix-particle format
%
%  Inputs:
%  array      Particle array in which A and B are located
%  Amap       (array, Amap) is A in short matrix-particle format
%  Bmap       (array, Bmap) is B in short matrix-particle format
%
%  Outputs:
%  C, Cmap    Matrix C in compact short matrix-particle format
%
%  The outputs may occupy the same location as any of the inputs in the
%  invoking function.

[n, m] = size(Amap);
k = size(Bmap, 2);
JN = size(array, 1);

Cmaplocal = zeros(n, k);

Cflag = Amap*Bmap>0;
Clocal = zeros(JN, sum(sum(Cflag)));
s = 0;
for j = 1:k
    for i = 1:n
        if Cflag(i,j)
            s = s + 1;
            Cmaplocal(i,j) = s;
            for h = 1:m
                if Amap(i,h)>0 && Bmap(h,j)>0
                    Clocal(:,s) = Clocal(:,s) + ...
                        array(:,Amap(i,h)).*array(:,Bmap(h,j));
                end
            end
        end
    end
end

C = Clocal;
Cmap = Cmaplocal;
   
end