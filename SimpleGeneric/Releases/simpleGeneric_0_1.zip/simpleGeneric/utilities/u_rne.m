function rne = u_rne(g, N, parallel)
%  Compute the relative numerical efficiency of ng functions.
%
%  Inputs:
%  g         Function evaluations with particles by row and functions 
%            by column  (JworkerN x ng)
%  N         Number of particles per group
%  parallel  Indicator for multiple workers
%
%  Output:
%  rne       Relative numerical efficiencies (1 x ng)

[JworkerN, ~] = size(g);
Jworker = JworkerN/N;

J = u_numlabs*Jworker;

rne = ((u_std(g, 1, parallel)./u_nse(g, N, parallel)).^2)/(J*N);

end