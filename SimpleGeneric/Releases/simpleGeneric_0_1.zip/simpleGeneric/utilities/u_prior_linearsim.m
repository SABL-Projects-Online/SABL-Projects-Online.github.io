function [theta, prior] = u_prior_linearsim(nsim, prior_in)
%  Simulate from the linear distribution.
%
%  Inputs:
%  nsim                    Number of simulations (particles)
%  prior_in                Prior structure created by u_prior_linearsetup
%
%  Outputs:
%  theta                   Simulated random variables (nsim x prior.n)
%  prior                   prior_in with the additional field
%    .constraints.logG     Simulation approximation of P(a <= D*theta <=b)
%                          ... if prior.con = true.
%    .constraints.logGnse  Corresponding numerical standard error

global C

prior = prior_in;

if prior.con
    [logG, logGnse, theta] = u_GHKprob(prior.mean, prior.varchol, ...
        prior.constraints.D, prior.constraints.a, prior.constraints.b, ...
        C.J, nsim/C.J, prior.df);
    if ~isfield(prior.constraints, 'logG')
        prior.constraints.logG = logG;
    end
    if ~isfield(prior.constraints, 'logGnse')
        prior.constraints.logGnse = logGnse;
    end
else
    if prior.normal
        theta = repmat(prior.mean', nsim, 1) + ...
            randn(nsim, prior.n)*prior.varchol;
    else
        theta = repmat(prior.mean', nsim, 1) + ...
            randn(nsim, prior.n)*prior.varchol./...
            repmat(sqrt(chi2rnd(prior.df, nsim, 1)/prior.df), 1, prior.n);
    end
end

if prior.mix
    [~, theta] = u_mixedrnd(theta, prior.mixed.mass, ...
        prior.mixed.prob, prior.mixed.r, prior.mixed.s);
end

end