function fieldsout = u_listfields(varargin)
%  List all of the fields of a global structure, including any
%  substructure.
%  
%  Input option 1:
%  varargin{1}     C, Cpar or M global (sub) structure name
%
%  Input option 2:
%  varargin{1}     Model name
%  varargin{2}     M global (sub) structure name
%
%  Output: List of fields, to the command window, 
%  with notation of fields that are themselves structures.

%  See whether the field exists and if it is a structure ------------------

if nargin < 1 ||nargin >2
    error('Function must have either one or two input arguments')
end
inputs = varargin{1};
if nargin == 2
    inputs = sprintf('%s %s', inputs, varargin{2});
end

if nargin == 1
    [~, keyword] = help(varargin{1});
else
    [~, keyword] = help(varargin{1}, varargin{2});
end

if isempty(keyword)
    if nargout == 0
        fprintf('\nThe field %s does not exist.\n\n', inputs)
    else
        fieldsout = [];
    end
    return
elseif ~strcmp(keyword, 'STRUCTURE')
    if nargout == 0
        fprintf('\nThe field %s is not a structure.\n\n', inputs)
        return
    else
        fieldsout = [];
        return
    end
end

%  Find the fields in the structure
if nargin == 1
    strucname = u_buildname(varargin);
else
    strucname = u_buildname(varargin{1}, varargin{2});
end

nQstruc = length(strfind(strucname, 'Q'));
strucfiles = dir(char(strcat(strucname(1:end-2), 'Q*.m')));
nstrucfiles = length(strucfiles);
lines = cell(nstrucfiles, 3);
fnames = cell(nstrucfiles, 3);
if nargout > 0
    fieldsout = cell(nstrucfiles, 1);
end
nrequired = 0;
ncontrol = 0;
nmonitor = 0;
nstructure = 0;
nfields = 0;
maxname = 0;
for i = 1:nstrucfiles
    fname = strucfiles(i).name;
    Qpos = strfind(fname, 'Q');
    if length(Qpos) == nQstruc+1
        fname(Qpos) = '.';
        if nargin == 1
            [keyline, keyword] = help(fname(1:end-2));
        else
            [keyline, keyword] = help(varargin{1}, fname(1:end-2));
        end
        if strcmp(keyword, 'REQUIRED')
            nrequired = nrequired + 1;
            lines{nrequired,1} = keyline;
            fnames{nrequired,1} = fname(1:end-2);
        elseif strcmp(keyword, 'CONTROL')
            ncontrol = ncontrol + 1;
            lines{ncontrol,2} = keyline;
            fnames{ncontrol,2} = fname(1:end-2);
        elseif strcmp(keyword, 'MONITOR')
            nmonitor = nmonitor + 1;
            lines{nmonitor,3} = keyline;
            fnames{nmonitor,3} = fname(1:end-2);
        elseif strcmp(keyword, 'STRUCTURE')
            nstructure = nstructure + 1;
            lines{nstructure,4} = keyline;
            fnames{nstructure,4} = fname(1:end-2);
        end
        maxname = max(maxname, length(fname));
        if nargout > 0
            nfields = nfields + 1;
            fieldsout{nfields} = fname(1:end-2);
        end
        
    end
end

if nargout > 0
    fieldsout = fieldsout(1:nfields);
    return
end
if nrequired > 0
    if nrequired == 1
        fprintf('\nThere is 1 required field:\n')
    else
        fprintf('\nThere are %d required fields:\n', nrequired)
    end
    for i = 1:nrequired
        fn = char(fnames{i,1});
        fprintf('%s %s %s\n', ...
            repmat(' ', 1, maxname-length(fn)), fn, char(lines{i,1}))
%         fprintf('%s   %s\n', char(fnames{i,1}), char(lines{i,1}))
    end
else
    fprintf('\nThere are no required fields.\n')
end
if ncontrol > 0
    if ncontrol == 1
        fprintf('\nThere is 1 control field:\n')
    else
        fprintf('\nThere are %d control fields:\n', ncontrol)
    end
    for i = 1:ncontrol
        fn = char(fnames{i,2});
        fprintf('%s %s %s\n', ...
            repmat(' ', 1, maxname-length(fn)), fn, char(lines{i,2}))
%         fprintf('%s   %s\n', char(fnames{i,2}), char(lines{i,2}))
    end
else
    fprintf('\nThere are no control fields.\n')
end
if nmonitor > 0
    if nmonitor == 1
        fprintf('\nThere is 1 monitor field:\n')
    else
        fprintf('\nThere are %d monitor fields:\n', nmonitor)
    end
    for i = 1:nmonitor
        fn = char(fnames{i,3});
        fprintf('%s %s %s\n', ...
            repmat(' ', 1, maxname-length(fn)), fn, char(lines{i,3}))
%         fprintf('%s   %s\n', char(fnames{i,3}), char(lines{i,3}))
    end
else
    fprintf('\nThere are no monitor fields.\n')
end

if nstructure > 0
    if nstructure == 1
        fprintf('\nThere is 1 structure field:\n')
    else
        fprintf('\nThere are %d structure fields:\n', nstructure)
    end
    for i = 1:nstructure
        fn = char(fnames{i,4});
        fprintf('%s %s %s\n', ...
            repmat(' ', 1, maxname-length(fn)), fn, char(lines{i,4}))
%         fprintf('%s   %s\n', char(fnames{i,4}), char(lines{i,4}))
    end
else
    fprintf('\nThere are no structure fields.\n')
end

end
