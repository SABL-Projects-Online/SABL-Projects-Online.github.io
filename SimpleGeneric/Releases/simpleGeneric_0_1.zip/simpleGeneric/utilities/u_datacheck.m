function [T, k] = u_datacheck
%  Check the existence and specification of the M.data matrix
%
%  Outputs:
%  [T, k]  Size of the data matrix

global M
if ~isfield(M, 'data')
    error('M.data is not specified')
elseif isempty(M.data)
    error('M.data is empty')
else
    u_is('realfinite', 'M.data', M.data)
end

[T, k] = size(M.data);

end