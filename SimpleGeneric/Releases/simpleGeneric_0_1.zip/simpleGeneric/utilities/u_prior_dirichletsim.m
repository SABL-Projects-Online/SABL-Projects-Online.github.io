function theta = u_prior_dirichletsim(nsim, prior)
%  Simulate from the Dirichlet prior distribution, x ~ Dirichlet(a);
%  x_i = theta_i/(1+exp(theta_1)+...+exp(theta_n-1)) (i=1,...,n-1)
%  x_n = 1/(1+exp(theta_1)+...+exp(theta_n-1))
%  theta_i = log(p_i/p_n) (i = 1, ... , n-1)
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior     Prior structure created by u_prior_dirichletsetup
%
%  Output:
%  theta     Simulated random variables (nsim x n-1)

theta = zeros(nsim, prior.n-1);
denominator = zeros(nsim, 1);
x = zeros(nsim, 1);
for i = 1:prior.n
    x(:,i) = gamrnd(prior.avector(i), 1, nsim, 1);
    denominator = denominator + x(:,i);
end

x = x./repmat(denominator, 1, prior.n);

for i = 1:prior.n-1
    theta(:,i) = log(x(:,i)./x(:,prior.n));
end

end