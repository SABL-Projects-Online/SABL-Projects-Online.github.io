function logmeanx = u_logmeanlog(logx, dim, parallel)
%  Replicate the Matlab function log(mean(exp(logx, dim))), avoiding error
%  due to the elements of exp(logx) being beyond the range of floating point 
%  representation and with efficient handling of the multiple-worker case. 
%  All 3 inputs are required.
%
%  Inputs:
%  logx      Log of array elements
%  dim	     Dimension along which to sum (dim = 1 or dim = 2)
%  parallel  Indicator for multiple workers
%
%  logmeanx   Log of mean along dimension dim 

[logmeanx, ~] = u_logmomlog(logx, dim, parallel);

end
