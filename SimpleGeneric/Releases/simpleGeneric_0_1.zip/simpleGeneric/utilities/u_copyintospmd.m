function u_copyintospmd(Cin, Ein, Min, Pin, Cparin, Eparin, Mparin, Pparin)
%  Copy global structures C, Cpar, E, Epar, M, Mpar, P, Ppar from client to workers
%  inside SPMD.
%
%  Inputs:
%  Cin			global structure C in the client
%  Ein			global structure E in the client
%  Min			global structure M in the client
%  Pin			global structure P in the client
%  Cparin		global structure Cpar in the client
%  Eparin		global structure Epar in the client
%  Mparin		global structure Mpar in the client
%  Pparin		global structure Ppar in the client

global C Cpar E Epar M Mpar P Ppar
C = Cin;
E = Ein;
M = Min;
P = Pin;

if C.simget
%{
    Cpar = Cparin;
    Epar = Eparin;
    Mpar = Mparin;
    Ppar = Pparin;
%}
    Cpar = u_distrirecursive(Cparin);
    Epar = u_distrirecursive(Eparin);
    Mpar = u_distrirecursive(Mparin);
    Ppar = u_distrirecursive(Pparin);
end