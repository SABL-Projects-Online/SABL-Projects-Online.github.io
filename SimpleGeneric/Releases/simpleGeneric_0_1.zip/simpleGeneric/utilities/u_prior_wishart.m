function logp = u_prior_wishart(theta, prior)
%  Evaluate the log pdf of the Wishart prior density function for X,
%  log[p(X|V)] = lognormconst + 0.5(n-df-1)log(det(X)) - 0.5tr(inv(V)X),
%  lognormconst = -0.5np*log(2) - 0.5nlog(det(V)) 
%                                 - sum (i=1,...,n)log(gamma(0.5(df+1-i)))
%  where V is the Variance, or scale, parameter of the distribution.
%  The n x n positive definite matrix X is parameterized by its Choleski
%  decomposition X = C'C, where C is upper triangular; the algorithm
%  parameter vector theta uses logs of the on-diagonal and levels of the
%  off-diagonal upper triangular components of C. The ordering of theta
%  begins with the first row of C (n elements), followed by the second
%  row of C (n-1 elements), ..., followed by the j'th row of C (n-j+1
%  elements, ..., and ending with C(n,n): i.e., row major order omitting
%  elements that are identically zero.
%
%  The function incorporates the Jacobian of transformation, returning
%  the log-density log[p(X|V)] + nlog(2) + sum(i=1,...,n)(n+i-1)log(c_ii)
%
%  Inputs:
%  theta     Algorithm parameters (C.JNwork x n*(n+1)/2)
%    
%  prior     Prior structure created by u_prior_dirichletsetup
%
%  Output:
%  logp      Log prior density corresponding to theta (C.JNwork x 1)

JN = size(theta, 1);
logp = repmat(prior.lognormconst, JN, 1);

cc = prior.df;
r1 = 1;
for j = 1:prior.n
    logp = logp + cc*theta(:,r1);      
    cjj = exp(theta(:,r1));
    for i=j:prior.n
        ss = 0;
        r2 = r1;
        for k = j:i
            if k==j
                ss = ss + cjj*prior.precfactor(i,k);
            else
                r2 = r2 + 1;
                ss = ss + theta(:,r2)*prior.precfactor(i,k);
            end
        end
        logp = logp - 0.5*ss.^2;
    end
    cc = cc - 1;
    r1 = r2 + 1;
end

end