function r = u_isonrecursive(a)
% Check if all fields (recursively) of a structure a are on CPU or GPU
%
%  Input:
%  a	The array to be checked
%  Output
%  r	'cpu', 'gpu' or 'mixed'

if isstruct(a)
    r = '';
    fields = fieldnames(a);
    for i = 1:length(fields)
	r1 = u_isonrecursive(a.(fields{i}));
	if isempty(r1)
	    continue;
	end
	if isempty(r)
	    r = r1;
	end
	if ~strcmp(r, r1)
	    r = 'mixed';
	    break;
	end
    end
else
    r = u_ison(a);
end