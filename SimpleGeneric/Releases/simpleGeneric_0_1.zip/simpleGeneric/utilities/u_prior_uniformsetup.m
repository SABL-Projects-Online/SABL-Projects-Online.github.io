function prior = u_prior_uniformsetup(prior_in)
%  Map alternative specifications of a uniform prior distribution function 
%  into a standard specification.  Set up handling of optional inequality 
%  constraints and/or mixed discrete-continuous variant. Check for 
%  specification errors.
%
%  Input:
%  prior_in       Structure expression the prior distribution:
%    .endpoints   Endpoints of uniform distribution (n x 2); OR,
%    .mean_width  Mean and width of uniform distribution (n x 2)  
%    .mixed       See function u_mixedsetup
%
%  Output:
%  prior                Structure expressing the prior distribution. The 
%                       following fields are added:
%    .name              'uniform'
%    .endpoints         Endpoints of distribution (n x 2)
%    .n                 Order of the distribution (n)
%    .npars             Corresponding order of theta (= prior.n)
%    .lognormconst      Log of uniform prior density normalizing constant
%    .mix               Indicator for mixed distribution   
%    .mixed             See function u_mixedsetup

trans = @(x) x;

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'uniform';
prior.con = false;

if isfield(prior, 'endpoints')
    if size(prior.endpoints, 2) ~= 2
        error('prior.endpoints has %d columns ~= 2', ...
            size(prior.endpoints, 2))
    end
    prior.n = size(prior.endpoints, 1);
    u_is('realfinite', 'prior.endpoints', prior.endpoints)
    if any(prior.endpoints(:,1) >= prior.endpoints(:,2))
        error('prior.endpoints(:,2) > prior.endpoints(:,1) required')
    end
    
elseif isfield(prior, 'mean_width') 
    if size(prior.mean_width, 2) ~= 2
        error('prior.mean_width has %d columns ~= 2', ...
            size(prior.emean_width, 2))
    end
    prior.n = size(prior.mean_width, 1);
    u_is('realfinite', 'prior.mean_width', prior.mean_width)
    u_is('positivereal', 'prior.mean_width(:,2)', prior.mean_width(:,2))
    prior.endpoints = ...
        [prior.mean_width(:,1) - prior.mean_width(:,2)*0.5, ...
        prior.mean_width(:,1) + prior.mean_width(:,2)*0.5];
    
else
    error('No valid prior hyperparameter fields')
end

prior.npars = prior.n;
prior.lognormconst = ...
    -sum(log(prior.endpoints(:,2) - prior.endpoints(:,1)));

prior = u_mixedsetup(prior, @u_prior_uniform, trans);
if prior.mix
    if any(prior.mixed.mass < prior.endpoints(1,1)) ||...
        any(prior.mixed.mass > prior.endpoints(1,2))
    error('One or more mass points not within distribution suppoort')
    end
end 
% prior = u_mixedsetup(prior, @u_prior_uniform, trans);

prior.simple = ~prior.mix;

end