function logp = u_prior_laplace(theta, prior)
%  Evaluate the log pdf of the gamma prior density function
%  p(x) = (lambda/2)exp(-lambda|x-mean|). 
%  The algorithm parameter theta = x.
%
%  Inputs:
%  theta     Points of evaluation (particles); theta = x   (C.JNwork x 1)
%  prior     Prior structure created by u_prior_laplacesetup
%
%  Output:
%  logp      Log prior density corresponding to theta  (C.JNwork x 1)

trans = @(x) x;

if prior.simple
    logp = prior.lognormconst - prior.lambda*abs(theta-prior.mean);
    
else
    logp = u_priormixcont(theta, prior, @u_prior_laplace, trans, trans);
    
end

end