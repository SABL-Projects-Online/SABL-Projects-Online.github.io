function theta1 = u_mixmap(theta)
%  Map the algorithm parameters theta of a partially mixed 
%  discrete-continuous joint prior distribution to their origina 
%  representation.  "Partially" means that some, none or all of the prior 
%  blocks have a mixed discrete-continuous distribution.
%
%  Input:
%  theta      Algorithm parameters (JN x k)
%
%  Output:
%  theta1     Original representation of theta (JN x k)

global M

theta1 = theta;

if M.mix
    nparts = length(M.prior);
    for ipart = 1:nparts
        a = M.prior{ipart};
        if a.mix
            theta1(:,a.columns) = u_cont_to_mixed(theta(:,a.columns), ...
                a.mixed.mass, a.mixed.r, a.mixed.s);
        end
    end
end