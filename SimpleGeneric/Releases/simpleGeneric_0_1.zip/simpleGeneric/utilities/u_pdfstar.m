function pdf = u_pdfstar(x, kernel, rvector, svector, pvector)
%  Evalute the pdf of the continuous representation of the mixed
%  discrete-continuous distribution.
%
%  Inputs:
%  x         Points of evaluation (JN x 1)
%  kernel    Evaluation of the kernel of the continuous component of
%            the mixed discrete-continuous distribution at the
%            mixed discrete-continuous points corresponding to x.
%  rvector   Vector r with reference to the notes in this section
%  svector   Vector s with reference to the notes in this section 
%  pvector   Vector p with reference to the notes in this section
%
%  Output:
%  pdf       Probability density function of the continuous random
%            varaiable evaluated at x
%
%  The typical invocation of this function proceeds as follows, where
%  pdfcont is the function evaluating the pdf of the continuous part
%  of the distribution:
%      x = cont_to_mixed(xstar, mvector, rvector, svector)
%      pdf = (1 - sum(pvector))*pdfcont(x, [parameters])
%      pdf = pdfstar(xstar, pdf, rvector, svector, pvector)

pdf = kernel;
n = length(rvector);
jj = 1:length(x);
for j = 1:n
    ii = find(x > rvector(j) & x <= svector(j));
    if ~isempty(ii)
        pdf(ii) = pvector(j)/(svector(j)-rvector(j));
    end
    jj = setdiff(jj, ii);
end

end