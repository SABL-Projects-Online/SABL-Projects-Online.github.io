function fullname = u_buildname(varargin)

gstrucs = {'C', 'Cpar', 'E', 'Epar', 'M', 'Mpar', 'P', 'Ppar'};

if nargin == 1
    fname = char(varargin{1});

else
    model = char(varargin{1});
    fname = char(varargin{2});
end

Qfind = false;

for i = 1:length(fname)
    if strcmp(fname(i), '.');
        Qfind = true;
        fname(i) = 'Q';
    end
end
fname = char(strcat(fname, '.m'));


if nargin == 1
    %  It looks like there will be conflict between the main SABL
    %  toolbox and updates_John at this point, that "which" resolves:
    fullname = which(fname);
    
else
    if Qfind || any(strcmp(fname(1:end-2), gstrucs))
        pathtemp = strcat(u_getsablroot, '/models/', model, '/', ...
            'helpfiles/');
    else
        pathtemp = strcat(u_getsablroot, '/models/', model, '/');
    end
%     if ~isempty(dir(pathtemp))
%         addpath(pathtemp)
%     end
    
    fullname = strcat(pathtemp, fname);

end

end