function [theta, prior] = u_initialsim(prior_in)
%  Simulate from the initial distribution.
%
%  Input:
%  prior_in      Each element of this cell array contains the specification
%                of the initial distribution for a component of the initial
%                distribution.  (cell, ncomponents x 1)
%
%  Outputs:
%  theta         Particles drawn from initial disitribution  (JN x npars)
%  prior         prior_in with the addition of some fields used in
%                subsequent computations.  Typically prior and prior_in
%                are the same in the invoking function.
                 
global C E

theta = u_allocate([C.JNwork, C.parameters]);
prior = prior_in;
nparts = length(prior);

for ipart = 1:nparts
    a = prior{ipart};
    
    if strcmp(a.name, 'beta')
        theta(:, a.columns) = u_prior_betasim(C.JNwork, a);
        
    elseif strcmp(a.name, 'Dirichlet')
        theta(:, a.columns) = u_prior_dirichletsim(C.JNwork, a);
        
    elseif strcmp(a.name, 'gamma')
        theta(:, a.columns) = u_prior_gammasim(C.JNwork, a);
        
    elseif strcmp(a.name, 'Laplace')
        theta(:, a.columns) = u_prior_laplacesim(C.JNwork, a);
        
    elseif strcmp(a.name, 'linear')
        [theta(:, a.columns), a] = u_prior_linearsim(C.JNwork, a);
        
    elseif strcmp(a.name, 'uniform')
        theta(:, a.columns) = u_prior_uniformsim(C.JNwork, a);
        
    elseif strcmp(a.name, 'Wishart')
        theta(:, a.columns) = ...
            u_prior_wishartsim(C.JNwork, a);
        
    elseif strcmp(a.name, 'model')
        theta = m_prior_customsim(ipart, a);
        
    elseif strcmp(a.name, 'custom')
        theta = p_prior_customsim(ipart, a);
        
    else
        error('M.prior{%d}.name = %s unrecognized', ipart, a.name)
    end
    
    prior{ipart} = a;
    
    if E.gpu
        memtype = 'gpu';
    else
        memtype = 'cpu';
    end
    
    theta = u_setdatatype(theta, memtype);
    
end
    
end
