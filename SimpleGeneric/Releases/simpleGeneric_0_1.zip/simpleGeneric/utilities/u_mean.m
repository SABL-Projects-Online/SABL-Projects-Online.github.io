function m = u_mean(x, dim, parallel, logw)
%  Replicate the Matlab function mean(x, dim) with efficient handling
%  of the multiple-worker case. In the multiple worker case the array
%  sizess must be the same for all workers. 
%  The first 3 inputs are required; the last is optional.
%
%  Inputs:
%  x	     The array whose mean is to be computed
%  dim	     Dimension along which to compute the mean
%  parallel  Indicator for multiple workers
%  logw      Array of log weights in 1-to-1 correspondence with x
%
%  Output:
%  m         Mean of x along dimension dim (size of x with dimension dim)

if nargin == 3
    m = mean(x,dim);
    if parallel
        m = mean(gcat(m ,dim), dim);
    end
elseif nargin == 4
    maxlogw = u_max(logw, dim, parallel);
    if dim == 1 
        w = exp(logw - repmat(maxlogw, size(logw, dim), 1));
    else
        w = exp(logw - repmat(maxlogw, 1, size(logw, dim)));
    end
    m = u_sum(w.*x, dim, parallel)./u_sum(w, dim, parallel);
end
    
end