function logsumx = u_logsumlog(logx, dim, parallel)
%  Replicate the Matlab function log(sum(exp(logx, dim))), avoiding error
%  due to the elements of exp(logx) being beyond the range of floating point 
%  representation and with efficient handling of the multiple-worker case. 
%  All 3 inputs are required.
%
%  Inputs:
%  logx      Log of array elements
%  dim	     Dimension along which to sum (dim = 1 or dim = 2)
%  parallel  Indicator for multiple workers
%
%  Output:
%  logsumx   Log of sum along dimension dim

maxlogx = u_max(logx, dim, parallel);
if dim == 1
    logxnorm = logx - repmat(maxlogx, size(logx, dim), 1);
else
    logxnorm = logx - repmat(maxlogx, 1, size(logx, dim));
end
logsumx = log(u_sum(exp(logxnorm), dim, parallel)) + maxlogx;

end