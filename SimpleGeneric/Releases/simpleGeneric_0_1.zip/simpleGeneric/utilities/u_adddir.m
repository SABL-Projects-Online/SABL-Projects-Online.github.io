function u_adddir(dir)
% Add directory or directories (in the form of a cell array) to MATLAB's
% search path. This function serves the purpose of adding model-specific or
% project-specific directories to the search path (supporting updates_*
% directories and directories outside SABL toolbox). The cell-array
% implementation facilitates support for update_* directories.
%
% Input:
% dir     A path or a cell array of paths being the model- or project-
%         specific directory or directories. In the case of multiple
%         directories, no particular order is assumed.             

if isempty(dir)
    return;
end

if iscell(dir)
    dir = sort(dir); 
    order = {'updates_Simon' 'updates_Bin' 'updates_Huaxin' 'updates_John'};
    try
	dir = u_sortcellarray(dir, order);
    catch 
	error('Ambiguous model or project directory. Make sure no model or project directories have duplicate names.');
    end
    for i = 1:length(dir)
        u_adddir(dir{i});
    end
else
    if 7 == exist(dir, 'dir')
        addpath(dir);
        u_adddir([dir filesep 'cufiles']);
        u_adddir([dir filesep 'ptxfiles']);
        u_adddir([dir filesep 'mexfiles']);
        u_adddir([dir filesep 'helpfiles']);
    end
end
   
end
