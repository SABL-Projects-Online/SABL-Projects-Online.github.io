function inspmd = u_distrirecursive(outspmd)
% Recursively distribute a structure from outside SPMD in.
%
%  Input:
%  outspmd     The structure outside SPMD (the source)
%
%  Output:
%  inspmd      The structure inside SPMD (the destination)

if isstruct(outspmd)
    fields = fieldnames(outspmd);
    for i = 1:length(fields)
        inspmd.(fields{i}) = u_distrirecursive(outspmd.(fields{i}));        
    end
else
    n = size(outspmd,1)/u_numlabs;
    r = n*(labindex-1)+1:n*labindex;
    inspmd = outspmd(r,:);
end

end