function prior = u_prior_gammasetup(prior_in)
%  Map alternative specifications of a gamma prior distribution function 
%  into a standard specification.  Set up handling of optional inequality 
%  constraints and/or mixed discrete-continuous variant. Check for 
%  specification errors. 
%
%  Input:
%  prior_in           Structure expressing the prior distribution:
%    .shape, .scale   Shape and scale parameters; OR,
%    .shape, .rate    Shape and rate parameters; OR,
%    .mean,  .std     Mean and standard deviation;  OR,
%    .chi2df, .scale  Chi-squared degrees of freedom and scale factor
%    .constraints     See function u_constraintssetup    
%    .mixed           See function u_mixedsetup
%
%  Output:
%  prior              Structure expressing the prior distribution. The 
%                     following fields are added:
%    .name            'gamma'
%    .shape           Shape parameter
%    .scale           Scale parameter
%    .n               Order of the distribution (1)
%    .npars           Corresponding order of theta (1)
%    .lognormconst    Log of gamma prior density normalizing constant
%    .con             Indicator for constraints
%    .mix             Indicator for mixed distribution
%    .constraints     See function u_constraintssetup    
%    .mixed           See function u_mixedsetup

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'gamma';
prior.n = 1;
prior.npars = 1;

if isfield(prior, 'shape') && isfield(prior, 'scale')
    u_is('scalar', 'prior.shape', prior.shape)
    u_is('scalar', 'prior.scale', prior.scale)
    u_is('positivereal', 'prior.shape', prior.shape)
    u_is('positivereal', 'prior.scale', prior.scale)
    
elseif isfield(prior, 'shape') && isfield(prior, 'rate');
    u_is('scalar', 'prior.shape', prior.shape)
    u_is('scalar', 'prior.rate', prior.rate)
    u_is('positivereal', 'prior.shape', prior.shape)
    u_is('positivereal', 'prior.rate', prior.rate)
    prior.scale = 1/prior.rate;
    
elseif isfield(prior, 'mean') && isfield(prior, 'std')
    u_is('scalar', 'prior.mean', prior.mean)
    u_is('scalar', 'prior.std', prior.std)
    u_is('positivereal', 'prior.mean', prior.mean)
    u_is('positivereal', 'prior.std', prior.std)
    prior.scale = (prior.std^2)/prior.mean;
    prior.shape = prior.mean/prior.scale;
    
elseif isfield(prior, 'chi2df') && isfield(prior, 'scale')
    u_is('scalar', 'prior.chi2df', prior.chi2df)
    u_is('scalar', 'prior.scale', prior.scale)
    u_is ('positivereal', 'prior.chi2df', prior.chi2df)
    u_is('positivereal', 'prior.scale', prior.scale)
    prior.shape = 0.5*prior.chi2df;
    prior.scale = 2*prior.scale;
    
else
    error('No valid combinations of prior hyperparameter fields')
end

prior.lognormconst = -gammaln(prior.shape) - prior.shape*log(prior.scale);
prior = u_constraintssetup(prior);
if prior.con
    a = prior.constraints.a;
    b = prior.constraints.b;
    prior.constraints.logG = log(gamcdf(b, prior.shape, prior.scale) ...
        - gamcdf(a, prior.shape, prior.scale));
    if a < 0
        error('Constraint set not a subset of the domain [0, +inf)')
    end
end

prior = u_mixedsetup(prior, @u_prior_gamma, @log);

if prior.mix && prior.con
    if prior.con
        z = prior.constraints.D*prior.mixed.mass;
        if any(z < a || z > b)
            error('Mixed distribution mass points violate constraints')
        end
    else
        if any(prior.mixed.mass < 0)
            error('Mixed distribution mass points must be in [0, inf)')
        end
    end
end

prior.simple = ~(prior.con || prior.mix);

end