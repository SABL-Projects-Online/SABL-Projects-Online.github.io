% Install the SABL toolbox. Installation doesn't require
% administrator's access rights. However it requires the 
% MATLAB built-in environment variable 'userpath' holding
% a valid value. Once 'userpath' is cleared, SABL needs to
% be re-installed.  
sablroot = u_getsablroot;
u_rmskeleton(sablroot,true); 
u_addskeleton(sablroot);
[install_dir, ~, ~] = fileparts(mfilename('fullpath'));

%% Identify OS
if ispc
    arch = 1;
elseif ismac
    arch = 2;
elseif isunix
    arch = 3;
else 
    error('Unrecognized Operating System.');
end


%% Identify startup.m
filestartup = which('startup');
if isempty(filestartup)
    % to create startup based on each OS
    if isempty(userpath) || 7 ~= exist(userpath, 'dir')
        if 3 == arch && 7 ~= exist('~/Documents', 'dir')
            mkdir('~/Documents');
        end
        userpath('reset');
    end
    switch arch
    case 1 % pc
        temp1 = regexp(userpath, pathsep, 'split');
        temp2 = temp1{1};
    case 2 % mac
        temp1 = regexp(userpath, pathsep, 'split');
        temp2 = temp1{1};
    case 3 % unix
        if isempty(userpath)
            [~, temp1] = fileattrib('~/');
            temp2 = temp1.Name;
        else
            temp1 = regexp(userpath, pathsep, 'split');
            temp2 = temp1{1};
        end
    otherwise
    end
    filestartup = [temp2 filesep 'startup.m'];
    fid = fopen(filestartup,'w');
    fclose(fid);
end

fid = fopen(filestartup,'r');
startfileconten = textscan(fid,'%s','Delimiter','\n');
fclose(fid);
startfileconten = startfileconten{1};

indicator = strfind(startfileconten, install_dir);
emptyCells = cellfun(@isempty,indicator);
if sum(emptyCells)==length(indicator)
    s = ['install_dir = ''' install_dir  '''; if exist(''' install_dir ...
        ''',''dir''); savedpath = pwd; cd(install_dir); ' ...
        ' sablroot = u_getsablroot; u_rmskeleton(sablroot,true); ' ...
        ' u_addskeleton(sablroot); cd(savedpath); end; ' ...
        ' clear install_dir sablroot savedpath'];
    startfileconten = [startfileconten; s];
    fid = fopen(filestartup,'w');
    for i = 1:length(startfileconten) - 1
	fprintf(fid, '%s\n', startfileconten{i});
    end
    fprintf(fid, '%s', startfileconten{end});
    fclose(fid);
end

admdir = ['~' filesep '.'];
[stat, info] = fileattrib(admdir);
if 1==stat && (1==info.UserWrite || 1==GroupWrite || 1==OtherWrite)
    copyfile(filestartup, admdir);
end

clear arch ans filestartup temp1 temp2 fid install_dir i s indicator startfileconten sablroot savedpath emptyCells
