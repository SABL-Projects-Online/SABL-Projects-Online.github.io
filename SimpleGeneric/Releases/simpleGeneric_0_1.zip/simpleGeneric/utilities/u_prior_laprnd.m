function y = u_prior_laprnd(mu, b)
%  Generate random numbers from laplacian distribution with mean mu and 
%  standard deviation sigma as follows.
%    f(x|mu, b) = 1/(2*b)*exp(-abs(x-mu)/b),
%    Mean       mu,
%    Median     mu,
%    Mode       mu,
%    Variance   2b.
%  If V ~ Exponential(1) and Z ~ N(0, 1) independent of V, then 
%      X = mu + b*sqrt{2*V}Z ~ Laplace(mu, b).
% 
%  Input:
%  mu      Mean
%  b       Scale parameter
%
%  Ouput:
%  Laplacian random number

[irow_mu, icol_mu] = size(mu);
[irow_b, icol_b]   = size(b);

if irow_mu ~= irow_b || icol_mu ~= icol_b
    error(['Invalid: size(mu) = [%d, %d]\n', ...
           '         size(b)  = [%d, %d]\n'], ...
           size(mu), size(b))
end

y = mu + b.*sqrt(2*exprnd(1, irow_b, icol_b)).*randn(irow_b, icol_b);

end