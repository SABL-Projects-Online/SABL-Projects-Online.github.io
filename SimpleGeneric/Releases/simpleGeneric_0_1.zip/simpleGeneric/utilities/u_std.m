function sd = u_std(x, dim, parallel, logw)
%  Replicate the Matlab function std(x, [], dim) with efficient handling
%  of the multiple-worker case. In the multiple-worker case the array
%  sizes must be the same for all workers. 
%  The first 3 inputs are required; the last is optional

%  Inputs:
%  x	     The array whose standard deviation is to be computed
%  dim	     Dimension along which to compute the standard deviation
%  parallel  Indicator for multiple workers
%  logw      Array of log weights in 1-to-1 correspondence with x

%  Output:
%  sd        Standard deviation of x along dimension dim

[n, k] = size(x);
if nargin == 3
  xmean = u_mean(x, dim, parallel);
  if dim == 1
      var1 = u_mean((x - repmat(xmean, n, 1)).^2, dim, parallel);
  else
      var1 = u_mean((x - repmat(xmean, 1, k)).^2, dim, parallel);
  end
else
    xmean = u_mean(x, dim, parallel, logw);
  if dim == 1
      var1 = u_mean((x - repmat(xmean, n, 1)).^2, dim, parallel, logw);
  else
      var1 = u_mean((x - repmat(xmean, 1, k)).^2, dim, parallel, logw);
  end
end
n = size(x,dim);
if parallel
    n = gplus(n);
end
sd = sqrt(var1*n/(n-1));

end