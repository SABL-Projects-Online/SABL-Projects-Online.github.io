function s = u_sum(x, dim, parallel)
%  Replicate the Matlab function sum(x, dim) with efficient handling
%  of the multiple-worker case. All 3 inputs are required.
%
%  Inputs:
%  x	     The array to be summed
%  dim	     Dimension along which to sum
%  parallel  Indicator for multiple workers
%
%  Output
%  m         Mean of x along dimension dim
s = sum(x,dim);

if parallel
    s = sum(gcat(s ,dim), dim);
end

end