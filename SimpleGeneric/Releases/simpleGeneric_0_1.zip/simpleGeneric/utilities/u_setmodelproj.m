function u_setmodelproj(model, project)
%  Set model and/or project without launching SABL.m.
%
%  Inputs:
%  model       A string representing the model's name or path.
%  project     A string representing the project's name or path.

global M P

M.modeldir = []; M.modelname = [];
P.projectdir = []; P.projectname = [];
[M.modeldir, M.modelname] = u_setspecdir(model);
[P.projectdir, P.projectname] = u_setspecdir(project);

u_adddir(M.modeldir);
u_adddir(P.projectdir);

end