function prior = u_initialsetup(prior_in)
%  Perform consistency checks on the joint specification of all prior
%  components.
%
%  Input
%  prior     Prior specification (cell vector)
%
%  Output:
%            No action if no errors; otherwise detail errors and terminate.

if ~iscell(prior_in)
    error('prior must be a cell array but class(prior) = %s', ...
        class(prior_in))
end
prior = prior_in;
n = length(prior);

%  Check for errors detectable in joint prior specification but not in
%  individual prior specifications.
colunion = [];
coltotal = 0;
ok = true;
for i = 1:n
    u_isfield(prior{i}, 'columns', true, sprintf('prior{%d}', i));
    cols = prior{i}.columns;
    
    % ******************
    if all(cols == 0)
        continue
    end
    % ******************
    
    check1 = all(cols > 0);
    check2 = all(cols == round(cols));
    check3 = length(cols) == length(unique(cols));
    if ~check1&&check2&&check3
        u_cprintf('Red', ...
            'prior{%d}.columns = \n%s\n not unique positive integers', ...
            i, num2str(cols))
        ok = false;
    end
    
%     fprintf('Component %d\n', i)
    
    if length(cols) ~= prior{i}.npars
        out1 = 'length(prior{%d}.columns) = %d ';
        out2 = 'but %d columns are required\n';
        u_cprintf('Red', [out1, out2], i, length(cols), prior{i}.npars)
        ok = false;
    end
    coltotal = coltotal + length(cols);
    colunion = union(colunion, cols);
    prior{i}.con = isfield(prior{i}, 'constraints');
    prior{i}.mix = isfield(prior{i}, 'mixed');
end
if length(colunion) ~= coltotal
    u_cprintf('Red', '%Some prior{.}.columns elements overlap');
    ok = false;
end

if ~ok
    error('Errors in specification of one or more prior components')
end

if max(colunion) > length(colunion)
    u_cprintf('Red', ...
        'Warning: Priors jointly exclude some columns of theta')
    pause
end

for i = 1:n
    prior{i}.con = u_isfield(prior{i}, 'constraints', false);
    prior{i}.mix = u_isfield(prior{i}, 'mixed', false);
end

end