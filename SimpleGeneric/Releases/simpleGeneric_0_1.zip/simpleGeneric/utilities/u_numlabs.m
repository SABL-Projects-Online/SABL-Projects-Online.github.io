function n = u_numlabs
%  Extend the Matlab parallel toolbox function numlabs to include Matlab
%  installations without the parallel toolbox
%
%  Output:
%  Number of workers (1 if parallel toolbox not installed)

global E

if E.pus > 1
    n = numlabs;
else
    n = 1;
end