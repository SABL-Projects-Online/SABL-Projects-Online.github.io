function [theta, prior] = u_priorlinearsim(nsim, prior_in)
%  Simulate from the linear distribution.
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior_in  Prior structure created by u_prior_gammasetup
%
%  Output:
%  theta     Simulated random variables (nsim x prior.n)
%  prior     prior_in with additional fields in some cases

prior = prior_in;


