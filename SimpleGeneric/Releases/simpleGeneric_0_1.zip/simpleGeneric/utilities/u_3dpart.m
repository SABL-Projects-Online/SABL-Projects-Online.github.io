function Aextensive = u_3dpart(A, Amap, Alinc, Aname)
%  Convert a matrix of matrix particle format to a conventional
%  3-dimensional matrix A with A(i,j,:) containing the particles for
%  row i, column j of the matrix.
%
%  Inputs:
%  A           Non-zero entries of the matrix  (JN x Anz)
%  Amap        Pointers from elements of A to columns of A
%
%  Other inputs and output:
%  map        Pointers from columns of array to entries in A (n x m)
%             If                       Then Aextensive(:,Amap(i,j)) =
%             0 < Amap(i,j) <= npars    array(:,Amap(i,j));
%             Amap(i,j) = 0             No entry, and Amap(i,j)=0
%             Amap(i,j) < 0             array*linc(1:npars),-Amap(i,j))
%                                               + linc(npars+1, -Amap(i,j))
%             Amap(i,j) > size(array,1) given by 
%                                            p_thetapar(array, name, i, j)
   
[n, m] = size(Amap);
JN = size(A, 1);
Aextensive = zeros(n, m, JN);
if nargin == 2
    [A1, A1map] = u_collectpart(A, Amap);
elseif nargin == 3
    [A1, A1map] = u_collectpart(A, Amap, Alinc);
else
    [A1, A1map] = u_collectpart(A, Amap, Alinc, Aname);
end

for i = 1:n
    for j = 1:m
        p = A1map(i,j);
        if p > 0
            Aextensive(i,j,:) = A1(:,p);
        end
    end
end

end