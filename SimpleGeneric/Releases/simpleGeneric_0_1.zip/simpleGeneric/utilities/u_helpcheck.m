function u_helpcheck
% Look through all of the functions in the current directory and execute 
% 'help [functionname]' for each one

filenames = dir('*.m');
a = length(filenames);
addpath(pwd);

for i = 1:a
    b = filenames(i).name;
    fprintf('%s\n', b);
    eval(['help ' b]);
    pause
end

end

