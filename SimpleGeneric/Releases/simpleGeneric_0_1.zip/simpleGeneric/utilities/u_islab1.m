function r = u_islab1
%  Extends the Matlab statement labindex == 1 to include Matlab 
%  installations without the parallel toolbox
%
%  Output:
%  r     True if one worker; indicator for worker 1 if multiple workers

global E

if E.pus > 1
    r = labindex == 1;
else
    r = true;
end