function [meanx, varx] = u_mvmom(x, dim, parallel)
%  Replicate the Matlab functions mean(x) and cov(x), with efficient 
%  handling of the multiple-worker case. In the multiple-worker case array 
%  sizes must be the same on all workers.  All 3 inputs are required.
%  Let N := # observatons, k := dimension of vector
%
%  Inputs:
%  x         Array whose multivariate mean and variance are to be computed
%  dim	     Dimension along which to sum observations for mean, variance
%  parallel  Indicator for multiple workers
%
%  Outputs:
%  meanx     Multivariate mean vector (1 x k if dim = 1, k x 1 if dim = 2)
%  varx      Multivariate variance matrix (using divisor N - 1)  (k x k)

if parallel
    meanx = u_mean(x, dim, true);
    if dim == 1  %  x is N x k on each processor
        y = x - repmat(meanx, size(x,1), 1);  %  N x k on each processor
    else  %  x is k x N on each processor
        y = x' - repmat(meanx', size(x,2), 1);  %  N x k on each processor
    end
    varx = gplus(y'*y)/(gplus(size(y,1)) - 1);
else
    meanx = mean(x, dim);
    if dim == 1
        varx = cov(x);
    else
        varx = cov(x');
    end
end

end