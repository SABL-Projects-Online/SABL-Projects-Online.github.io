function res = u_toolbox_ok(toolbox)
%  Determine whether a Matlab toolbox is installed.
%
%  Input:
%  toolbox     Name of toolbox (string)
%
%  Output:
%  res         Indicator for toolbox installed

a = ver;
b = cell(length(a),1);
for i = 1:length(a)
    b(i) = {a(i).Name};
end
res = nnz(strcmp(b, toolbox)) > 0;

end