function x = u_normtruncrnd(mu, sig, astar, bstar)
%  Make one draw from the N(mu, sig^2) disttribution subject to a < x < b.
%  The algorithm is described in Geweke, "Efficient Simulation from the 
%  Multivariate Normal and Student-t Distributions Subject to Linear 
%  Constraints," Computing Science and Statitics: Proceedings of the 23rd 
%  Symposium on the Interface, 1991, pages 571 - 578; and in Geweke, 
%  Contemporary Bayesian Econometrics and Statistics, 2005 (Wiley), 
%  Chapter 4.
%
%  Inputs:
%  mu    Mean of untruncated distribution
%  sig   Standard deviation of untruncated distribution
%  a     Lower truncation point
%  b     Upper truncation point
%
%  Output:
%  x     Random draw from N(mu, sig^2) restricted to a < x < b

if bstar < astar
    error('bstar = %22.15e < astar = %22.15e', astar, bstar)
end
if bstar - astar <10*eps
    x = unifrnd(astar, bstar);
    return
end

t1 = 0.150;
t2 = 2.18;
t3 = 0.725;
t4 = 0.45;

a = (astar - mu)/sig;
b = (bstar - mu)/sig;
flip = b < 0;

if flip
    temp_a = a;
    a = - b;
    b = - temp_a;
end

phia = normpdf(a);
phib = normpdf(b);
ratio = exp(0.5*(b^2 - a^2));
accept = false;

normsamp = false;
unifsamp = false;
halfnormsamp = false;
expsamp = false;

if isinf(b)
    normsamp = a <= t4;
    expsamp = ~normsamp;
elseif a <= 0 && b >= 0
    unifsamp = phia >= t1 && phib >= t1;
    phikernmax = 1;
    normsamp = ~unifsamp;
else
    unifsamp = ratio <= t2;
    phikernmax = exp(-0.5*a^2);
    if ~unifsamp
        if ratio > t1 
            halfnormsamp = a < t3;
            expsamp = ~halfnormsamp;
        end
    end
end

if normsamp
    while ~accept
        x1 = randn;
        accept = x1 >= a && x1 <= b;
    end
elseif unifsamp
    while ~accept
        x1 = unifrnd(a, b);
        accept = rand < exp((-0.5*x1^2))/phikernmax;
    end
elseif halfnormsamp
    while ~accept
        x1 = abs(randn);
        accept = x1 >= a && x1 <= b;
    end
elseif expsamp
    botrat = exp(-0.5*a^2);
    while ~accept
        x1 = a + exprnd(1/a);
        toprat = exp(-0.5*x1^2)/exp(-a*(x1-a));
        rat = toprat/botrat;
        accept = rand < rat && x1 < b;
    end
end

if flip
    x2 = -x1;
else
    x2 = x1;
end
x = mu + sig*x2;

end