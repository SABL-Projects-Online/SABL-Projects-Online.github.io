function [out, docTopic] = u_mhelp(varargin)
    %  U_MHELP : A clone of the help.m in
    %  /usr/local/matlab2015a/toolbox/matlab/helptools

    if nargin && ~iscellstr(varargin)
        error(message('MATLAB:help:NotAString'));
    end

    process = helpUtils.helpProcess(nargout, nargin, varargin);
    try 
        process.getHelpText;
        process.prepareHelpForDisplay;
    end
    if nargout > 0
        out = process.helpStr;
        if nargout > 1
            docTopic = process.docTopic;
        end
    end
end

