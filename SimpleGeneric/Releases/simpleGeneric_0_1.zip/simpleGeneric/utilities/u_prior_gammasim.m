function theta = u_prior_gammasim(nsim, prior)
%  Simulate from the gamma prior distribution, x ~ gamma(shape, scale);
%  x = exp(theta), theta = log(x)
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior     Prior structure created by u_prior_gammasetup
%
%  Output:
%  theta     Simulated random variables (nsim x 1)

if prior.con
    lower = prior.constraints.a/prior.constraints.D;
    upper = prior.constraints.b/prior.constraints.D;
    plower = gamcdf(lower, prior.shape, prior.scale);
    pupper = gamcdf(upper, prior.shape, prior.scale);
    p = unifrnd(plower, pupper, nsim, 1);
    theta = log(gaminv(p, prior.shape, prior.scale));
else
    theta = log(gamrnd(prior.shape, prior.scale, nsim, 1));
end

if prior.mix
    [~, theta] = u_mixedrnd(theta, log(prior.mixed.mass), ...
        prior.mixed.prob, prior.mixed.r, prior.mixed.s);
end

end