function yes = u_compare(x, y)
%  Determine whether two arrays are identical.  (Note a column vector n x 1
%  and its transpose are not identical if n > 1.)
%  Inputs:
%  x     First array
%  y     Second array
%
%  Output:
%  yes   Indicator for x and y identical

if any(size(x)~=size(y))
    yes = false;
    return
end

a = all(x == y);
for i = 1:ndims(x)-1
    a = all(a);
end
yes = squeeze(a);

end