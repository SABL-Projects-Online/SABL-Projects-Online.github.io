function logp = u_normtruncprob(mu, sig, astar, bstar)
%  Evaluate log(P(a < x < b) for X ~ N(mu, sig^2).  For |b| small enough
%  or |a| large enough that direct cdf evaluation would yield probability
%  zero, the function uses a Mills ratio approximation to the cdf.
%
%  Inputs:
%  mu    Mean of untruncated distribution
%  sig   Standard deviation of untruncated distribution
%  a     Lower truncation point
%  b     Upper truncation point
%
%  Outputs:
%  logp  log(P(a < X < b)) for X ~ N(mu, sig^2))

a = (astar - mu)/sig;
b = (bstar - mu)/sig;
if a >= b
    error('astar = %22.15e >= bstar = %22.15e', astar, bstar)
end
if a > 0
    bb = -a;
    a = -b;
    b = bb;
end

if b > -35
    p = normcdf(b) - normcdf(a);
    if p > 0
        logp = log(p);
    else
        logp = log(0.5*(normcdf(b) + normcdf(a))*(b-a));
    end
else
    if isfinite(a)
        logcdfa = -0.5*a^2 - log(-a) - 0.5*log(2*pi);
        logcdfb = -0.5*b^2 - log(-b) - 0.5*log(2*pi);
        logp = logcdfb + log(1 - exp(logcdfa - logcdfb));
    else
        logp = -0.5*b^2 - log(-b) - 0.5*log(2*pi);
    end
end

end