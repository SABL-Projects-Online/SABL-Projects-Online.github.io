function y = u_max(x, dim, parallel)
%  Replicate the Matlab function max(x, dim) with efficient handling
%  of the multiple-worker case. In the multiple worker case the array
%  sizes must be the same for all workers. 
%  All 3 inputs are required.
%
%  Inputs:
%  x  	     The multidimensional array.
%  dim	     Dimension of the array along which the maximum is computed
%  parallel  Indicator for multiple workers
%
%  Output:
%  y        Maximum

y = max(x, [], dim);
if parallel
    y = max(gcat(y, dim),[], dim);
end

end