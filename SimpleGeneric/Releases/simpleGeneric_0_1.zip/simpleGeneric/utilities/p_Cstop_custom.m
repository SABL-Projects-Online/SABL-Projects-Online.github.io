function p_Cstop_custom
%  This is a Matlab function written by the user that determines when
%  to stop the C phase
%
%  Input:
%  stage       Current stage of the SABL algorithm
%
%  Output:
%  moreCsteps  Indicator to continue with another C phase step

error('User-provided Matlab function p_Cstop_custom not found.')

end