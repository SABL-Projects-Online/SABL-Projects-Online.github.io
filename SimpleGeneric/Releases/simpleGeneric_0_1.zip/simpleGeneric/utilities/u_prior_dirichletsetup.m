function prior = u_prior_dirichletsetup(prior_in)
%  Map alternative specifications of a Dirichlet prior distribution
%  function into a standard specification. Check for specification errors.
%  Inputs:
%  Input:
%  prior_in        Structure expressing the prior distribution:
%    .avector      Parameter vector  (n x 1);  OR,
%    .a            Common value of all elements of avector  AND
%    .n            Order of the distribution
%
%  Output:
%  prior           Structure expressing the prior distribution. The
%                  following fields are added:
%    .name         'Dirichlet'
%    .n            Order of the distribution
%    .npars        Corresponding order of theta
%    .lognormconst Log normalizing constant

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'Dirichlet';

if isfield(prior, 'avector')
    u_is('positivereal', 'prior.avector', prior.avector)
    prior.n = length(prior.avector);
    
elseif isfield(prior, 'a') && isfield(prior, 'n')
    u_is('positivereal', 'prior.a', prior.a)
    u_is('positiveinteger', 'prior.n', prior.n)
    if prior.n == 1
        error('prior.n = 1 is not valid')
    end
    prior.avector = repmat(prior.a, prior.n, 1);
    
else
    error('No valid prior hyperparameter fields')
end

prior.npars = prior.n - 1;
prior.asum = sum(prior.avector);
prior.lognormconst = ...
    gammaln(sum(prior.avector)) - sum(gammaln(prior.avector));

end