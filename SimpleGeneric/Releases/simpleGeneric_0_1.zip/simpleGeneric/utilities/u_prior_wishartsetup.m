function prior = u_prior_wishartsetup(prior_in)
%  Map alternative specifications of a Wishart prior distribution function 
%  into a standard specification. Check for specification errors.  This is
%  done by means of adding fields to the prior specification structure
%  provided by the user.  The p.d.f. is
%  log[p(X|V)] = lognormconst + 0.5(n-df-1)log(det(X)) - 0.5tr(inv(V)X),
%  lognormconst = -0.5np*log(2) - 0.5nlog(det(V)) 
%                                 - sum (i=1,...,n)log(gamma(0.5(df+1-i)))
%  where V is the variance (scale) parameter of the distribution.
%
%  Input:
%  prior_in        Structure expressing the prior distribution:
%    .variance     Variance parameter V; OR,
%    .precision    Precision (inverse of variance parameter V); OR,
%    .std          V is diagonal, diag(V) = prior.std.^2
%    .df           Degrees of freedom of the Wishart prior distribution
%    
%  Output:
%  prior           Structure expressing the prior distribution. The
%                  following fields are added:
%    .name         'Wishart'
%    .n            Order of the distribution
%    .npars        Corresponding order of theta
%    .var          V, the variance (scale) parameter of the distribution
%    .precfactor   Matrix F: F*F' = inv(V)  (n x n)      
%    .lognormconst Log of prior density normalizing constant

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'Wishart';

if isfield(prior, 'variance')
    u_is('positive_definite', 'prior.variance', prior.variance)
    prior.var = prior.variance;
    
elseif isfield(prior, 'precision')
    u_is('positive_definite', 'prior.precision', prior.precision)
    prior.var = prior.precision\eye(size(prior.precision, 1));
    
elseif isfield(prior, 'std')
    u_is('positivereal', 'prior.std', prior.std)
    prior.var = diag(prior.std.^2);
    
else
    error('No valid prior hyperparameter field')
end

prior.n = size(prior.var, 1);
prior.npars = 0.5*prior.n*(prior.n+1);
if prior.df <= prior.n
    error('prior.df %d must exceed order - 1 = %d', prior.df, prior.n-1)
end

prior.precfactor = inv(chol(prior.var))';

prior.lognormconst = prior.n*log(2) ...
    - (0.5*prior.df*log(det(prior.var)) ...
    + 0.5*prior.n*prior.df*log(2) ...
    + 0.25*prior.n*(prior.n-1)*log(pi) + ...
    + sum(gammaln((prior.df+(1-prior.n:0))*0.5)));

end