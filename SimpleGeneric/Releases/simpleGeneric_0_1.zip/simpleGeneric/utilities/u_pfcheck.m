function [chi2testout,ptestout] = u_pfcheck(x,pf,display)
%  This function tests the hypothesis that a random sample from a
%  discrete univariate distribution was in fact generated from a given 
%  probability function.  The test is the conventional chi-square goodness 
%  of fit test. The theory is asymptotic, requiring that the number of 
%  sampled values be large relative to the number of points of support.  
%  It is based on Pearson's Chi-squared test.
%  Function is designed for use with CPU, 1 worker.
%
%  Inputs:
%  x           Sample of random variables (N x 1)
%  pf          Corresponding evaluations of the pdf;  N x 1 vector
%  display     If true then display the results of the tests
%
%  Outputs (both optional):
%  chi2testout Test statistic
%  ptestout    Evaluation of test statistic at chisquare cdf

N = size(x,1);
ncell1 = floor((1/10^(1/3))*(N^(1/3)));
inv_cdf = zeros(ncell1-1,1);

%  Count the frequency for each bin (such that n(k)/N) above. Note that
%  n(k) counts the value x(i) if edges(k) <= x(i) < edges(k+1) and the last
%  bin counts any values of x that match edges(end). In this function, the
%  edges(start) is always -inf and edges(end) is always inf. Thus,
%  size(b)=size(ct) is at least 3 after grouping. (e.g. For Bernoulli case,
%  b is [-inf; 1; inf])
for i = 1:(ncell1-1)
    inv_cdf(i,1) = quantile(x,i/ncell1);
end
b = floor(unique([-inf ; inv_cdf; inf]));
ct = (1/N)*histc(x,b);   

m = size(b,1);% m also equals size(ct,1).
while sum(ct >= 0.5/(m-1)) ~= (m-1)
    id = find(ct < 0.5/(m-1),1);
    if id ~= (m-1)
        temp = zeros(m-1,1);
        for i = 1:id
            temp(i) = b(i);
        end
        for i = (id+2):m
            temp(i-1) = b(i);
        end
        b = temp;
        ct = (1/N)*histc(x,b);
    else 
        temp = zeros(m-1,1);
        for i = 1:(m-2)
            temp(i) = b(i);
        end
        temp(m-1) = b(m);
        b = temp;
        ct = (1/N)*histc(x,b);
    end
    m = size(b,1);
end

%  To make sure that the true p valus are calculated correctly, the two
%  tails are grouped as one. (e.g. For Poisson distribution, we evaluate
%  the probabilities for the bins in the mid. Then use one minus these
%  probabilities to get the probability of the two tails. The reason is
%  that the observations can not include all the possible output no matter
%  how large the smaple size is. It implies that if we only evaluate the
%  observations in the two tails through pdf, the sum of true p values will
%  be less than one for sure.)

%  Calculate phat values
if m > 3              % For the cases which have more that two outputs.
    phat = zeros(m-2,1);
    phat(1:(m-3),1) = ct(2:(m-2),1);
    phat(m-2,1) = ct(1) + ct(m-1);
elseif m == 3         % For Bernoulli case
    phat = ct(1:2,1);
else
    error('Size of outputs are incorrect')
end

%  Calculate p values
if m > 3              % For the cases which have more that two outputs. 
    bb = cell(m-1,1);
    for i = 2:(m-2)
        l = 1;
        temp = zeros(b(i+1)-b(i),1);
        for j = b(i):(b(i+1)-1)
            temp(l,1) = j;
            l = l+1;
        end
        bb{i} = temp;
    end 
    p = zeros(m-2,1);
    for i = 2:(m-2)
        zioccurs = ismember(x,bb{i},'rows');
        pfs = unique(pf(zioccurs));
        p(i-1,1) = sum(pfs);
    end
    p(m-2,1) = 1-sum(p(1:(m-3),1));  
elseif m == 3         % For Bernoulli case
    p = zeros(2,1);
    zioccurs = ismember(x,b(2),'rows');
    pfs = unique(pf(zioccurs));
    p(2,1) = pfs;
    p(1,1) = 1-p(2,1);
else
    error('Size of outputs are incorrect')
end

% chi2test = (phat-p)'*pinv((1/N)*(diag(p)-p*p'))*(phat-p);
% The above equation generates the same number as below.
chi2test = N*sum(((phat-p).^2)./p);
if m > 3
    ptest = chi2cdf(chi2test,m-3);
elseif m == 3
    ptest = chi2cdf(chi2test,1);
else
    error('Size of outputs are incorrect')
end
if display
    fprintf('  Test of consistency between pf and simulation\n')
    fprintf('  Number of simulations: %d\n',N)
    if m > 3
        fprintf('  Number of bins used for test: %d\n',m-2)
        fprintf('  Test statistic ~ chisquare(%d): %9.5f\n',m-3,chi2test)
    elseif m == 3
        fprintf('  Number of bins used for test: %d\n',2)
        fprintf('  Test statistic ~ chisquare(%d): %9.5f\n',1,chi2test)
    end
    fprintf('  Evaluated at cdf: %8.5f\n',ptest)
end
if nargout>0
    chi2testout = chi2test;
end
if nargout>1
    ptestout = ptest;
end

end
