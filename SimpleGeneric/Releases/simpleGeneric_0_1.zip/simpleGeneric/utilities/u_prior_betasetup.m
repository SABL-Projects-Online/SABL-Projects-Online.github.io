function prior = u_prior_betasetup(prior_in)
%  Map alternative specifications of a beta prior distribution function 
%  into a standard specification.  Set up handling of optional inequality 
%  constraints and/or mixed discrete-continuous variant. Check for 
%  specification errors. 
%
%  Input:
%  prior_in           Structure expressing the prior distribution:
%    .a, .b           Conventional a and b parameters; OR,
%    .mean,  .std     Mean and standard deviation
%    .constraints     See function u_constraintssetup    
%    .mixed           See function u_mixedsetup
%
%  Output:
%  prior              Structure expressing the prior distribution. The 
%                     following fields are added:
%    .name            'beta'
%    .a               Conventional a parameter
%    .b               Conventional b parameter
%    .n               Order of the distribution (1)
%    .npars           Corresponding order of theta (1)
%    .lognormconst    Log of gamma prior density normalizing constant
%    .con             Indicator for constraints
%    .mix             Indicator for mixed distribution
%    .constraints     See function u_constraintssetup    
%    .mixed           See function u_mixedsetup

trans = @(x) log(x./(1-x));

prior = prior_in;
prior = u_tidyfields(prior);
prior.name = 'beta';
prior.n = 1;
prior.npars = 1;

if isfield(prior, 'a') && isfield(prior, 'b')
    u_is('positivereal', 'prior.a', prior.a)
    u_is('positivereal', 'prior.b', prior.b)
    
elseif isfield(prior, 'mean') && isfield(prior, 'std')
    u_is('openunitinterval', 'prior.mean', prior.mean)
    u_is('positivereal', 'prior.std', prior.std)
    prior.b = prior.mean-1 + (prior.mean*(1-prior.mean)^2)/prior.std^2;
    prior.a = prior.b*prior.mean/(1-prior.mean);
    if prior.a <=0 || prior.b <=0
        error('prior.mean = %8.4f and prior.std = %8.4f not possible', ...
            prior.mean, prior.std)
    end
    
else
    error('No valid combinations of prior hyperparameter fields')
end
    
prior.lognormconst = -betaln(prior.a, prior.b);
prior = u_constraintssetup(prior);

if prior.con
    a = prior.constraints.a;
    b = prior.constraints.b;
    prior.constraints.logG = ...
        log(betacdf(b, prior.a, prior.b) - betacdf(a, prior.a, prior.b));
    if a < 0 || b > prior.constraints.D
        error('Constraint set not a subset of the domain [0, 1]')
    end
end

prior = u_mixedsetup(prior, @u_prior_beta, trans);

if prior.mix && prior.con
    if prior.con
        z = prior.constraints.D*prior.mixed.mass;
        if any(z < a || z > b)
            error('Mixed distribution mass points violate constraints')
        end
    else
        if any(prior.mixed.mass < 0) || any(prior.mixed.mass > 1)
            error('Mixed distribution mass points must be in [0, 1]')
        end
    end
end

prior.simple = ~(prior.con || prior.mix);

end