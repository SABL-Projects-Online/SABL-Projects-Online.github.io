function p_thetapar
%  This is a user-written function invoked only if the model parameter maps
%  contain nonlinear functions of the algorithm parameter vector theta.
%  p_thetapar is a Matlab function.
%  
%  Inputs:
%  theta    The C.JN x C.parameters matrix of particles
%  name     Assigned by the model to indicate which map is being
%           constructed. The model documentation provides the names
%  ii       Vector with one entry for each model parameter that is a
%           nonlinear function of theta. The entry ii(r) is the row i of
%           the map leading to the r'th nonlinear transformation.
%  jj       Vector with one entry for each model parameter that is a
%           nonlinear function of theta. The entry jj(r) is the column j of
%           the map leading to the r'th nonlinear transformation.
%  columns  ector with one entry for each model parameter that is a
%           nonlinear function of theta. The entry columns(r) is the 
%           column of A_in that is missing (i.e., entirely zero) on input
%           that will be filled on output using the r'th nonlinear 
%           transformation
%  A_in     Matrix of model parameters with C.JNwork rows. At input all but
%           the parameters with nonlinear maps have been filled.
%
%  Output:
%  A        Same as A_in but with columns requiring non-linear
%           transformations filled.

error('User-provided Matlab function p_thetapar not found.')

end