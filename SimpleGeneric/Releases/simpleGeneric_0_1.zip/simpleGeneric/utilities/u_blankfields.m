function M = u_blankfields(M_in, varargin)
%  Check for the presence of one or more fields in a structure.
%  If a field does not exist create it and set its contents to [].
%
%  Inputs:
%  M_in      Structure
%  varargin  List of fields being checked (cell array of strings)
%
%  Output:
% M          M_in with the addition of new fields not present in M_in

M = M_in;
n = length(varargin);
for i = 1:n
    if ~isfield(M_in, varargin{i})
        M.(varargin{i}) = [];
    end
end

end