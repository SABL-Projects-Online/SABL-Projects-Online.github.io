function dperm = u_permute(vTarget,vD)
    vPerms = 1:vD;
    vS = 1:length(vTarget);
    dperm(vTarget) = vS;
    vPerms(vTarget) = [];
    dperm(vPerms) = (1+length(vTarget)):vD;
end