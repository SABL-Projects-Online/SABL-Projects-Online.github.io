function R = u_runtest(pustatus, npars, model, project)
%  This code runs the a model under combinations of several
%  variants of the SABL algorithm and the computing environment.
%  There are two objectives:
%  (1) Successful execution of all the combinations, as indicated by
%      the absence of error messages
%  (2) Organize the results of the run in a structure, saved to file
%      for subsequent analysis by the function u_testrun_study
%
%  Inputs:
%  pustats    (1,1)  Indicator for one CPU, one worker
%             (1,2)  Indicator for CPU, two workers
%             (2,1)  Indicator for one GPU
%             (2,2)  Indicator for two GPUs
%  GPU        Indicator to test with E.gpu = true
%  workers2   Indicator to test with E.pus = 2
%  npars      Length of the parameter vector
%
%  Output:
%  The code creates several 7-dimensional arrays, each a field of the
%  structure R. The dimensions indicate algorithm variants or computing
%  environments are follows.
%  R.*(iw,:,:,:,:,:,:)   iw = 1, 1 worker; i = 2, 2 workers
%  R.*(:,iGPU,:,:,:,:,:) iGPU = 1, CPU; iGPU = 2, GPU
%  R.*(:,:,iC,:,:,:,:)   iC = 1, C phase method data_whole; 
%                        iC = 2, C phase method anneal_Bayes;
%                        iC = 3, C phase method anneal_optimal                 
%  R.*(:,:,:,iM,:,:,:)   iM = 1, M phase method MGRW_simple; 
%                        iM = 2, M phase method MGRW_blocked                    
%  R.*(:,:,:,:,itp,:,:)  itp = 1, One pass; itp = 2, two passes
%  R.*(:,:,:,;,:,igr,:)  i = 1, Use sample part 1, no E.simulation_record;
%                        i = 2, Use part 1, write E.simulation_record;
%                        i = 3, Read part 1 from E.simulation_get, complete
%                               with sample part 2
%                        i = 4, Run entire sample at once
%  Arrays are as follows.
%  R.meantheta(:,:,:,:,:,:,1:2)  mean(C.theta)
%  R.stdtheta(:,:,:,:,:,:,1:2)   std(C.theta)
%  R.nse(:,:,:,:,:,:,1:2)        nse(C.theta)
%  R.logml(:,:,:,;,:,:)          log marginal likelihood
%  R.logmlnse(:,:,:,;,:,:)       log marginal likelihood NSE
%
%  Other communication:
%  The code creates arrays and constants in the global P structure
%  that p_monitor then maps into approriate fieds of the global C, E
%  and M structures.

global C E M P Cpar Epar Mpar Ppar

P.test = true;
P.Cphase_method{1} = 'data_whole';
P.Cphase_method{2} = 'anneal_Bayes';
P.Mphase_method{1} = 'MGRW_simple';
P.Mphase_method{2} = 'MGRW_blocked';

R = struct;
R.errors = cell(2, 2, 2, 2, 2, 4);
R.meantheta = zeros(2, 2, 2, 2, 2, 4, npars);
R.stdtheta = zeros(2, 2, 2, 2, 2, 4, npars);
R.nsetheta = zeros(2, 2, 2, 2, 2, 4, npars);
R.logml = zeros(2, 2, 2, 2, 2, 4);
R.logmlnse = zeros(2, 2, 2, 2, 2, 4);
R.cell = false(2, 2, 2, 2, 2, 4);
multipars = npars > 1;
errormess = 0;
for iw = 1:2
    P.workers = iw;
    for iGPU = 1:2
        if ~pustatus(iGPU, iw)
            continue
        end
        if iw == 2 && isempty(gcp('nocreate'))
            parpool(2);
        end
        P.gpu = iGPU;
        for iC = 1:2
            P.Cphase = iC;
            %for iM = 2:2
            for iM = 1:multipars + 1
                P.Mphase = iM;
                for itp = 1:2
                    P.twopass = itp;
                    for igr = 1:4
                        if itp == 2 && (igr == 2 || igr == 3)
                            continue % No two-pass with get/record
                        end
                        P.step = igr - 1;
                        tic;
                        errors = false;
                        try
                            SABL(model, project);                            
                        catch ME
                            P.errors{iGPU, iw, iC, iM, igr} = ME;
                            errors = true;
                        end
                        if errors
                            disp(ME.identifier)
                            disp(ME.message)
                            func = ME.stack.file;
                            line = ME.stack.line;
                            fprintf('\n ERROR in line %d of file\n%s\n', ...
                                line, func)
                            errormess = errormess + 1;
                            pause
                        else                            
                            R.cell(iGPU, iw, iC, iM, itp, igr) = true;
                        end
                        clear global C E M Cpar Epar Mpar Ppar
                        ttime = toc;
                        if ~errors                                  
                            R.meantheta(iGPU, iw, iC, iM, itp, igr, :) = ...
                                gather(P.tmean);
                            R.stdtheta(iGPU, iw, iC, iM, itp, igr, :) = ...
                                gather(P.tstd);
                            R.nsetheta(iGPU, iw, iC, iM, itp, igr, :) = ...
                                gather(P.tnse);
                            R.logml(iGPU, iw, iC, iM, itp, igr) = ...
                                gather(P.logml1);
                            R.logmlnse(iGPU, iw, iC, iM, itp, igr) = ...
                                gather(P.logmlnse);
                        end
                        fprintf('\nruntest progress:\n')
                        fprintf(' iGPU = %d, iw = %d, iC = %d, iM = %d,',...
                            iGPU, iw, iC, iM)
                        fprintf(' itp = %d, igr = %d\n',itp, igr)
                        fprintf(' complete in%8.3f seconds\n', ttime)
                    end
                end
            end
        end
    end
end
fprintf('\n  %d error messages issued\n', errormess)
if ~isempty(gcp('nocreate'))
    delete(gcp)
end
if exist('simfile.mat', 'file')
    delete simfile.mat
end

end
