function fullpath = u_getsablroot(downstream)
% Get the full path of the root of this copy of SABL.

if 1 > nargin || isempty(downstream)
	downstream = mfilename('fullpath');
else
	if ~ischar(downstream) || 7 ~= exist(downstream,'dir')
		fullpath = '';
		return;
	else
		[~,info] = fileattrib(downstream);
		downstream = info.Name;
	end
end

b = regexp(downstream, filesep, 'split');
fullpath = '';
found = false;
l = length(b);
t = 0;
for i=1:l
    if ~isempty(regexp(b{1+l-i},'^SABL','match')) 
	found = true;
	t = 1+l-i;
	break;
    end
end 
if found
    fullpath = b{1};
    for i = 2:t
	fullpath = [fullpath filesep b{i}];
    end
else
    fullpath = '';
end

end