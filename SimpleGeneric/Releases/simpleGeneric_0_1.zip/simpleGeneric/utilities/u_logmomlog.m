function [logmeanx, logvarx] = u_logmomlog(logx, dim, parallel)
%  Replicate the Matlab functions log(mean(exp(logx), dim)) and 
%  log(var(exp(logx, [], dim))), avoiding error when
%  the elements of exp(logx) are beyond the range of floating point 
%  representation and with efficient handling of the multiple-worker case.
%  In the multiple-worker case array sizes must be the same on all workers.
%  All 3 inputs are required.
%
%  Inputs:
%  logx      Log of array elements (two dimensional)
%  dim	     Dimension along which to compute the mean (dim = 1 or dim = 2)
%  parallel  Indicator for multiple workers
%
%  Outputs:
%  logmeanx  Log of mean along dimension dim
%  logvarx   Log of variance along dimension dim (optional)

maxlogx = u_max(logx, dim, parallel);

if dim == 1
    logy = logx - repmat(maxlogx, size(logx, dim), 1);
else
    logy = logx - repmat(maxlogx, 1, size(logx, dim));
end
y = exp(logy);
ymean = u_mean(y, dim, parallel);
logmeanx = log(ymean) + maxlogx;
if nargout == 2
    logvarx = 2*(log(u_std(y,dim,parallel)) + maxlogx);
end

end