function ok = u_isfield(struc, field, errmess, name)
%  Function checks to see that a field is present in a structure and has
%  content.
%
%  Inputs:
%  struc      The structure
%  field      Name of the field (string)
%  errmess    Indicator to terminate with error if field is not present
%             or is present but empty
%  name       String with the name of the structure
%
%  Output:
%  ok         Indicator for field present and not empty

if nargin == 4
    em = errmess;
else
    em = false;
end

if isfield(struc, field)
    ok = ~isempty(struc.(field));
    if ~ ok && em
        error('The field %s.%s is needed and present but empty', ...
            name, field)
    end
else
    ok = false;
    if em
        error('The field %s.%s is needed but absent', name, field)
    end
end

end