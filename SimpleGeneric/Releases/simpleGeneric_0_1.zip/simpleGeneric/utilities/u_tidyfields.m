function structure = u_tidyfields(structure_in)
%  Put all the fields of a structure in ASCII dictionary order and replace
%  any row vectors by their transpose.
%
%  Input:
%  structure_in   Structure before being tidied
%
%  Output:
%  structure      Structure after being tidied
%
%  Typical use is structure = u_tidyfields(structure)

structure = orderfields(structure_in);
fields = fieldnames(structure);
nfields = length(fields);
if nfields == 0
    return
end
for ifield = 1:nfields
    field = structure.(fields{ifield});
    if isstruct(field)
        field = u_tidyfields(field);
    elseif isnumeric(field)
        if (ndims(field) == 2)
            if size(field,1) == 1
                field = field';
            end
        end
    end
    structure.(fields{ifield}) = field;
end

end