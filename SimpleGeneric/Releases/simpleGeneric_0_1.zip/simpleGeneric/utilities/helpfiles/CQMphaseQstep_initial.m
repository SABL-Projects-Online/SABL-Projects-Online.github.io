function CQMphaseQstep_initial
% C.Mphase.step_initial 
% In the Mphase algorithms this is the initial multiplicative factor for 
% converting the covariance matrix of particles to the variance matrix of 
% the Metropolis Gaussian random walk. 
%
% CONTROL FIELD  Core default value: 0.5

end