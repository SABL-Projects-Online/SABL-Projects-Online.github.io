function CQdetailQendCphase
% C.detail.endCphase
% Indicator field for display at the end of the C phase. 
%
% CONTROL FIELD  Core default: 'true' if C.detail_level is 6 or 7.

end