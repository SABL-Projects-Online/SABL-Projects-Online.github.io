function CQMphaseQrne
% C.Mphase.rne
% Mean value of RNE across the functions g = m_rnefunctions(theta), set in 
% each step of the M phase
%
% MONITOR FIELD

end