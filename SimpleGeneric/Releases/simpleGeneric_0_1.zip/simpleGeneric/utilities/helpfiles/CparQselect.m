function CparQselect
% Cpar.select
% In the S phase parent particles are replaced by children. 
% Child particle matrix Cpar.theta 
%           = Parent particle matrix Cpar.theta(Cpar.select,:).C.JNwork x 1
% MONITOR FIELD


end

