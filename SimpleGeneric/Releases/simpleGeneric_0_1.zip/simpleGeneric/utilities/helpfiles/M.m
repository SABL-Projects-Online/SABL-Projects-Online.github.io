function M
% 
% One of the eight SABL parent global structures. The M structure is model
% specific and therefore no documentation is available through this
% command. Instead use
%        help [modelname] M

end

