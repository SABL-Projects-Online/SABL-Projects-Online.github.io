function CQMphaseQsigmafactor
% C.Mphase.sigmafactor
% Choleski factorization of the variance matrix of particles, computed at 
% the start of each M phase
%
% MONITOR FIELD

end