function CQCstopQress 
% C.Cstop.ress 
% The relative effective sample size criterion for termination of the C
% phase. In the 'anneal_Bayes' and 'anneal_optimize' C phase algorithms the
% relative effective sample size will be this value at the termination of
% the C phase. In the 'data_whole' C phase algorithm observations are added
% until an observation causes relative effective sample size to be less
% than C.Cstop.ress.
%
% CONTROL FIELD  Core defalt: 0.5

end

