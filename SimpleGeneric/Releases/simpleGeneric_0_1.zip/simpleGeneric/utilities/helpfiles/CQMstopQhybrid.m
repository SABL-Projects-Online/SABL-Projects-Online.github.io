function CQMstopQhybrid
% C.Mstop.hybrid 
% Indicator for C.Mstop_method = 'hybrid'.
%
% MONITOR FIELD

end