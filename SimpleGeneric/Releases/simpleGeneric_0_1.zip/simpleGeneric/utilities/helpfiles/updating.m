function updating
%  In SABL it is possible to save the particles that represent a posterior
%  distribution and then subsequently, when more data have become
%  available, to retrieve the particles and update the posterior
%  distribution.  For situation in which the additional observations 
%  constitute a small fraction of the total, the savings in computation
%  time is substantial.
%
%  To save particles, in p_monitor stage 'open' set the field 
%  E.simulation_record to the name of the file to which they will be saved. 
%  (In the core default the field does not exist, indicating that particles 
%  will not be saved to file.) In fact, SABL saves all of the global 
%  structures in this file.
%
%  To update beginnning from saved particles, in p_monitor stage 'open'
%  set the field E.simulation_get to the name of the file from which all
%  global structures, including particles, will be uploaded. (In the core  
%  default the field does not exist, indicating that particles will not be 
%  read from file.) In this case the SABL algorithm begins with the
%  particles read from file in stage 'initialize' rather than simulating
%  them from the prior distribution. 
%
%  When updating, the field M.data the rows containing the new data must
%  follow all the rows containing exactly the same data that were used in
%  generating the saved particles. The fields C.tfirst and C.tlast must
%  contain the first and last observations (rows) of M.data after
%  updating. By core default C.tfirst = 1 and C.tlast is the last
%  observation of the updated M.data matrix.  The number and grouping of
%  particles C.J and C.N must (obviously, and by core default) remain the
%  same.  All other options may be changed in updating. For example, the
%  particles recorded could have been generated using C.Cphase_method
%  = 'anneal_Bayes' while updating could be accomplished using 
%  C.Cphase_method = 'data_whole'. 
%  
%  Updating is not possible if C.Cphase_method = 'anneal_optimize'.
%  It is possible to both read particles and record the updated particles
%  in the same run.  If C.twopass = true, then the particles recorded 
%  are the particles at the end of the second pass.
