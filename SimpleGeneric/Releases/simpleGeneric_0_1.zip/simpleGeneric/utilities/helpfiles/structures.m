function structures
%  Any datatype that is not specific to a single function is a field
%  in one of 8 global structures in SABL:
%  C      Core data that are the same across multiple workers
%  Cpar   Core data that differ across multiple workers
%  E      Computing environment data that are the same across 
%         multiple workers
%  Epar   Computing environment data that differ across multiple workers  
%  M      Model data that are the same across multiple workers
%  Mpar   Model data that differ across multiple workers
%
%  It is strongly suggested that users exploit the 2 global structures
%  P      Project data that are the same across multiple workers
%  Ppar   Project data that differ across multiple workers
%  because SABL will handle the overhead required if using multiple
%  workers.
%
%  The "data" nomenclature is from computer science, meaning constants,
%  arrays, strings, etc.
%  The fields Epar and Mpar are empty in SABL 2015a.  P and Ppar fields,
%  if any, are created by the user.
%
%  The command help [structure] (e.g., help C) or help [field within
%  structure] (e.g., help C.Cphase, help E.gpu) documents all the details
%  of the SABL global structure system. Every field in a structure is
%  one of three types: 
%  REQUIRED      User must specify, e.g. M.data.
%  CONTROL       SABL sets default but user can override, e.g. C.N
%                The help command provides the default value.
%  MONITOR       User can access the field in p_monitor and save it
%                to a user-defined field of the P global structure.
%    The command help [structure] or help [field within structure] if the
%    target is itself a structure, produces a brief desciption of the 
%    structure, followed by a list of each of its fields. For each field
%    the type is indicated, along with the default value if the type is
%    CONTROL.
%    Otherwise, the command help describes the field together with its
%    type, and for a control field the default value.