function CQJNwork 
% C.JNwork 
% The number of particles per Matlab worker  C.JNwork = C.JN/E.pus
%
% MONITOR FIELD

end