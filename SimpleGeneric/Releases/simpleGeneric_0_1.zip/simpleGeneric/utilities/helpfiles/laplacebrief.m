function laplacebrief
%  The (univariate) Lapalce prior distribution has support (-inf, inf),
%  density kernel
%       (lambda/2)*exp(-lambda*|x - mean|)
%  where lambda is the diversity parameter.  The variance is 2*lambda^2. 
%  The hyperparameters may be specified by
%       scalar fields mean and diversity, OR
%       scalar fields mean and std
%
%  The Lapalce prior distribution may be modified by
%      truncation to an interval (a, b) (help priorconstrainted) AND/OR
%      mixture with a discrete distribution (help priormixed)

end