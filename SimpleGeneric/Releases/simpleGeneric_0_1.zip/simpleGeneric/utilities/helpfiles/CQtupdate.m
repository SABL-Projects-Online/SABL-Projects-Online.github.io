function CQtupdate
% C.tupdate   
% The number of rows of M.data used for inference: C.tlast - C.tfirst + 1,
% set in c_monitor in stage 'startrun'.
%
% MONITOR FIELD

end