function algorithm

%  In the outline below the occurence of "Stage: [name]" indicates that 
%  control passes 
%  -> c_monitor -> m_monitor -> p_monitor -> m_monitor -> c_monitor ->
%  Fields of global structures can be created, assigned values or accessed
%  in any *_monitor function; assignments made in p_monitor override those
%  made in m_monitor override those in c_monitor. Field values specific to
%  a given application should be made in p_monitor, which is the interface
%  function written by the user.
%
%  Outline of the SABL algorithm:
%
%  Retrieve particles to be updated (if E.simulation_get specified)
%  Set SABL environment                                
%  Stage: 'open'
%  for pass = first, [second if C.twopass = true]
%    Define the problem, including priors and data     Stage: 'startrun'
%    Copy global structures from one to multiple workers if E.pus >  1
%    Draw particles from prior if not updating         Stage: 'initialize'
%    while SABL cycles = 1, 2, 3, ...
%      Stage: 'startcycle'
%      Initialize C (Correction) phase weight function
%      Stage: 'startCphase'
%      while C phase steps incomplete
%        Update the weight function                    Stage: 'whileCphase'
%      end
%      Stage: 'endCphase'
%      Stage: 'startSphase'
%      Execute S (Selection) phase
%      Stage: 'endSphase'
%      Stage: 'startMphase'
%      while M (Mutation) phase steps incomplete
%        Execute the next step                         Stage: 'whileMphase'
%      end
%      Stage: 'endMphase'
%    end
%    Stage: 'finish'
%    Stage: 'endrun'
%    Copy global structures from multiple workers to one if E.pus > 1
%  end
%  Stage: 'close'
%  Save particles for future updating (if E.simulation_record specified)
%
%  Subsidiary topics:
%     help Cphase, Sphase, Mphase
%     help environment, parametermaps, pass, updating
