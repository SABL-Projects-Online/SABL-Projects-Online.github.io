function CQCphaseQtotal
% C.Cphase.total
% Counts the number of C phase iterations in the entire algorithm. 
%
% MONITOR FIELD

end

