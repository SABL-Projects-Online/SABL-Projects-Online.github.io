function CparQtheta
% Cpar.theta
% Matrix of particles, C.JNwork x C.parameters. Each row is a distinct 
% particle and each column is a distinct parameter. If there is one worker 
% (C.pus = 1) this is the entire set of particles. If E.pus > 1 then 
% particles are allocated across Matlab workers (C.JNwork = C.JN/E.pus) 
% MONITOR FIELD

end

