function CQoptstatusQpower
% C.optstatus.power
% The current value of the exponent of the objective function in the  
% anneal_optimize variant of the C phase; equal to C.Cphase.power
%
% MONITOR FIELD

end