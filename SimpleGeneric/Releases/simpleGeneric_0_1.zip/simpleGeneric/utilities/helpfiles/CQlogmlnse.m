function CQlogmlnse
% C.logmlnse  
% The numerical standard error associated with the SABL approximations of 
% the log marginal likelihood. Determined and available at stage 'finish'.
%
% MONITOR FIELD

end