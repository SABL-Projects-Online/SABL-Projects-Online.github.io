function E
% E
% One of the eight SABL parent global structures
% The fields of structure E all pertain to the computing environment,
% for example E.gpu and Epus.
%
% STRUCTURE

end

