function CQwalltime
% C.walltime
% The time elapsed for the entire SABL algorithm (in seconds) set in stage
% 'finish'
%
% MONITOR FIELD

end