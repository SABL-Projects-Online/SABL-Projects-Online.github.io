function Mphase
%  There are two primary variants of the M (Mutation) phase, set in the
%  control field C.Mphase_method, whose core default value is 
%  'MGRW_simple'. In each variation M phase consists of iterations of
%  a Gaussian random walk Metropolis algorithm with a variance matrix
%  computed from the distribution of the particles at the start of the 
%  Mphase. The precise design of the Metropolis algorithm is set in the
%  control fields of the structure C.Mphase, and its termination criteria
%  are set in the control fields of the structure C.Mstop.
%
%  C.Mphase_method = 'MGRW_simple': Metropolis Gaussian random walk.
%    The variance matrix is the variance matrix of all the particles at
%    the end of the S phase, multiplied by a step factor C.Mphase.step.
%    The step factor increases by the increment C.Mphase.step_inc (core
%    default value 0.10) but never exceepds C.Mphase.step_lower (core
%    default value 2.0) and has a lower bound of C.Mphase.step_lower (core
%    default value 0.10).
%
%  C.Mphase_method = 'MGRW_blocked': The algorithm parameter vector (theta)
%    is partiitioned into blocks and in each iteration of the M phase
%    the Metropolis increment is applied separtely to each block.
%    There are two primary block partition methods set by the logical 
%    control field C.Mphase.ranblock, core default value 'true'. Consult
%    help C.Mphase.ranblock for details on the results of 'true' and
%    'false' and the additional required control fields in each case.
%
%  There are four different criteria M phase termination, set in the
%  control field C.Mstop_method (core default value 'RNE&steps'). The two
%  simplest methods are
%
%  C.Mstop_method = 'steps', which executes the algorithm for C.Mstop.steps
%    iterations (core default value 100).
%
%  C.Mstop_method = 'RNE', which executes the algorithm until the average
%    relative numerical efficiency (RNE) of a set of specified functions
%    attains at least C.Mstop.rne (core default value, 0.4). 
%
%  The two hybrid methods are
%
%  C.Mstop_method = 'RNE&steps' (the core default), in which uses the
%    C.Mstop.rne criterion but never executes more then C.Mstop.steps
%    steps.
%
%  C.Mstop_method = 'hybrid': in addition to the termination criteria of
%    'RNE&steps', terminate if at iteration s of the Metropolis algorithm
%    C.Mphase.rne/s < C.Mstop.rne/C.Mstop.steps.