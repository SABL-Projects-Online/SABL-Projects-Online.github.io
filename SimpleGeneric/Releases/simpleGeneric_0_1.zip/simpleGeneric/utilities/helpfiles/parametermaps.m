function parametermaps
%  Each SABL model uses the same system to map the algorithm paremters
%  theta (with evaluations for each particle in Cpar.theta) and the 
%  parameters of the model. Most SABL models have a default mode in which
%  the map system is transparent to the user, but to get the most out of
%  the flexibility SABL affords it is necssary to understand how the map
%  system works.
%
%  Each parameter vector or matrix in a model contains structures that
%  provide the map from theta to that vector or matrix. The parent field
%  has the name map: e.g., it is M.betmap for the conditional mean 
%  coefficients in model normal and M.Amap for the endogenous variable
%  coefficients in model MVN specification 'FI'. The matrix map has the
%  same order as the model parameter vector or matrix. The entry map(i,j)
%  indicates how to construct the map from theta to that parameter. 
%
%  In some cases the parameter component (i,j) may simply be an element
%  of theta (correspondingly, column of Cpar.theta). In this case map(i,j)
%  designates the numer of the element (column number of Cpar.theta).
%
%  If map(i,j) = 0 the parameter is identically zero. This feature is
%  redundant in many simple models, but in more complex contexts like
%  linear simultaneous equation models (model MVN, specification 'FI') it
%  arises commonly from (over) identifying restrictions. 
%
%  If map(i,j) < 0 then the element of the parameter vector or matrix
%  (i,j) is a combination of elements of the algorithm parameter vector
%  theta (and its corresponding particles are the same linear combination
%  of the columns of Cpar.theta). In this the parameter particles are
%  Cpar.theta*linc(:,-map(i,j)) + linc(C.parameters+1,-map(i,j)).
% 
%  If map(i,j) > C.parameters (i.e, beyond the extent of theta and the
%  nubmer of columns of Cpar.theta) then the element of the parameter
%  vector or matrix (i,j) is a nonlinear function of the algorithm 
%  parameter vector. In this case the user must provide a function
%  p_thetapar, written in Matlab code, that computes the nonlinear 
%  transformations. Optionally, and to potentially great advantage in 
%  some complext models, the user may provide a function P-thetapar_CUDA
%  written in C/CUDA code, that is then invoked if E.gpu = true. Consult
%  help p_thetapar and p_thetapar_CUDA for the details of the inputs and 
%  output arguments of these functions if there are such nonlinear 
%  transformations.