function CQstagestep
% C.stagestep
% Set in c_monitor to 'premonitor' before invoking m_monitor, to 
% 'postmonitor' after invoking p_monitor, and to 'nomonitor' just before
% leaving c_monitor. This permits finer determination of the point that
% functions have been invoked. This is important in the functions c_Cphase,
% c_Sphase, c_Mphase and the functions they invoke, in determining whether
% or not to return a termination indicator and in ensuring that information
% is displayed exactly once.
%
% MONITOR FIELD

end