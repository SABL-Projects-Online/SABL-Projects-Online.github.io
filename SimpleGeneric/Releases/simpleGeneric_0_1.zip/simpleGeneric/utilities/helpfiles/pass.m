function pass
%  In the two-pass variant of the SABL algorithm, the algorithm executes
%  in the usual way in the first of two passes. In particular, the 
%  particles themselves are generally used to determine the extent of
%  updating in the C phase (by means of C.Cstop.ress), as they are in
%  the execution of the M phase (by means of the construction of the
%  Metropolis randome walk, the determination of the scale factor
%  C.Mphase.step at each iteration, and generally in termination of the
%  M phase based on the relative numerical efficiency of some functions of
%  the particles.
%
%  Most of the theory that underlies SABL presumes a fixed rather than
%  an adaptive algorithm, one in which the design of the algorithm
%  (extent of updating in the C phase and the precise form of the M phase)
%  do not depend on the random particles themselves. This renders the 
%  theory not directly applicable to practical applictions because in 
%  those applications it is essential to use the particles themselves to
%  design an algorithm that is sufficiently efficient for practical use.
%
%  The second of the two passes uses the algorithm designed in the first
%  pass (that is: the extent of the updating in the C phase, and the
%  Metropolis variance matrix, scale factors, and number of iterations in
%  the M phase) that were determined in the first pass. The random
%  particles generated in the second pass are independent of those 
%  generated in the first pass. The second pass thereby conforms to the
%  the conditions of the theory while achieving the efficiency made 
%  possible by using the particles themselves to design the algorithm.
%
%  To use the two-pass variant of the algorithm all that is needed is
%  to declare C.twopass = true in stage 'startrun' of p_monitor. If
%  p_montior harvests monitor fields during execution, C.passone = true
%  will indicate that SABL is in the first of the two passes, C.passsone =
%  false that it is in the second.