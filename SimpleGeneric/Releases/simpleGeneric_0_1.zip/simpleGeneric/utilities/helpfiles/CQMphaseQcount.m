function CQMphaseQcount
% C.Mphase.count 
% Counts the number of M phase iterations in the current cycle. 
%
% MONITOR FIELD

end