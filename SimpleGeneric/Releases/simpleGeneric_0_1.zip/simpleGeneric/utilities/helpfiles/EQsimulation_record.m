function EQsimulation_record 
% E.simulation_record 
% Contains the name of a file to which global structures will be written at
% the conclusion of the SABL algorithm. If the field is empty then these
% structures are not recorded.
%
% CONTROL FIELD  Core default: Field is absent

end
