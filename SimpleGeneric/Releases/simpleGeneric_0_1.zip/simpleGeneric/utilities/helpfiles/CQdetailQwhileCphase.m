function CQdetailQwhileCphase
% C.detail.whileCphase 
% Indicator field for displaying during the C phase. 
%
% CONTROL FIELD  Core default: 'true' if C.detail_level >= 8

end