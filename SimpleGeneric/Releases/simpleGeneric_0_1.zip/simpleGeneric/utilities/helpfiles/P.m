function P
% 
% One of the eight SABL parent global structures. The P structure is 
% reserved for data created by the user as part of a project (application)
% that has the same value across all workers when multiple CPUs or GPUs
% are explicitly employed.
%
% Since the P structure is project specific, no SABL documentation is
% available.

end

