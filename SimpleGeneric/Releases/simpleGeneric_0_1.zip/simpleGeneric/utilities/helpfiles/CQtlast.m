function CQtlast
% C.tlast
% The last row of M.data used in the current run of SABL. 
% Case 1:
% The user sets C.tlast to a row of M.data (C.tlast > C.tfirst)
%
% Case 2:
% If not set by the user SABL sets C.tlast = size(M.data, 1)
%
% CONTROL FIELD  (Case 1)  MONITOR FIELD (Case 2)

end