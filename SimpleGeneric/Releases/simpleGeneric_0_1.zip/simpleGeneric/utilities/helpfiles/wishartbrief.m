function wishartbrief
%  The (multivariate) Wishart prior distribution has support on the space
%  of n x n positive defiite matrices X, with denisty kernel
%        det(X)^[(df-n-1)/2)] * exp{trace[(V^-1)*X]/2}
%  where V is the n x n positive definite scale matrix and df > n-1 is
%  the degrees of freedom parameter.
%  The hyperparameters are df (positive scalar field df) and either
%         n x n matrix field variance (= V) OR
%         n x n matrix field precision (= V^-1), OR
%         n x 1 positive vector field std, in which case V = diag(std.^2)
%
%  A random positive definite matrix is represented in SABL through
%  its Choleski factor A where A'A = X, A is upper triangular, and
%  diag(A) > 0. The matrix A has row major vector representation omitting
%  the elements of A below the diagonal (which are identically zero).

end