function CQdetailQstartupC
% C.detail.startupC 
% Indicator field for displaying in the C phase at stage 'startrun'. 
% CONTROL FIELD  Core default: 'true' if C.detail_level >= 2

end