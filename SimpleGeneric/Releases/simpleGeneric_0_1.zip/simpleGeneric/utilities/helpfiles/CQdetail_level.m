function CQdetail_level
% C.detail_level 
% The field controls the level of detail in information returned to the 
% screen as the SABL algorithm executes. Values are integers in the range 0
% to 10, and 7 is the default. The level of detail is specific to variants 
% of the various phases of the SABL algorithm and the model being used. If 
% you don't see what you want increase the value and if there is too much 
% information then decrease the value. An alternative is to modify fields 
% of the C.detail structure. With rare exception any print statement from 
% model specific code should condition on a logical variable and the 
% logical variable should be linked to C.detail_level.
%
% CONTROL FIELD  Core default: 7

end