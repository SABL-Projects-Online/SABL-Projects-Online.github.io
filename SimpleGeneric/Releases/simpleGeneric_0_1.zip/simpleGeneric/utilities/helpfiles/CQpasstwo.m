function CQpasstwo 
% C.passtwo 
% Indicator for pass two of the SABL two-pass algorithm. 
%
% MONITOR FIELD

end