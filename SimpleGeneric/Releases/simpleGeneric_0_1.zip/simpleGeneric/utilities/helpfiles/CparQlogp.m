function CparQlogp  
% Cpar.logp  
% Evaluation of the log-likelihood or objective function, multiplied by the 
% intensity vector, of the accepted particles in the current step of the M 
% phase. C.JNwork x 1. 
% MONITOR FIELD

end

