function CQoptstatusQfracmax
% C.optstatus.fracmax
% In the anneal_optimize algorithm this is the fraction of particles for 
% which the evaluation of the objective function is identical and is equal
% to the maximum value of the objective function taken across all particles
%
% MONITOR FIELD

end