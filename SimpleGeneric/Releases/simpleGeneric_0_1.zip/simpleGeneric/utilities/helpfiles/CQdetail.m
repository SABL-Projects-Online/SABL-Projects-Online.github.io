function CQdetail 
% C.detail 
% This field is a structure containing indicator fields determining whether 
% SABL displays information at various stages. This permits the user to 
% exercise finer control over displays than is possible with 
% C.detail_level. Default values of fields determined by C.detail_level
%
% STRUCTURE

end