function environments
%  SABL will execute using one or more central processing units (CPUs)
%  or, alternatively, one or more graphics processing units (GPUs).
%  The field E.gpu discriminates between CPUs (E.gpu = false) and
%  GPUs (E.gpu = true). The field E.pus indicates the number of processing
%  units. If E.gpu = true or E.pus > 1 then the Matlab Parallel toolbox
%  must be installed. If E.pus > 1, then the user must have declared 
%  the number of workers to be at least E.pus before SABL is invoked.
%
%  If E.gpu = false and E.pus = 1 (the core default) then code written by
%  the user can default to conventional Matlab code. In this case Matlab
%  attempts to efficiently use all the CPU cores available, and it is 
%  often highly efficient in doing so. (The final output to the command
%  window at the conclusion of SABL states CPU time in seconds and elapsed
%  time in seconds, and the ratio of the former to the latter can approach
%  the number of cores depending on the model and application.)
% 
%  If E.pus > 1 or E.gpu = true, then SABL exploits the pleasingly parallel
%  structure of the algorithm to carry out operations on multiple workers
%  (E.gpu = false, E.pus > 1) or on the GPU(s) (E.gpu = true). This
%  presents substantial management overhead not apparent to the novice or
%  inexperienced user of parallel Matlab code or GPUs. SABL renders these
%  problems transparent, so long as the user does not attempt (via
%  p_monitor) to harvest monitor fields or intervene in the algorithm.
%  For the user who does wish to harvest or intervene in this way, SABL
%  provides a suite of functions that manage almost all of the additional
%  overhead that is incurred when E.gpu = true and/or E.pus > 1. To learn
%  about these functions invoke help SABLfunctions, followed by help
%  [functionname] for a specific functions.
%
%  To exploit the potential of hundreds or thousands of GPU cores, it is
%  important that computationally intensive code be written not in Matlab,
%  but in compiled C/CUDA code. (Matlab provides GPU variants of many of
%  its commands, but they do not make use of the pleasingly parallel 
%  structure of SABL and in fact they interfere with exploiting this
%  structure.) All of the models in SABL provide C/CUDA code for likelihood
%  function evaluation, and this code is used if E.gpu = true.
% 
%  Using a GPU, and especially multiple GPUs, can mutiply the computational
%  efficiency of SABL many-fold. These efficiencies are realized more 
%  readily to the extent that applications are more computationally 
%  intensive, which is where such acceleration is most desirable. Simple
%  ("textbook") problems show less increase in efficiency and may even
%  exhibit a decrease. There are quite a few considerations that can
%  arise from using GPUs, especially in some of the more elaborate ways
%  facilitated by SABL. As users gain in experiene and embark on such 
%  projects it is essential to consult the more detailed documentation 
%  available in the SABL Handbook.