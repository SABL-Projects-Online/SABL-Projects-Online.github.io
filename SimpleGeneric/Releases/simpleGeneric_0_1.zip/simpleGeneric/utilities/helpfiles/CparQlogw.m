function CparQlogw
% Cpar.logw
% C phase log weights for all particles. In each cycle weights are 
% initialized at 1 and then updated in each step of the C phase 
% (stage 'whileCphase'). C.JNwork x 1. 
% MONITOR FIELD

end

