function prior = p_prior_modelsetup(prior_in)
%  Check the specification of the (family of) prior distribution(s) 
%  'custom'.  Create any additional fields required for p_prior_customsim 
%  and p_prior_custom.
%
%  Input:
%  prior_in         Structure expressing the prior distribution with some
%                   fields set.
%
%  Output:
%  prior            Structure expressing the prior distribution with
%                   additional fields set.