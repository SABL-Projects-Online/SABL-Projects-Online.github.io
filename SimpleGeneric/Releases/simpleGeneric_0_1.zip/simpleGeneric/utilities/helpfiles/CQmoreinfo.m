function CQmoreinfo
% C.moreinfo 
% Indicator set only when all the information has been exhausted. 
%Once C.moreinfo = true, there are no more cycles.

%either 
% the end of the data has been reached (C.Cphase_method = 'data_whole') or 
% annealing is complete (C.Cphase_method = 'anneal_Bayes' or 
% 'anneal_optimize'). 
%
% Case 1:  
% Experienced users can impose their own stopping criteria by performing 
% the necessary calculations in p_monitor and setting C.moreinfo 
% accordingly. This is especially useful in optimization problems.
%
% Case 2:
% If C.Cphase_method = 'data_whole' then C.morinfo changes from 'false' to
% 'true' when the last observation is added in the C phase
% If C.Cphase_method = 'anneal_bayes' then C.morinfo changes from 'false'
% to 'true' when C.Cphase.power attains the value 1.
%
% CONTROL FIELD  (Case 1)  MONITOR FIELD  (Case 2)

end