function CQMphaseQblocks
% C.Mphase.blocks 
% A cell array incicating the current blocking of the parameter vector 
% for the MGRW_blocked M phase algorithm: C.Mphase.blocks{i} is a vector
% containing the algorithm parameter vector theta elements in block i.
% These entries may be fixed or changing over the course of the SABL
% algorithm.
%

% Case 1:
% Blocks are fixed if the model or user creates entries for this cell
% array at stage startrun. Then SABL sets C.ranblock = false. The
% union of the arrays in the cells must be 1:C.parameters, but these 
% arrays need not constitute a strict partition (i.e., overlaps are
% permitted.
%
% Case 2:
% Blocks change if C.Mphase.ranblock = true (core default). Contents
% are set by the MGRW_blocked algoirthm.
%
% CONTROL FIELD  (Case 1)  MONITOR FIELD (Case 2) 

end

