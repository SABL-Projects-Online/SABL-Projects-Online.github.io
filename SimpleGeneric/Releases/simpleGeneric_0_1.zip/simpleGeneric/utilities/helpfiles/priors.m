function priors
%  The following priors are available in this edition (2015a) of SABL:  
%        beta (Beta distribution, univariate)
%        dirichlet (Dirichlet distribution, multivariate)
%        gamma (Gamma distribution, univariate)
%        laplace (Laplace distribution, univariate)
%        linear (Normal or Student-t distribution, 
%                                               univariate or multivariate)
%        uniform (Uniform distribution, univariate or multivariate)
%        wishart (Wishart distribution, multivariate)
%        model  (Prior distribution specific to a model)
%        custom  (Prior distribution specific to a project)
%
%        Many of the prior distributions may be truncated and/or mixed with
%        discrete distributions.
%
%  A prior distribution must be created in p_monitor in stage 'startrun'.
%  The code creates a structure (call it prior) with subfields for 
%  hyperparameters as specified in the SABL documentation for that prior.
%  Then it uses the command prior = u_[priorname]setup(prior) to instruct
%  SABL to check the consistency of the prior specification and create
%  other fields of prior used subsequently by SABL.
%
%  For example, an n-dimensional multivariate normal prior distribution
%  with each element having mean m and variance 1, and correlation 0.5 
%  between each element, could be created in p_monitor stage 'startrun' 
%  through the sequence of commands
%  prior.mean = repmat(m, n, 1);
%  prior.variance = 0.5*(eye(n) + repmat(1, n, n));
%  prior = u_prior_linearsetup(prior);
%
%  SABL facilitates seamless extension of prior distributions to (1)
%  truncation by linear constraints and/or (2) mixing with a discrete
%  distribution. For details on these extensions use the commands
%        help priormixed
%        help priorconstraints
%
%  SABL uses an internal representation of priors that is generic. It is
%  transparent to the user who employs model default priors, but an
%  important tool for the user who departs from these defaults.
%  The prior structure for the model is contained in a cell array M.prior.
%  Each element is a prior specifcation structure of the kind desribed
%  above. Each component M.prior{i} also includes a vector field
%  M.prior{i}.columns, indicating the elements of theta (columns of
%  Cpar.theta) to which the prior distribution applies. In the prior
%  distribution these components are mutually independent. SABL checks
%  the entire set of structures in M.prior to make sure that the .columns
%  fields describe a partition of theta.
%
%  Subsidiary topics:
%     help [priorname]brief, e.g. help linearbrief
%     help priormixed, help priorconstraints

end