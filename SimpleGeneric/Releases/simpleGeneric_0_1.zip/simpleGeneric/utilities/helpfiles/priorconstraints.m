function priorconstraints
%  Any univariate prior distribution, or any linear prior distribution, may
%  be truncated by linear constraints. The general form is
%   a <= D*x <= b  where a: r x 1, b: r x 1, D: r x n; a < b, rank(D) = r.
%  
%  The prior distribution becomes constrained if the prior structure
%  contains the structure field constraints with fields
%     constraints.a
%     constraints.b
%     constraints.D
%
%  For example, a bivariate prior distribution N(0, V) constrained to the
%  positive orthant would be created by the sequence of commands
%  prior.mean = zeros(2, 1);
%  prior.var = V;
%  prior.constraints.a = zeros(2, 1);
%  prior.constraints.b = zeros(2, 1);
%  prior.constraints.D = eye(2);
%  prior = u_prior_linearsetup(prior);

end
