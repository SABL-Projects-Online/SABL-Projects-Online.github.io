function CQnlcuda
% C.nlcuda
% Indicator that there are nonlinear parameter maps in the model that are
% evaluated by the user function p_thetapar_CUDA. Set true by the user in
% p_monitor stage 'startrun' if this is the case
%
% CONTROL FIELD  Core default value: false