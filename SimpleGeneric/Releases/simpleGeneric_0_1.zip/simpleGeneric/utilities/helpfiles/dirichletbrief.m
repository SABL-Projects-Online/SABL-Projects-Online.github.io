function dirichletbrief
%  The (multivariate) Dirichlet prior distribution has support on the
%  n-dimensional unit simplex, density kernel
%       prod(x(i)^(a(i)-1)  (i = 1,...,n)
%  The hyperparameters may be specified by
%       the n x 1 vector field a, OR
%       the scalar fields a and n, in which case a(1) = ... = a(n)
%
%  The Dirichlet prior may not be modified by truncation or mixture with
%  a discrete distribution.

end