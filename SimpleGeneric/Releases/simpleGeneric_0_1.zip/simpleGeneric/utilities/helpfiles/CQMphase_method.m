function CQMphase_method
% C.Mphase_method 
% This is the algorithm used in the M phase, either 'MGRW_simple' or 
% 'MGRW_blocked' The default is model-specific. In most cases either 
% algorithm can be used, but it is possible a model might not permit this. 
% There are several algorithm-specific parameters required in each case, 
% with default values for all models, in the structure C.Mphase. The user 
% may set C.Mphase_method in p_monitor in stage 'startrun', but if this 
% differs from the default for the model errors may result. 
% 
% CONTROL FIELD  Core default: 'MGRW_simple'

end