function normalbrief
% Distribution: independent normal conditional on covariate vectors x and z
% The conditional mean is beta'x. The conditional variance is exp(gamma'z).
% Required model specification fields:
%    M.data       T x d data matrix
%    M.x_pointer  Columns of M.data corresponding to x
%    M.z_pointer  Columns of M.data corresponding to z
%    M.y_pointer  Column of M.data corresponding to y
% Parameter map
% Default map theta' = (beta', gamma').  Optional maps:
%    For beta:    M.betmap, M.betlinc, and name 'bet'
%    For gamma:   M.gammap, M.gamlinc, and name 'gam'
% Default prior distributions
%    Independent distributions for beta and gamma
%    For beta:    Prior structure M.betprior, must be linear
%    For gamma:   Prior structure M.gamprior, must be linear
%  Core control field defaut overrides: None