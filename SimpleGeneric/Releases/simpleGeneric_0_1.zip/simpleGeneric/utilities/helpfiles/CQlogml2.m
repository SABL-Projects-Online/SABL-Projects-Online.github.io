function CQlogml2 
% C.logml2 
% The SABL approximation of the log marginal likelihood using the 'w-tilde' 
% method. Determined and available at stage 'finish'. 
%
% MONITOR FIELD

end