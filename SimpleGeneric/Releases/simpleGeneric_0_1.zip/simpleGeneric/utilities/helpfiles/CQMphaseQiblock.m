function CQMphaseQiblock
% C.Mphase.iblock 
% Counter for block numbers over the iterations of the MGRW_blocked 
% algorithm in the M phase; facilitates indexing in the two-pass version of
% the algorithm. 
%
% MONITOR FIELD

end

