function priorcustom
%  A project may specify a specific prior that is not in the SABL suite of
%  priors. In this case the name of the prior is 'custom' and this name
%  can be used just like a SABL prior name: for example, 
%  u_prior_customsetup is used in the same way as u_prior_linearsetup 
%  or u_prior_gammasetup.
%  The user may exploit a P structure so that the single prior 'custom'
%  in fact functions as one of several alternative priors.
%  The project must provide, in the project directory, the functions SABL 
%  invokes in using any prior distribution:
%             p_prior_customsetup, u_prior_customsim, u_prior_custom,
%  all using the required input structure. 
%  