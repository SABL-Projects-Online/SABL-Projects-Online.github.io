function CQlogml1  
% C.logml1  
% The SABL approximation of the log marginal likelihood using the 'w-bar' 
% method. Determined and available at stage 'finish'. 
%
% MONITOR FIELD

end