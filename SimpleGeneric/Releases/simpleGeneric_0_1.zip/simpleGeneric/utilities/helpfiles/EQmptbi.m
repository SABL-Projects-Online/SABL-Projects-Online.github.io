function EQmptbi
% E.mptbi
% Indicator for Matlab parallel toolbox installed 
%
% MONITOR FIELD

end

