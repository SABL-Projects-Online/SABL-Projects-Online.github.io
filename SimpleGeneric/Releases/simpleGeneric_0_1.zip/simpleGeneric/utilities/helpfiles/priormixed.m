function priormixed
%  Any univariate prior distribution becomes mixed discrete-continuous if
%  the prior structure contains the structure field mixed. Two fields of
%  the structured mixed describe the mixture:
%  
%  The vector field mixed.mass contains the mass points a(1), ..., a(n).
%     They musts all be in the support of the distribution.
%  The vector field mixed.prob provides the corresponding probabiities 
%     p(1), ... , p(n). They must be positive and sum to p* < 1.
%  The result is a prior distribution with mass p(i) on point a(i) 
%     (i = 1, ... , n) and continuous with probabiity p*, the continuous
%     part being described by the parent prior structure.
%
%  For example, a univariate N(0,1) distribution mixed with the discrete
%  distribution that has probabiity 0.5 for x = 0 would be created by
%  the sequence of commands
%  prior.mean = 0
%  prior.std = 1;
%  prior.mixed.mass = 0;
%  prior.mixed.prob = 0.5;
%  prior = u_prior_linearsetup(prior);
%
%  If the discrete component also included the point x = 1 with probability
%  0.75, then the third and fourth lines above would be
%  prior.mixed.mass = [0; 1];
%  prior.mixed.prob = [0; 1];

end