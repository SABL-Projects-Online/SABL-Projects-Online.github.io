function CQCphaseQlogwsum
% C.Cphase.logwsum
% The current log of the sum of the Cphase weights. Modified in each step 
% of the Cphase, so harvesting must take place in stage 'whileCphase'. 
%
% MONITOR FIELD

end

