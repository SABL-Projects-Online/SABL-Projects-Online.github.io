function CQMstopQsteps 
% C.Mstop.steps 
% This is the number of steps stopping criterion for M phase Metropolis 
% steps under the 'RNE%steps' stopping criterion (the default). This 
% criterion is used in all cycles except the last one (for which see 
% C.Mstop.steps_end). 
%
% CONTROL FIELD  Core default: 100


end

