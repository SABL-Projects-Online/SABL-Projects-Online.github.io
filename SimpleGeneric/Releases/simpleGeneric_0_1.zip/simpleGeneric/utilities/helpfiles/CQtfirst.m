function CQtfirst
% C.tfirst
% The first row of M.data used in the current run of SABL. 
% Case 1:
% The user sets C.tfirst to a row of M.data (C.tfirst < C.tlast)
% This is essential when updating (E.simulation_get field present)
% and then typically C.tfirst is the value of C.tlast in file 
% E.simulation_get, plus 1.
% Case 2:
% If not set by the user SABL sets C.tfirst = 1
%
% CONTROL FIELD  (Case 1)  MONITOR FIELD (Case 2)

end
