function CQoptstatusQmax
% C.optstatus.max
% In the anneal_optimize algorithm this is the maximum value of the 
% objective function.
%
% MONITOR FIELD

end