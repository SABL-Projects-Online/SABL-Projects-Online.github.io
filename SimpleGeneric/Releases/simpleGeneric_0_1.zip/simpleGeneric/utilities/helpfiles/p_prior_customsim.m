function [theta, prior] = p_prior_customsim(nsim, prior_in)
%  Simulate from the custom distribution.
%
%  Inputs:
%  nsim                    Number of simulations (particles)
%  prior_in                Prior structure created by p_prior_customsetup
%
%  Outputs:
%  theta                   Simulated random variables (nsim x prior.n)
%  prior                   Same as prior_in, with additional fields that
%                          use values computed in this function (if any).

end