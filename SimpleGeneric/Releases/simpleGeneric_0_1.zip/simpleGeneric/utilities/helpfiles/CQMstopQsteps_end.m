function CQMstopQsteps_end
% C.Mstop.steps_end 
% This is the number of steps stopping criterion for M phase Metropolis 
% steps under the 'RNE%steps' stopping criterion (the default)in the final
% cycle only. This value may be changed by the user in p_monitor in stage 
% 'startrun'. 
%
% Case 1:
% C.Mstop.steps_end is declared by the model or user in stage startrun.
%
% Case 2:
% If not declared then C.Mstop.steps_end = 3*C.Mstop.steps regardless of
% whether C.Mstop.steps was declared or set by default.

% CONTROL FIELD  (Case 1)  MONITOR FIELD  (Case 2)

end