function CQCphaseQtop
% C.Cphase.top
% Upper bound on power in two C phase algorithms: 
% In the 'anneal_Bayes' Cphase algorithm C.Cphase.Qtop = 1;
% In the 'anneal_optimize' Cphase algorithm C.Cphase.Qtop = inf.
% 
% MONITOR FIELD

end

