function CQMstopQrne
% C.Mstop.rne 
% RNE stopping criterion for M phase Metropolis steps in all but the last
% cycle of the SABL algorithm.
%
% CONTROL FIELD  Core default: 0.4
%

end