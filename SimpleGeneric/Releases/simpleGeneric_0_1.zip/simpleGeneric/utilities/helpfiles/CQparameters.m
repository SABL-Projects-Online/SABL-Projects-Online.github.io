function CQparameters
% C.parameters
% The number of parameters used for inference or optimization; it is the 
% number of columns in the matrix of particles Cpar.theta.
%
% Case 1:
% The user sets C.parameters. This is most often done when the user is
% not using a default parameter map, or if the model has no such default.
%
% Case 2:
% For many default parameter maps, C.parameters is determined by the
% specification of the model. The user need not set C.parameters.
%
% CONTROL FIELD  (Case 1)  MONITOR FIELD  (Case 2)

end