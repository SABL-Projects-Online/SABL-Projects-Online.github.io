function CparQlogpinc
% Cpar.logpinc  
% Current increment to the log-likelihood or objective function in the C 
% phase. C.JNwork x 1. 
% MONITOR FIELD

end

