function prior = u_prior_modelsetup(prior_in)
%  Check the specification of the (family of) prior distribution(s) 'model'.
%  Create any additional fields required for u_prior_modelsim and 
%  u_prior_model.
%
%  Input:
%  prior_in         Structure expressing the prior distribution with some
%                   fields set.
%
%  Output:
%  prior            Structure expressing the prior distribution with
%                   additional fields set.