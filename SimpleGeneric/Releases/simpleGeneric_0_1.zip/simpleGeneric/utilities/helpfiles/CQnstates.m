function CQnstates 
% C.nstates 
% Indicator for the presence of state variables in evaluating the log- 
% likelihood function. This is specific to the model and data.
%
% MONITOR FIELD

end