function MVNbrief
%  Distribution: independent multivariate normal for y conditional on x
%            y = Ay + Bx + eps,  eps ~ N(0, (H'H)^-1)
%  with y: n x 1 observable, x: k x 1 observable, P(I_n-A nonsingular) = 1,
%  H upper triangular with positive diagonal elements.
%  The model has several specifications governed by M.specification.
%  For all specifications the required model specification fields are
%    M.data       T x d data matrix
%    M.x_pointer  Columns of M.data corresponding to x
%    M.y_pointer  Column of M.data corresponding to y
%  
%  Full information specification: M.specification = 'FI'
%  Parameter map: No defaults. Required maps:
%     For A:      M.Amap, M.Alinc, and name 'A'
%     For B:      M.Bmap, M.Blinc, and name 'B'
%     For H:      M.Hmap, M.Hlinc, and name 'H'
%  Default prior distribution: No defaults
%  Core control field default overrides: None
%
%  Seemingly unrelated regressions specification: M.specification =  'SUR'
%     To be added in a future edition of SABL
%
%  Instrumental variables specification: M.specification = 'IV'
%     To be added in a future edition of SABL
%
%  Limited information specification: M.specification = 'LI'
%     To be added in a future edition of SABL
