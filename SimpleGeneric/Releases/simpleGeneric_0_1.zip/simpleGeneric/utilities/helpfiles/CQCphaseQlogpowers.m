function CQCphaseQlogpowers
% C.Cphase.logpowers
% In the aneeal_Bayes variant of the C phase, entry i of this vector is the 
% log of the power set in the C phase in cycle i. Entry C.cycle is 
% available at stage 'endMphase'.  
%
% MONITOR FIELD

end

