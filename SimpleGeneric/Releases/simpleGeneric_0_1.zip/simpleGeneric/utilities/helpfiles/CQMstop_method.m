function CQMstop_method 
% C.Mstop_method 
% This is the stopping rule for the M phase. The choices are 
% 'RNE&steps'  Execute Metropolis steps until a specified RNE is attained, 
%              subject to an upper bound on steps. 
% 'steps'      Execute a fixed number of Metropolis steps regardless of 
%              RNE. 
% 'hybrid'     Continue to execute Metropolis steps until at step s, the 
%              ratio of RNE to s is lower than the ratio of the target RNE
%              to the upper bound on the number of steps. 
% 'RNE'        Execute Metropolis steps until a specified RNE is attained, 
%              but without an upper bound on steps. This can lead to 
%              obvious practical problems but it can be useful when 
%              experimenting with various algorithm design parameters 
%              specific to the M phase. 
%
% CONTROL FIELD  Core default: 'RNE&steps'

end