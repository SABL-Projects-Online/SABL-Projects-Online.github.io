function CQJN
% C.JN 
% The total number of particles C*J. 
% 
% MONITOR FIELD 

end