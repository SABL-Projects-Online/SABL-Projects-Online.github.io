function logp = p_prior_custom(theta, prior)
%  Evaluate the log prior probability density of the prior distribution
%  custom.
%  
%  Inputs:
%  theta     Points of evaluation (particles)  (C.Jnwork x prior.n)
%  prior     Prior structure created by u_prior_modelsetup
%
%  Output:
%  logp      Log prior density corresponding to theta (C.JNwork x 1) 

end