function poissonbrief
% Distribution: independent Poisson conditional on 
%    covariate vectors x and z
% The conditional log mean is beta'x. 
% Required model specification fields:
%    M.data       T x d data matrix
%    M.x_pointer  Columns of M.data corresponding to x
%    M.y_pointer  Column of M.data corresponding to y
% Parameter map
% Default map theta = beta.  Optional map:
%    For beta:    M.betamap, M.betalinc, and name 'beta'
% Default prior distributions
%    For beta:    Prior structure M.betaprior, must be linear
%  Core control field default overrides: None