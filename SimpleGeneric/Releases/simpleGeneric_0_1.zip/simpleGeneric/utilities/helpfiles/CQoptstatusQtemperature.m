function CQoptstatusQtemperature
% C.optstatus.temperature
% The inverse of C.optstatus.power. In the context of the simulated 
% annealing literature this is the temperature in the current cycle of the  
% anneal_optimize algorithm.
%
% MONITOR FIELD

end