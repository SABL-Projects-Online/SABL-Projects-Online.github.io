function CQcptime
% C.cptime
% Central processor time (in seconds) used by SABL, set in stage 'endrun'.
% To the extent Matlab has exploited multiple cores it will exceed 
% C.walltime. However, CP time retrieval algorithms can be specific to 
% hardware and operating systems and can be unreliable.
%
% MONITOR FIELD

end

