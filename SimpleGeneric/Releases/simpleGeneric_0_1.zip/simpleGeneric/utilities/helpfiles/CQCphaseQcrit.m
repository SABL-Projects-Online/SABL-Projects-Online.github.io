function CQCphaseQcrit
% C.Cphase.crit
% Convergence criterion for the solution of the nonlinear equation 
% (function l_annealpower) that determines the increment to C.Cphase.power 
% in the anneal_Bayes and anneal_optimize variants of the C phase. The 
% default value can be modified by the modeler, and may be changed by the 
% user in stage 'startrun'.
%
% CONTROL FIELD  Core default: 1e-12

end

