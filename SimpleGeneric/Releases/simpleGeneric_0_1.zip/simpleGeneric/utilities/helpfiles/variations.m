function variations
%  While SABL can be used in its default mode, it has variations in several
%  dimensions that can make it best suited to particular applications
%  and computing environments.  Each of the following helps provides
%  a summary of variations in a particular dimension.
%
%  help Cphase      Variations in the C phase
%  help Sphase      Variations in the S phase
%  help Mphase      Variations in the M phase
%  help updating    Using SABL to update posteriors with incremental data
%  help pass        One- and two-pass variants of SABL
%  help environment CPU/GPU and single/multiple-worker SABL