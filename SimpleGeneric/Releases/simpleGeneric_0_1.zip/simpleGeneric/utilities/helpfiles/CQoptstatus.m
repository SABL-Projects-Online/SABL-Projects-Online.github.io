function CQoptstatus
% C.optstatus
% Structure containing fields with information about the convergence status  
% of the anneal_optimize variant of the C phase. The fields are updated in  
% stage 'endMphase'. Typically they are interrogated by the user in  
% p_monitor at this stage in determining whether to set C.moreinfo = true,  
% terminating the algorithm.
%
% STRUCTURE

end