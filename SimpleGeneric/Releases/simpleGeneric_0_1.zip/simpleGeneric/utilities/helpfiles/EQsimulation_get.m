function EQsimulation_get 
% E.simulation_get 
% Contains the name of a file of previously recorded global structures.  If the 
% field is present then the initial particles are the recorded Cpar.theta;
% if not they are generated from the initial (prior) distribution.
%
% CONTROL FIELD  Core default: Field is absent

end
