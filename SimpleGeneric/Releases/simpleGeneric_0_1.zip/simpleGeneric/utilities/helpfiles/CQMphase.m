function CQMphase 
% C.Mphase 
% This field is a structure containing fields for algorithm parameters and 
% variables shared across stages in the M phase. 
%
% STRUCTURE

end