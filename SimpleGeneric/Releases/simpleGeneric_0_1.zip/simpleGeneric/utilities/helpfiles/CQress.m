function CQress
% C.ress 
% The current relative effective sample size, computed in the C phase. Its
% value changes only in stage whileCphase.
% stage 'whileCphase'. 
%
% MONITOR FIELD

end