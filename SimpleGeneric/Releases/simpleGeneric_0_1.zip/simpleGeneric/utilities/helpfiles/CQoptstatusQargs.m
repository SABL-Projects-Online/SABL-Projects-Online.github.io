function CQoptstatusQargs
% C.optstatus.args
% In the anneal_optimize algorithm these are the particles at the end of 
% the M phase. This C.JN x C.parameters matrix exists in the CPU regardless
% of the values of E.gpu and E.pus.
%
% MONITOR FIELD

end