function theta = u_prior_laplacesim(nsim, prior)
%  Simulate from the Laplace prior distribution; pdf is
%  p(x) = 0.5*lambda*exp(-lambda*|x - pmean|).
%
%  Inputs:
%  nsim      Number of simulations (particles)
%  prior     Prior structure created by u_prior_lambdasetup
%
%  Output:
%  theta     Simulated random variables

if prior.con
    u = unifrnd(prior.constraints.cdfa, prior.constraints.cdfb, nsim, 1);
else
    u = unifrnd(0, 1, nsim, 1);
end

theta = log(u*2)/prior.lambda + prior.mean;

ii = find(theta > prior.mean);
if ~isempty(ii)
    theta(ii) = -log(2*(1-u(ii)))/prior.lambda + prior.mean;
end

if prior.mix
    [~, theta] = u_mixedrnd(theta, prior.mixed.mass, prior.mixed.prob, ...
        prior.mixed.r, prior.mixed.s);
end

end