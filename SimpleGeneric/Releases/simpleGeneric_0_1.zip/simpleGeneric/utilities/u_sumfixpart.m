function [C, Cmap] = u_sumfixpart(A, B, Bmap, Bscale)
%  Compute C = A + s*B, A in conventional matrix format, B in short
%  matrix-particle format and C in compact short matrix-particle format
%
%  Inputs:
%  A          Matrix A  (n x m)
%  B, Bmap    Matrix B in short matrix-particle format
%  Bscale     The scalar factor s
%
%  Outputs:
%  C, Cmap    Matrix C in compact short matrix-particle format
%
%  The outputs may occupy the same location as any of the inputs in the
%  invoking function.

[n, m] = size(A);
JN = size(B, 1);

Cmaplocal = zeros(n, m);
Cflag = A~=0 | Bmap>0;

Clocal = zeros(JN, sum(sum(Cflag)));
s = 0;
for j = 1:m
    for i = 1:n
        if Cflag(i,j)
            s = s + 1;
            Cmaplocal(i,j) = s;
            Clocal(:,s) = A(i,j);
            if Bmap(i,j) > 0
                Clocal(:,s) = Clocal(:,s) + Bscale*B(:,Bmap(i,j));
            end
        end
    end
end

C = Clocal;
Cmap = Cmaplocal;
   
end