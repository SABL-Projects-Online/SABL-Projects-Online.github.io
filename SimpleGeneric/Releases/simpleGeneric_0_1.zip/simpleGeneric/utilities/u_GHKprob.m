function [logprob, logprobnse, xsim] = ...
    u_GHKprob(mu, varchol, D, a, b, nsimouter, nsiminner, nu, parallel)
%  Evaluate P(a <= D*x <= b) for a random vector with a multivariate normal
%  or Student-t distribution using the GHK algorithm.  Optionally, return 
%  simulated values of the random vector with its pdf truncated to the 
%  region a <= D*x <= b.
%
%  Inputs:
%  mu         Location (Mean if normal, or if Student-t and mean exists)  
%                                                                   (n x 1) 
%  varchol    Choleski decomposition C: C'C is the scale matrix (Variance
%             if normal)
%  D          Nonsingular matrix D  (n x n)
%  a          Vector a (n x 1)
%  b          Vector b (n x 1)
%  nsimouter  Iterations in the outer loop
%  nsiminner  Iterations in the inner loop
%  nu         Degrees of freedom for Student t; inf indicates norma;
%  parallel   Indicator for using multiple workers; false if absent(Optional)
%
%  Outputs:
%  logprob    log of unbiased simulation approximation of P(a <= x <= b)
%  logprobnse Numerical standard error of logprob
%  xsim       Simulated x constrainted to a <= D <= b  
%                                                 (nsimouter*nsiminner x 1)

if nargin < 9
    parallel = false;
end

n = length(mu);
A = a - D*mu;
B = b - D*mu;

if nargout == 2 && isinf(nu) && n <= 2
    nsimout = 1;
    nsim = 1;
else
    nsimout = nsimouter;
    nsim = nsiminner;
end
w_nusim = true;
if isinf(nu)
    w_nu = ones(nsim, 1);
    w_nusim = false;
end
if nargout == 3
    xsim = zeros(nsim*nsimout, n);
end
logpp = zeros(nsimout, 1);

v = D*varchol';
varchol_new = chol((v*v'));

jsim = 0;
fprintf('Simulating %d times from truncated prior...', ...
    nsimout*nsim)
time0 = tic;
for isimout = 1:nsimout
    if w_nusim
        w_nu = (chi2rnd(nu, [nsim, 1])/nu).^(1/2);
    end
    logw  = zeros(nsim, 1);
    for isim = 1:nsim
        uu = zeros(n, 1);
        A_isim = A*w_nu(isim);
        B_isim = B*w_nu(isim);
        for i = 1:n
            temp_sum = 0;
            for j = 1:(i-1) 
                temp_sum = temp_sum + varchol_new(j, i)*uu(j);
            end 
            Int_low = (A_isim(i) - temp_sum)/varchol_new(i, i);
            Int_up  = (B_isim(i) - temp_sum)/varchol_new(i, i);    
            uu(i) = u_normtruncrnd(0, 1, Int_low, Int_up);
            logp  = u_normtruncprob(0, 1, Int_low, Int_up);
            logw(isim) = logw(isim) + logp;
        end
        if nargout == 3
            jsim = jsim + 1;
            xsim(jsim, :) = mu' + (1/w_nu(isim))*uu'*varchol_new/D';
        end
    end
    logpp(isimout) = u_logmeanlog(logw, 1, parallel);
end
fprintf('%8.4f seconds\n', toc(time0))

logprob = u_logmeanlog(logpp, 1, parallel);
if nargout >= 2
    logprobnse = std(logpp)/sqrt(nsimout);
end

end
