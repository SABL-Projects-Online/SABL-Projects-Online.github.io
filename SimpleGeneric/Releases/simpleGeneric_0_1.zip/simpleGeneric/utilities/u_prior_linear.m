function logp = u_prior_linear(theta, prior)
%  Evaluate the log prior probability density of a Gaussian or Student
%  prior distribution, truncated to an interval or not.
%  
%  Inputs:
%  theta     Points of evaluation (particles)  (JN x n)
%  prior     Prior structure created by u_prior_gammasetup
%
%  Output:
%  logp      Log prior density corresponding to theta (C.JNwork x 1) 

trans = @(x) x;

JN = size(theta, 1);
if prior.simple
    z = (theta - repmat(prior.mean', JN, 1))*prior.precchol';
    el2 = sum(z.^2, 2);
    if prior.normal
        logp = -0.5*el2 + prior.lognormconst;
    else 
        logp = prior.power*log(1+el2/prior.df) + prior.lognormconst;
    end 
else
    logp = u_priormixcont(theta, prior, @u_prior_linear, trans, trans);
end

end