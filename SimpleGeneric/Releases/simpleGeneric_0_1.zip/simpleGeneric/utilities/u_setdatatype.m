function a_out = u_setdatatype(a_in, memtype)
% Moves the data to desired memory ('cpu' or 'gpu').
%
% Inputs:
%  a_in         Source array (in either cpu or gpu)
%  memtype      Destination memory type (either cpu or gpu); 'gpu', 'cpu' 
%               or 'default'; 'default' uses E.gpu to determine memory type
%  Omitting the last input argument is equivalent to memtype = 'default'.
% 
% Output:
%   a           The array on cpu or gpu as indicated by input

global E

if 1 == nargin 
    memtype = 'default';
end

if E.gpu
    if strcmp(memtype, 'cpu')
        a_out = gather(a_in); % Works even when a_in is on CPU.
    elseif strcmp(memtype, 'gpu')
        a_out = gpuArray(a_in); % Works even when a_in is on GPU.
    elseif strcmp(memtype, 'default')
        a_out = gpuArray(a_in); 
    else
    end
else
    if strcmp(memtype, 'cpu')
        a_out = a_in;
    elseif strcmp(memtype, 'gpu')
        error('E.gpu = %d, memtype = ''%s'', not supported.', E.gpu, memtype);
    elseif strcmp(memtype, 'default')
        a_out = a_in;
    else
    end
end

end
