function u_rmdir(dire)
%  Remove directory (in character string representing a full path) or
%  directories (in cell array with each element representing a full path)
%  from MATLAB's search path.
%
%  Input:
%  dire    directory (in character string) or directories (in cell array)

if isempty(dire)
    return;
end

if iscell(dire)
    for i = 1:length(dire)
        u_rmdir(dire{i});
    end
else
    if ~ischar(dire)
        return;
    end
    
    if 7~=exist(dire, 'dir')
        return;
    end
    
    if 0 < nnz(strcmp(dire,regexp(path,pathsep,'split')))
        rmpath(dire);
        u_rmdir([dire filesep 'ptxfiles']);
        u_rmdir([dire filesep 'mexfiles']);
    end
end

end