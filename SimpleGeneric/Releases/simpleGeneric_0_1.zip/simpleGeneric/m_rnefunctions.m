function g = m_rnefunctions(theta)
%  This function specifies the evalaution functions for the RNE stopping
%  rule in the M phase.
%
%  Input:
%  theta     Parameter vectors (C.JNwork x C.parameters)
%
%  Output:
%  g         Functions of theta used for RNE computation (C.JNwork x ng)

global M


% g = [theta(:,4)];
g = theta;
end