function [ logp, rawlogp ] = m_message( atheta, intensity )
%% M_MESSAGE Calculation of log-likelihood   
% Allocate tensor array dimensions:
%     Dim 1: Observations
%     Dim 2: Covariates 
%     Dim 3: Outcomes
%     Dim 4: SABL particles

global M P

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Important note for new users
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % Starting from your desired log-
    % likelihood function, you then apply
    % a scaling factor (intensity) to each
    % score in order for SABL to work.
    % 
    % See the bottom of this file for
    % an example
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Do not modify this section 

    tt   = intensity > 0;
    l_intensity = intensity(tt);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Provide your log-likelihood score function here:    
    % For this example, I use:  Pr(P.x{5}==1) = logit(P.x{1},P.x{3}) * logit(P.x{2},P.x{4})
    %
    lfLogit1 = sum( bsxfun( @times,...
                            M.data(:,P.dataColumnsLogit1),...
                            permute(atheta(:,P.thetaColumnsLogit1),[4 2 3 1])), 2);
    isp = (lfLogit1 >= 0);
    isn = (lfLogit1 < 0);
    partLogit1      = u_allocate(size(lfLogit1),'default','zeros');
    partLogit1(isn) = -log(1+exp(lfLogit1(isn)));   % base
    partLogit1(isp) = -log(1+exp(lfLogit1(isp))) - lfLogit1(isp);  % base

    lfLogit2 = sum( bsxfun( @times,...
                            M.data(:,P.dataColumnsLogit2),...
                            permute(atheta(:,P.thetaColumnsLogit2),[4 2 3 1])), 2);
    isp = (lfLogit2 >= 0);
    isn = (lfLogit2 < 0);
    partLogit2      = u_allocate(size(lfLogit2),'default','zeros');
    partLogit2(isn) = -log(1+exp(lfLogit2(isn)));   % base
    partLogit2(isp) = -log(1+exp(lfLogit2(isp))) - lfLogit2(isp);  % base

    selectComp = (M.data(:,P.dataColumnsY) == 1);
    partLogit1(selectComp,:,:,:) = partLogit1(selectComp,:,:,:) + lfLogit1(selectComp,:,:,:);
    partLogit2(selectComp,:,:,:) = partLogit2(selectComp,:,:,:) + lfLogit2(selectComp,:,:,:);

    partialLogLikelihoods = partLogit1 + partLogit2;
 
    % Return value : contributions to log-likelihood of each observation (score)
    rawlogp = partialLogLikelihoods;

    % Return value : log-likelihood
    % For the SABL algorithm to work, we must scale the scores by 'l_intensity':
    logp = permute(sum(bsxfun(@times,partialLogLikelihoods,l_intensity),1),[4 2 3 1]);
end


