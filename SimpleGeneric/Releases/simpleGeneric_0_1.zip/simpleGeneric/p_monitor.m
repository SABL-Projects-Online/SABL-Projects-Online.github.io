function p_monitor(stage)
%% P_MONITOR
global Cpar C E M P
    if strcmp(stage, 'open')
        E.gpu = P.useGpu;
        E.pus = gpuDeviceCount;

    elseif strcmp(stage, 'startrun')
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Start of user-specific requirements
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %% Data: read data from .mat file
        % Populate M.data. For M.data, transfer to GPU is automatic.  
        % Otherwise, you must handle the transfer of data to GPU
        % yourself.
        % 
        M.data = [P.x{1:length(P.x)}];
        
        %% Parameters: 
        pkdv = P.priorMeanStd;
               
        %% M.prior
        % Complete the setup of truncated normal prior distributions and populate M.prior 
        pkdv = u_prior_linearsetup(pkdv);       
        M.prior{1} = pkdv;  
        
        %% C.parameters
        % Set the number of parameters that SABL is handling
        C.parameters = length(pkdv.mean);       
               
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% End of user-specific requirements
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %
        %% Defaults for SABL
        %    
         C.J = 16;
         C.N = 1024;
         % C.N = 192;
         % C.N = 256;    
         % C.N = 1024 is the usual default for SABL, but is causing crashes when running on multiple GPUs
         
         % C.twopass = true;
         % C.tfirst = 1;
         % C.Mstop_method = 'RNE&steps';
         % C.Mstop.steps = 40;         
         C.tlast = size(M.data, 1);


    elseif strcmp(stage, 'endrun')      
     
    elseif strcmp(stage, 'finish')

    elseif strcmp(stage, 'close')

    end    

end

