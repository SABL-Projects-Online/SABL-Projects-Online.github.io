function c_Sphase(stage)
%  Function manages the S phase
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C Cpar E

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    if ~isfield(C.detail, 'startSphase')
        C.detail.startSphase = C.detail_level >= 5;
    end
    if C.passone
        fprintf('\nS phase %s resampling\n', C.Sphase_method)
    end
    
elseif strcmp(stage, 'startSphase') && strcmp(C.stagestep, 'nomonitor')
    
    %  Computations common to all S phase methods
    logw1 = reshape(Cpar.logw, C.N, C.Jwork);
    logw2 = logw1 - repmat(u_logsumlog(logw1, 1, false), C.N, 1);
    w = exp(logw2);
    s = zeros(C.N, C.Jwork);

    for j = 1:C.Jwork  %  Resampling executed within each particle group
        if strcmp(C.Sphase_method, 'residual')
            count = c_Sphase_residual(w(:,j), C.N);
	
        elseif strcmp(C.Sphase_method, 'multinomial')
            count = c_Sphase_multinomial(w(:,j), C.N);
	
        elseif strcmp(C.Sphase_method, 'systematic')
            count = c_Sphase_systematic(w(:,j), C.N);
	
        elseif strcmp(C.Sphase_method, 'stratified')
            count = c_Sphase_stratified(w(:,j), C.N);
            
        elseif strcmp(C.Sphase_method, 'custom')
            count = p_Sphase_custom(w(:,j), C.N);
	    
        else
            error('Unrecognized: C.Sphase = %d', C.Sphase)
        end
	
        ipos = find(count > 0);
        junique = length(ipos);
        ibase = 0;
        ss = zeros(C.N,1);

        for i = 1:junique
            ss(ibase+1:ibase+count(ipos(i))) = ...
                repmat(ipos(i),count(ipos(i)),1);
            ibase = ibase + count(ipos(i));
        end
        s(:,j) = ss + (j-1)*C.N;
	
    end

    %  Computations common to all S phase methods
    Cpar.select = reshape(s, C.N*C.Jwork, 1);
    Cpar.theta = Cpar.theta(Cpar.select,:);
    if isa(Cpar.theta, 'gpuArray')
	nunique = u_sum(size(unique(Cpar.theta(:,1)), 1), 1, E.pus>1);
    else
	nunique = u_sum(size(unique(Cpar.theta, 'rows'), 1), 1, E.pus>1);
    end

    if C.detail.startSphase && u_islab1
	    fprintf('Cycle%5.0f Sphase: %d particles out of %d unique (%5.4f)\n', ...
            C.cycle, nunique, C.JN, nunique/(C.JN))
    end

end

end