function count = c_Sphase_stratified(w, n)
%  Execute the S phase using stratified resampling.
%
%  Inputs:
%  w       Weights of the sample (non-negative, positive sum)  (m x 1)
%  n       Size of unweighted sample
%
%  Output:
%  count   count(i) is the number of times the sample point with weight
%          w(i) is included in the unweighted sample of size n  (n x 1)

m = length(w);
wnorm = cumsum(w);
wnorm = wnorm/wnorm(m);
unorm = cumsum(ones(n,1));
unorm = unorm/unorm(n);

count = zeros(m,1);
i = 1;
j = 1;
while j <= n 
    if wnorm(i) >= unorm(j)
        count(i) = count(i)+1;
        j = j+1;
    else
        i = i+1;
    end
end

end