function moreCsteps = c_Cphase(stage)
%  Function manages the C phase
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C   

%  Execute the specified C phase method.

if strcmp(C.Cphase_method, 'data_whole')
    c_Cphase_data_whole(stage);
    
elseif strcmp(C.Cphase_method, 'anneal_Bayes')
    c_Cphase_anneal_Bayes(stage);

elseif strcmp(C.Cphase_method, 'anneal_optimize')
    c_Cphase_anneal_optimize(stage);
    
elseif strcmp(C.Cphase_method, 'anneal_fixed')
    c_Cphase_anneal_fixed(stage);
    
elseif strcmp(C.Cphase_method, 'custom')
    p_Cphase_custom(stage);
    
else
    error('Unrecognized: C.Cphase_method = %s', C.Cphase_method)
end

%  Execute the specifed C phase stopping rule.

if strcmp(C.Cstop_method, 'ESS')
    if strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
        moreCsteps = c_Cstop_ess(stage);
    else
        c_Cstop_ess(stage);
    end
    
elseif strcmp(C.Cstop_method, 'optimize')
    if strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
        moreCsteps = c_Cstop_optimize(stage);
    else
        c_Cstop_optimize(stage);
    end
    
elseif strcmp(C.Cstop_method, 'custom')
    if strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
        moreCsteps = p_Cstop_custom(stage);
    else
        p_Cstop_custom(stage);
    end
    
elseif strcmp(C.Cstop_method, 'unconditional_stop')
    if strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
        moreCsteps = c_Cstop_unconditional(stage);
    else
        c_Cstop_unconditional(stage);
    end
    
else
    error('Unrecognized: C.Cstop_method = %s', Cstop_method)
end

end