function c_Cphase_anneal_optimize(stage)
%  Eecute the C phase anneal_optimize algorithm
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C Cpar E
persistent cycle_powerinc_store

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    if ~isfield(C.detail, 'startupC')
        C.detail.startupC = C.detail_level >= 2;
    end
    if ~isfield(C.detail, 'whileCphase')
        C.detail.whileCphase = C.detail_level >= 8;
    end
    if ~isfield(C.detail, 'endCphase')
        C.detail.endCphase = C.detail_level >= 6;
    end
    if ~isfield(C.Cphase, 'crit')
        C.Cphase.crit = 1e-12;
    end
    if ~isfield(C.Cstop, 'ress')
        C.Cstop.ress = 0.5;
    end
    if ~isfield(C, 'tfirst')
        C.tfirst = 1;
    end
    if ~isfield(C, 'tlast')
        C.tlast = 1;
    end
    C.mpl = false;
    
    C.Cstop_method = 'optimize';
    C.Cphase.top = inf;
    C.Cphase.power = 0;
    if C.passone
        fprintf('\nC phase anneal_optimize algorithm\n')
        fprintf('Effective sample size criterion (C.Cstop.ress):%5.3f\n',...
            C.Cstop.ress)
    end
    
elseif strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
    %  Set the intensity vector for evaluation of the objective function
    intensity = u_allocate([C.tlast,1]);
    intensity(C.tfirst:C.tlast) = 1;
    
    %  Evaluate the objective function at the current particles.
    if C.nstates > 0
        [Cpar.logpinc, Cpar.states_out] = u_message(Cpar.theta, ...
            intensity, Cpar.states_in);
    else
        Cpar.logpinc = u_message(Cpar.theta, intensity);
    end
    
    %  Solve for the increment to power yielding the required ESS.
    if C.passone
        powerinc = l_annealpower(Cpar.logpinc, C.Cstop.ress, ...
            C.Cphase.top - C.Cphase.power, C.Cphase.crit, E.pus>1);
        if C.twopass
            cycle_powerinc_store(C.cycle) = powerinc;
        end
    else
        powerinc = cycle_powerinc_store(C.cycle);
    end
    
    C.Cphase.power = C.Cphase.power + powerinc;
    
    %  Update the intensity vector for the SABL algorithm
    C.intensity = u_allocate([C.tlast,1]);
    C.intensity(C.tfirst:C.tlast) = C.Cphase.power;
    
    %  Compute the new weights.
    wnew = Cpar.logw + powerinc*Cpar.logpinc;  %  For C phase
    Cpar.logw = wnew;
    w = exp(Cpar.logw - u_logsumlog(Cpar.logw, 1, E.pus>1));
    
    %  This evaluation is as a check/reassurance that ESS target is met.
    ess = 1/u_sum(w.^2, 1, E.pus>1);
    C.ress = ess/C.JN - C.Cphase.crit;
    C.moreinfo = C.Cphase.power < C.Cphase.top - C.Cphase.crit;
    
elseif strcmp(stage, 'endCphase') && strcmp(C.stagestep, 'postmonitor')
    if C.detail.endCphase && u_islab1
        fprintf('Cycle%5.0f Cphase: Objective function exponent %7.4e, RESS%7.4f\n',...
            C.cycle, C.Cphase.power, C.ress)
    end
        
end

end