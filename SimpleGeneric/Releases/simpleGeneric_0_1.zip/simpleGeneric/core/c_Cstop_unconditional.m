function moreCsteps = c_Cstop_unconditional(stage)
%  Execute the C phase unconditional stop.
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm
%
%  Output:
%  moreCsteps Inicator for more steps in the C phase

global C

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor') && ...
    C.passone
    if C.passone
        fprintf('\nC phase Cstop_unconditional algorithm\n')
    end

elseif strcmp(stage, 'whileCphase') && strcmp(C.stagestep, 'nomonitor')
    moreCsteps = false;

end

end