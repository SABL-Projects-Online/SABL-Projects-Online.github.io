function c_sabl_spmd
%  This function is intermediate between the SABL shell function and
%  the function c_sabl that executes the SABL algorithm.  This enables 
%  code to be written without regard to whether execution is single
%  thread or multiple thread. This function is invoked only when E.pus > 1.

global C Cpar E Epar M Mpar P Ppar

%  The invocation of SPMD syntax is explicit, meaning outside SPMD block 
%  there is one thread, inside SPMD block there are E.pus threads (workers)

spmd
    
    %  Transfer identical information to each block (C, E, M, P)
    %  Transfer distinct information to each block 
    %  (Cpar, Epar, Mpar, Ppar) if any.
    u_copyintospmd(C, E, M, P, Cpar, Epar, Mpar, Ppar);
    
    %  Execute the SABL algorithm
    c_sabl
    
    %  Transfer information from the workers back to local CPU memory.
    [Coutspmd, Eoutspmd, Moutspmd, Poutspmd, ...
        Cparoutspmd, Eparoutspmd, Mparoutspmd, Pparoutspmd] = ...
            u_copyfromspmd;

end

%  Convert identical copies of C, Cpar, E, Epar, M, Mpar, P, and Ppar 
%  global structures from the workers to single global structures 
%  on the client.
C = Coutspmd{1};
E = Eoutspmd{1};
M = Moutspmd{1};
P = Poutspmd{1};
Cpar = Cparoutspmd{1};
Epar = Eparoutspmd{1};
Mpar = Mparoutspmd{1};
Ppar = Pparoutspmd{1};

end