function moreCsteps = c_Cstop_ess(stage)
%  Execute the C phase ESS stopping rule.
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm
%
%  Output:
%  moreCsteps Inicator for more steps in the C phase

global C
persistent cycle_length_store

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    %  Fill missing fields with default values
    if ~isfield(C.Cstop, 'ress')
        C.Cstop.ress = 0.5;
    end
    if C.passone
        fprintf('C phase Cstop_ess algorithm\n')
        fprintf('    RESS criterion C.Cstop.ress = %5.3f\n', ...
            C.Cstop.ress)
    end

elseif strcmp(stage, 'whileCphase')
    if C.passone
        moreCsteps = C.ress >= C.Cstop.ress  &&  C.moreinfo;
        if ~moreCsteps && C.twopass
            cycle_length_store(C.cycle) = C.Cphase.count;
        end
    else
        moreCsteps = C.Cphase.count < cycle_length_store(C.cycle);
    end

end

end