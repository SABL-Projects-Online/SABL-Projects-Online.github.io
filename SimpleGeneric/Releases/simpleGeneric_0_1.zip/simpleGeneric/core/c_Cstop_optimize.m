function moreCsteps = c_Cstop_optimize(stage)
%  Compute functions of the particles and the objective function that may
%  be useful in deciding whether to terminate the anneal_optimize
%  algorithm. These computations are made just before the user has access
%  at the end of the M phase in p_monitor. 
%
%  It is entirely the user's responsibility to terminate the algorithm
%  by declarining C.moreinfo = false. Failure to do this will result in
%  execution that either becomes degenerate (e.g. random small changes
%  in the objective function) or a numerical accident (e.g. generation of
%  NaNs causes Matlab to interupt.
%  
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm
%
%  Output:
%  moreCsteps Inicator for steps in the C phase (always false, here)

global C Cpar E

moreCsteps = false;

if strcmp(stage, 'startrun') && strcmp(C.stagestep, 'postmonitor')
    eta2k = C.Cstop.ress^(-2/C.parameters);
    C.optstatus.rhostar = eta2k - 1 + sqrt(eta2k*(eta2k-1));

elseif strcmp(stage, 'endMphase')  && strcmp(C.stagestep, 'premonitor')
    if C.cycle > 1
        C.optstatus.rho = C.Cphase.power/C.optstatus.power - 1;
    else
        C.optstatus.rho = inf;
    end
    C.optstatus.power = C.Cphase.power;
    C.optstatus.temperature = 1/C.optstatus.power;
    objective = u_setdatatype(u_gcat(u_message(Cpar.theta, 1)), 'cpu');
    top = u_max(objective, 1, E.pus>1);
    C.optstatus.fracmax = u_mean(objective == top, 1, E.pus>1);
    C.optstatus.args = u_setdatatype(u_gcat(Cpar.theta), 'cpu');
    C.optstatus.max = u_max(objective, 1, E.pus>1);
    C.optstatus.maxindex = find(objective == C.optstatus.max);    
end

end