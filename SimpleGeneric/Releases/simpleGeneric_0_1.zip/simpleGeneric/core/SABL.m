function allstructures = SABL(model, project)
%  This is SABL release 2015a. To invoke SABL, use the command
%          SABL([model], [project])                                     (1)
%  The argument [project] can take one of three forms:
%    (1) The directory for project code (absolute or relative);
%    (2) The name of one of the example projects in the SABL toolbox;
%    (3) If invoked from the project directory the argument can be omitted.
%  The argument [model] can take one of three forms:
%    (1) The name of a SABL model, e.g. 'normal' or 'poisson';
%    (2) The directory for model code (absolute or relative);
%    (3) If the current directory includes all model and project code
%        then both arguments can be omitted.
%  The command
%          allsturctures = SABL([model], [project]) 
%  results in a structure containing all eight SABL global structures
%  C, E, M, P, Cpar, Epar, Mpar, Ppar.
%  The command (1), followed by the declaration
%          global [SABL global structure 1], [SABL global structure 2], ...
%  makes the named structures accessible from the command window.
%
%  Detailed help for SABL is available through help commmands.
%  help [functionname] for any SABL function, just as in Matlab, e.g.
%           help u_mean.
%  help [SABL global structure].[field] and optionally subfields, provides
%           a description of the named SABL global field that is not an 
%           M or Mpar field, e.g.
%           help C.J, help C.Cphase, help C.Cstop, help C.Cstop.ress.
%  help [modelname] [SABL global structure] does the same for M and Mpar
%           fields, e.g. help normal M.data, help MVN M.k.
%
%  For SABL methods, operaton and use there is a hierarchy of help commands.
%           The commands at the top level are
%           help algorithm      Organization, stages and variations in 
%                               the SABL algorithm   
%           help SABLfunctions  Function structure, applications functions
%           help structures     Hierarchy of SABL structures
%           help models         Models in SABL
%           help priors         Priors in SABL


global C E M P Cpar Epar Mpar Ppar

tic;
cpustart = cputime;

savedpath = path;

C = [];
E = [];
M = [];
Cpar = [];
Epar = [];
Mpar = [];
Ppar = [];

E.SABLrootdir = u_getsablroot;

if nargin < 1 || isempty(model) || ~ischar(model)
    if isempty(M) || ~isfield(M, 'modeldir') || isempty(M.modeldir) ...
            || isempty(M.modelname)
        if ~isempty(M) && isfield(M, 'modeldir')
            u_rmdir(M.modeldir);
        end
        model = '.';
        [M.modeldir, M.modelname] = u_setspecdir(model);
    end
else
    if ~isempty(M) && isfield(M,'modeldir')
        u_rmdir(M.modeldir);
    end
    [M.modeldir, M.modelname] = u_setspecdir(model);
end

if ~isempty(P) && isfield(P,'projectdir')
    u_rmdir(P.projectdir);
end
if nargin < 2 || isempty(project) || ~ischar(project)
    % Use utilities/p_monitor.m
    P.projectdir = '';
    P.projectname = '';
else
    [P.projectdir, P.projectname] = u_setspecdir(project);
end


u_rmskeleton(E.SABLrootdir,true); 
u_addskeleton(E.SABLrootdir);
u_adddir(M.modeldir);
u_adddir(P.projectdir);

if isempty(which('m_monitor.m'))
    path(savedpath);
    error('Model directory missing required m_monitor.m.');
end

%  Stage open: If reading the results of a previous application and
%  continuing with more data, save certain global fields from the current
%  run before they are overwritten by the globals from file simulation_get;
%  then load file from the previous applicaton.
c_monitor('open');

if isfield(E, 'simulation_get');
    if 1 == exist('E', 'var')
        tempE = E;
    end
    fname = E.simulation_get;    
    load(fname);
    if 1 == exist('tempE', 'var')
        E = tempE;  % Always use E set in p_monitor.m even in the scenario 
                    % of simulation_get.
    end
    fprintf('\nGlobal structures loaded from file %s\n', fname)
    newJ = C.J;
    newN = C.N;
    newwork = C.J/C.Jwork;
    C.tfirst = C.tlast + 1;
    C.simget = true;
else
    C.simget = false;
    C.tfirst = 1;
end
C.runcomplete = false;
C.passone = true;
u_pucheck;

while ~C.runcomplete  %  For pass one and pass two
    
    %  Stage startrun: Sets up the application.  Outside spmd block if any.
    c_monitor('startrun');
    if C.simget && (C.J ~= newJ || C.N ~= newN || C.J/C.Jwork ~= newwork)
        fprintf('\nOriginal and updating algorithm design parameters\n')
        fprintf('     File simulation_get      This run\n')
        fprintf('          (Original)         (Updating)\n')
        fprintf('C.J %14.0f %16.0f\n', C.J, newJ)
        fprintf('C.N %14.0f %16.0f\n', C.N, newN)
        fprintf('Workers %10.0f %16.0f\n', C.J/C.Jwork, newwork)
	path(savedpath); 
        error('One or more inconsistencies')
    end
    
    if E.gpu
        if iscell(M.modeldir)
            ourmodel = M.modeldir{end};
        else
            ourmodel = M.modeldir;
        end
        if exist([ourmodel,filesep,'compile_cuda.m'],'file')
            fprintf('\nStarting to compile the CUDA/mex kernel...\n')
            c_res = compile_cuda;
            if c_res > 0
                fprintf('\nCompiled successfully\n')
                pause(0.5);
            elseif c_res < 0
                fprintf('\nCheck if .cu file exists in the model or library directory!\n')
            else
                fprintf('\nReusing the existing binary CUDA/mex kernel...\n')
            end
        else
            fprintf('\nThe helper script (compile_cuda.m) was not found...skipping compilation of CUDA/mex kernel...\n')
        end
    end
   
    %  Start of spmd block (if > 1 worker)
    if E.pus > 1
        c_sabl_spmd;
    else
        c_sabl;
    end

    %  Stage endrun: Close out the application.  Outside spmd block if any.
    c_monitor('endrun');
    C.walltime = toc;
    C.cptime = cputime - cpustart;
    fprintf('\n Elapsed clock time %10.2f seconds\n', C.walltime)
    fprintf('           CPU time %10.2f seconds\n', C.cptime)
    fprintf('              Ratio %10.2f\n', C.cptime/C.walltime)
    fprintf(' (Interpretation of CPU time is installation specific.)\n')

    if C.twopass && C.passone
        C.passone = false;
        fprintf('\nEnd of first pass, start of second pass\n'); 
        tic;
        cpustart = cputime;
    else
        fprintf('\nRun is complete.\n'); 
        C.runcomplete = true;
    end

end  %  End of loop for pass one and pass two

%  Stage close: Save the results if E.simulation_record set.
c_monitor('close')

if strcmp(C.stage, 'close') && isfield(E, 'simulation_get')
    E = rmfield(E, 'simulation_get');
end

if strcmp(C.stage, 'close') && isfield(E, 'simulation_record')
    fname = E.simulation_record;
    E = rmfield(E, 'simulation_record');
    save(fname, 'C', 'E', 'M', 'P', ...
        'Cpar', 'Epar', 'Mpar', 'Ppar');
    fprintf('\nGlobal structures saved to file %s\n', fname)
end

if nargout > 0
    allstructures = struct('C', C, 'E', E, 'M', M, 'P', P, ...
        'Cpar', Cpar, 'Epar', Epar, 'Mpar', Mpar, 'Ppar', Ppar);
end
path(savedpath);

C = u_tidyfields(C);
Cpar = u_tidyfields(Cpar);
E = u_tidyfields(E);
M = u_tidyfields(M);
% P = u_tidyfields(P);

end
