function c_monitor(stage)
%  Fuction is invoked at each stage of execution of the SABL algrorithm.
%  It performs housekeeping functions common to all models and
%  applications.  It transfers control to m_monitor before returning.
%
%  Input:
%  stage      Name of the current stage of execution of the SABL algroithm

global C E M Ppar

%  Work prior to transferring control to m_monitor ------------------------

C.stage = stage;
if strcmp(stage, 'open')
    if u_toolbox_ok('Parallel Computing Toolbox')
        E.mptbi = true;
        E.phygpus = gpuDeviceCount;
    else
        E.mptbi = false;
        E.phygpus = 0;
    end
    E.gpu = false;
    E.pus = 1;
    E.float = 'double';
    E.doclevel = 1;
elseif strcmp(stage,'startrun')
    %  Create substructures
    if ~C.simget
        C.Cphase = struct;
        C.Cstop = struct;
        C.Mphase = struct;
        C.Mstop = struct;
        C.detail = struct;
        %  Create some structure fields and set to default values
        C.twopass = false;
        C.J = 2^4;
        C.N = 2^10;
        C.Cphase_method = 'anneal_Bayes';
        C.Cstop_method = 'ESS';
        C.Sphase_method = 'residual';
        C.Mphase_method = 'MGRW_simple';
        C.Mstop_method = 'RNE&steps';
        C.nstates = 0;
        C.detail_level = 7;
        C.Mphase.groups = 1;
        M.rnecustom = false;
        C.nlcuda = false;
    end
end

C.stagestep = 'premonitor';
%  Opportunity to set values that might be modified in m_monitor, p_monitor
if ~(strcmp(stage, 'open') || strcmp(stage, 'close'))
    c_Cphase(stage);
    c_Sphase(stage);
    c_Mphase(stage);
end

%  Pass control to m_monitor, p_monitor

m_monitor(stage);

if strcmp(stage, 'open')
    E.EE = E; 
elseif strcmp(stage, 'close')
    if isfield(E, 'EE')
        E = rmfield(E, 'EE');
    end
else
    if u_islab1
        tempE = E;
        tempEE = tempE.EE;
        tempE = rmfield(tempE, 'EE');
        if ~isequal(tempE, tempEE)
            error('Attempt to change E structure after stage open')
        end
        clear tempE tempEE
    end
end

if strcmp(stage, 'startrun')
    
    C = u_tidyfields(C);
    E = u_tidyfields(E);
    M = u_tidyfields(M);
    
    u_isfield(M, 'prior', true, 'M');
    M.prior = u_initialsetup(M.prior);
    
    if C.twopass && C.tfirst > 1
        error('Two-pass algorithm not implemented with simulation_get')
    end
    
    if isfield(M,'data')
        M.data = u_setdatatype(M.data);
    end
    u_isfield(C, 'tfirst', true, 'C');
    u_isfield(C, 'tlast', true, 'C');
    
    C.tupdate = C.tlast - C.tfirst + 1;
    
    %     if ~isfield(M, 'custom')
    %         M.rnecustom = false;
    %     end
    
    if E.gpu && ~isempty(Ppar)
        r = u_isonrecursive(Ppar);
        if ~isempty(r) && ~strcmp('gpu', r)
            u_cprintf('Red', 'E.gpu = true and there are fields of Ppar');
            u_cprintf('Red', 'that are not datatype gpuArray.');
            u_cprintf('Red', ...
                'This may significantly slow your execution time.');
        end
    end
    
    C.detail.ml = C.detail_level > 0;
    if C.passone
        C.JN = C.J*C.N;
        C.Jwork = C.J/E.pus;
        if C.Jwork ~= round(C.Jwork)
            error('C.J = %d not wholly divisible by E.pus = %d', C.J, E.pus)
        end
        C.JNwork = C.JN/E.pus;
        if 1 == E.pus
            if E.gpu
                fprintf('\nSABL executing using GPU with 1 worker\n')
            else
                fprintf('\nSABL executing using CPU with 1 worker\n')
            end
        else
            if E.gpu
                fprintf('\nSABL executing using GPU with %d workers\n', ...
                    E.pus)
            else
                fprintf('\nSABL executing using CPU with %d workers\n', ...
                    E.pus)
            end
        end
    end
    
    M.mix = false;
    for j = 1:length(M.prior)
        if M.prior{j}.mix
            M.mix = true;
        end
    end
    
elseif strcmp(stage, 'startcycle') && C.detail_level > 7 && u_islab1
    fprintf('\n')
    
elseif strcmp(stage, 'finish')
    if C.detail.ml && u_islab1 && ...
            (strcmp(C.Cphase_method, 'data_whole') || ...
            strcmp(C.Cphase_method, 'anneal_Bayes'))
        fprintf('\nLog marginal likelihood\n')
        fprintf('             Approximation    Numerical standard error\n')
        fprintf('   w-bar:  %15.4f       %21.4f\n', C.logml1, C.logmlnse)
        fprintf(' w-tilde:  %15.4f       %21.4f\n', C.logml2, C.logmlnse)
    end
    
    if E.gpu && ~isempty(Ppar)
        r = u_isonrecursive(Ppar);
        if ~isempty(r) && ~strcmp('gpu', r)
            out1 = 'There are fields of Ppar, E.gpu = true, ';
            out2 = 'and these fields are not datatype gpuArray. ';
            out3 = 'This may significantly slow your execution time.';
            u_cprintf('Red', [out1, out2, out3])
        end
    end
    
end
C.stagestep = 'postmonitor';
%  Opportunity to react to global fields set in m_monitor, p_monitor
if ~(strcmp(stage, 'open') || strcmp(stage, 'close'))
    c_Cphase(stage);
    c_Sphase(stage);
    c_Mphase(stage);
end

% Conveys to c_Cphase, c_Sphase, c_Mphase control not passed from c_monitor
C.stagestep = 'nomonitor';

end
